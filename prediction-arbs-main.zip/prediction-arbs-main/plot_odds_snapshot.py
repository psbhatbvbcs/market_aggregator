#!/usr/bin/env python3
"""
Plot odds snapshots from CSV file
Shows time-series graphs for all platforms and outcomes with color coding
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import sys
from pathlib import Path
import numpy as np

# Color schemes for different platform types
PREDICTION_MARKET_COLORS = {
    'polymarket_price': '#7C3AED',  # Purple
    'kalshi_price': '#2563EB',      # Blue
}

TRADITIONAL_SPORTSBOOK_COLORS = {
    'youwager_odds': '#EF4444',      # Red
    'matchbook_odds': '#F59E0B',     # Amber
    'unibet_odds': '#10B981',        # Green
    'betmgm_odds': '#06B6D4',        # Cyan
    'betonline_odds': '#8B5CF6',     # Violet
    'bodog_odds': '#EC4899',         # Pink
    'fanduel_odds': '#F97316',       # Orange
    'draftkings_odds': '#14B8A6',    # Teal
    'sportsbetting_odds': '#6366F1', # Indigo
    'lowvig_odds': '#A855F7',        # Purple
    'bovada_odds': '#D946EF',        # Fuchsia
    'pinnacle_odds': '#84CC16',      # Lime
    'intertops_odds': '#22C55E',     # Green
}

ALL_COLORS = {**PREDICTION_MARKET_COLORS, **TRADITIONAL_SPORTSBOOK_COLORS}

# Platform display names
PLATFORM_NAMES = {
    'polymarket_price': 'Polymarket',
    'kalshi_price': 'Kalshi',
    'youwager_odds': 'YouWager',
    'matchbook_odds': 'Matchbook',
    'unibet_odds': 'Unibet',
    'betmgm_odds': 'BetMGM',
    'betonline_odds': 'BetOnline',
    'bodog_odds': 'Bodog',
    'fanduel_odds': 'FanDuel',
    'draftkings_odds': 'DraftKings',
    'sportsbetting_odds': 'SportsBetting',
    'lowvig_odds': 'LowVig',
    'bovada_odds': 'Bovada',
    'pinnacle_odds': 'Pinnacle',
    'intertops_odds': 'Intertops',
}

def american_to_probability(odds):
    """Convert American odds to implied probability"""
    if pd.isna(odds) or odds == 0:
        return None
    if odds > 0:
        return 100 / (odds + 100)
    else:
        return abs(odds) / (abs(odds) + 100)


def load_and_prepare_data(csv_file):
    """Load CSV and prepare data for plotting"""
    print(f"📂 Loading data from: {csv_file}")
    df = pd.read_csv(csv_file)
    
    # Convert timestamp to datetime
    df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
    
    print(f"✅ Loaded {len(df)} rows")
    print(f"📊 Outcomes: {df['outcome'].unique()}")
    print(f"⏰ Time range: {df['datetime'].min()} to {df['datetime'].max()}")
    print(f"⏱️  Duration: {(df['datetime'].max() - df['datetime'].min()).total_seconds() / 60:.1f} minutes")
    
    # Convert American odds to probabilities for traditional sportsbooks
    for col in TRADITIONAL_SPORTSBOOK_COLORS.keys():
        if col in df.columns:
            prob_col = col.replace('_odds', '_prob')
            df[prob_col] = df[col].apply(american_to_probability)
    
    return df


def plot_outcome_comparison(df, outcome, ax, show_legend=True):
    """Plot all platforms for a single outcome"""
    outcome_data = df[df['outcome'] == outcome].copy()
    outcome_data = outcome_data.sort_values('datetime')
    
    # Track which platforms have data
    platforms_with_data = []
    
    # Plot prediction markets (as probabilities)
    for platform, color in PREDICTION_MARKET_COLORS.items():
        if platform in outcome_data.columns:
            data = outcome_data[['datetime', platform]].dropna()
            if len(data) > 0:
                ax.plot(data['datetime'], data[platform], 
                       label=PLATFORM_NAMES.get(platform, platform),
                       color=color, linewidth=2.5, alpha=0.9, marker='o', markersize=3)
                platforms_with_data.append(platform)
    
    # Plot traditional sportsbooks (converted to probabilities)
    for platform, color in TRADITIONAL_SPORTSBOOK_COLORS.items():
        prob_col = platform.replace('_odds', '_prob')
        if prob_col in outcome_data.columns:
            data = outcome_data[['datetime', prob_col]].dropna()
            if len(data) > 0:
                ax.plot(data['datetime'], data[prob_col], 
                       label=PLATFORM_NAMES.get(platform, platform),
                       color=color, linewidth=1.5, alpha=0.7, marker='.', markersize=2)
                platforms_with_data.append(platform)
    
    # Formatting
    ax.set_ylabel('Implied Probability', fontsize=12, fontweight='bold')
    ax.set_title(f'{outcome}', fontsize=14, fontweight='bold', pad=10)
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.set_ylim(0, 1)
    
    # Format y-axis as percentage
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y*100:.0f}%'))
    
    # Format x-axis
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    ax.tick_params(axis='x', rotation=45)
    
    if show_legend and platforms_with_data:
        # Split legend into two columns for better readability
        ax.legend(loc='best', fontsize=8, ncol=2, framealpha=0.9)
    
    print(f"  {outcome}: {len(platforms_with_data)} platforms plotted")
    
    return platforms_with_data


def create_full_comparison_plot(df, output_file=None):
    """Create a comprehensive plot with all outcomes"""
    outcomes = df['outcome'].unique()
    n_outcomes = len(outcomes)
    
    print(f"\n🎨 Creating plot for {n_outcomes} outcomes...")
    
    # Create figure with subplots
    fig, axes = plt.subplots(n_outcomes, 1, figsize=(16, 6 * n_outcomes))
    
    # Handle case of single outcome
    if n_outcomes == 1:
        axes = [axes]
    
    # Plot each outcome
    for idx, outcome in enumerate(outcomes):
        show_legend = (idx == 0)  # Only show legend on first plot
        plot_outcome_comparison(df, outcome, axes[idx], show_legend=show_legend)
    
    # Main title
    start_time = df['datetime'].min().strftime('%Y-%m-%d %H:%M')
    end_time = df['datetime'].max().strftime('%H:%M')
    duration_min = (df['datetime'].max() - df['datetime'].min()).total_seconds() / 60
    
    fig.suptitle(f'Odds Tracking: {start_time} to {end_time} ({duration_min:.1f} minutes)', 
                 fontsize=16, fontweight='bold', y=0.995)
    
    plt.tight_layout()
    
    # Save or show
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"\n✅ Plot saved to: {output_file}")
    else:
        plt.show()
    
    return fig


def create_combined_plot(df, output_file=None):
    """Create a single plot with all outcomes overlaid"""
    print(f"\n🎨 Creating combined overlay plot...")
    
    fig, ax = plt.subplots(figsize=(16, 10))
    
    outcomes = df['outcome'].unique()
    
    # Use different line styles for different outcomes
    outcome_styles = {
        outcomes[0]: '-',   # Solid for first outcome
        outcomes[1]: '--',  # Dashed for second outcome
        outcomes[2]: ':',   # Dotted for third outcome
    }
    
    for outcome in outcomes:
        outcome_data = df[df['outcome'] == outcome].copy()
        outcome_data = outcome_data.sort_values('datetime')
        linestyle = outcome_styles.get(outcome, '-')
        
        # Plot prediction markets
        for platform, color in PREDICTION_MARKET_COLORS.items():
            if platform in outcome_data.columns:
                data = outcome_data[['datetime', platform]].dropna()
                if len(data) > 0:
                    label = f"{outcome} - {PLATFORM_NAMES.get(platform, platform)}"
                    ax.plot(data['datetime'], data[platform], 
                           label=label, color=color, linewidth=2.5, 
                           alpha=0.9, linestyle=linestyle, marker='o', markersize=3)
        
        # Plot traditional sportsbooks (converted to probabilities)
        for platform, color in TRADITIONAL_SPORTSBOOK_COLORS.items():
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[['datetime', prob_col]].dropna()
                if len(data) > 0:
                    label = f"{outcome} - {PLATFORM_NAMES.get(platform, platform)}"
                    ax.plot(data['datetime'], data[prob_col], 
                           label=label, color=color, linewidth=1.5, 
                           alpha=0.6, linestyle=linestyle, marker='.', markersize=2)
    
    # Formatting
    ax.set_ylabel('Implied Probability', fontsize=14, fontweight='bold')
    ax.set_xlabel('Time', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--')
    ax.set_ylim(0, 1)
    
    # Format y-axis as percentage
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y*100:.0f}%'))
    
    # Format x-axis
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    ax.tick_params(axis='x', rotation=45)
    
    # Legend outside plot area
    ax.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize=9, framealpha=0.9)
    
    # Title
    start_time = df['datetime'].min().strftime('%Y-%m-%d %H:%M')
    end_time = df['datetime'].max().strftime('%H:%M')
    duration_min = (df['datetime'].max() - df['datetime'].min()).total_seconds() / 60
    
    ax.set_title(f'Combined Odds Tracking: {start_time} to {end_time} ({duration_min:.1f} minutes)', 
                 fontsize=16, fontweight='bold', pad=15)
    
    plt.tight_layout()
    
    # Save or show
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✅ Combined plot saved to: {output_file}")
    else:
        plt.show()
    
    return fig


def create_platform_comparison(df, output_file=None):
    """Create plots comparing prediction markets vs traditional sportsbooks"""
    print(f"\n🎨 Creating platform type comparison...")
    
    outcomes = df['outcome'].unique()
    n_outcomes = len(outcomes)
    
    fig, axes = plt.subplots(n_outcomes, 2, figsize=(20, 6 * n_outcomes))
    
    if n_outcomes == 1:
        axes = axes.reshape(1, -1)
    
    for idx, outcome in enumerate(outcomes):
        outcome_data = df[df['outcome'] == outcome].copy()
        outcome_data = outcome_data.sort_values('datetime')
        
        # Left plot: Prediction markets
        ax_pred = axes[idx, 0]
        for platform, color in PREDICTION_MARKET_COLORS.items():
            if platform in outcome_data.columns:
                data = outcome_data[['datetime', platform]].dropna()
                if len(data) > 0:
                    ax_pred.plot(data['datetime'], data[platform], 
                               label=PLATFORM_NAMES.get(platform, platform),
                               color=color, linewidth=3, alpha=0.9, marker='o', markersize=4)
        
        ax_pred.set_ylabel('Implied Probability', fontsize=12, fontweight='bold')
        ax_pred.set_title(f'{outcome} - Prediction Markets', fontsize=13, fontweight='bold')
        ax_pred.grid(True, alpha=0.3, linestyle='--')
        ax_pred.set_ylim(0, 1)
        ax_pred.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y*100:.0f}%'))
        ax_pred.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax_pred.tick_params(axis='x', rotation=45)
        ax_pred.legend(loc='best', fontsize=10, framealpha=0.9)
        
        # Right plot: Traditional sportsbooks
        ax_trad = axes[idx, 1]
        for platform, color in TRADITIONAL_SPORTSBOOK_COLORS.items():
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[['datetime', prob_col]].dropna()
                if len(data) > 0:
                    ax_trad.plot(data['datetime'], data[prob_col], 
                               label=PLATFORM_NAMES.get(platform, platform),
                               color=color, linewidth=2, alpha=0.8, marker='.', markersize=3)
        
        ax_trad.set_ylabel('Implied Probability', fontsize=12, fontweight='bold')
        ax_trad.set_title(f'{outcome} - Traditional Sportsbooks', fontsize=13, fontweight='bold')
        ax_trad.grid(True, alpha=0.3, linestyle='--')
        ax_trad.set_ylim(0, 1)
        ax_trad.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y*100:.0f}%'))
        ax_trad.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        ax_trad.tick_params(axis='x', rotation=45)
        ax_trad.legend(loc='best', fontsize=8, ncol=2, framealpha=0.9)
    
    # Main title
    start_time = df['datetime'].min().strftime('%Y-%m-%d %H:%M')
    end_time = df['datetime'].max().strftime('%H:%M')
    duration_min = (df['datetime'].max() - df['datetime'].min()).total_seconds() / 60
    
    fig.suptitle(f'Platform Comparison: {start_time} to {end_time} ({duration_min:.1f} minutes)', 
                 fontsize=16, fontweight='bold', y=0.995)
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✅ Platform comparison saved to: {output_file}")
    else:
        plt.show()
    
    return fig


def print_statistics(df):
    """Print summary statistics for each outcome and platform"""
    print("\n" + "="*80)
    print("📈 STATISTICS SUMMARY")
    print("="*80)
    
    for outcome in df['outcome'].unique():
        print(f"\n{outcome}:")
        print("-" * 60)
        
        outcome_data = df[df['outcome'] == outcome]
        
        # Prediction markets
        print("\n  Prediction Markets:")
        for platform in PREDICTION_MARKET_COLORS.keys():
            if platform in outcome_data.columns:
                data = outcome_data[platform].dropna()
                if len(data) > 0:
                    print(f"    {PLATFORM_NAMES.get(platform, platform):15} | "
                          f"Mean: {data.mean():.3f} | "
                          f"Min: {data.min():.3f} | "
                          f"Max: {data.max():.3f} | "
                          f"Std: {data.std():.4f} | "
                          f"Samples: {len(data)}")
        
        # Traditional sportsbooks (show as probabilities)
        print("\n  Traditional Sportsbooks:")
        for platform in TRADITIONAL_SPORTSBOOK_COLORS.keys():
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[prob_col].dropna()
                if len(data) > 0:
                    print(f"    {PLATFORM_NAMES.get(platform, platform):15} | "
                          f"Mean: {data.mean():.3f} | "
                          f"Min: {data.min():.3f} | "
                          f"Max: {data.max():.3f} | "
                          f"Std: {data.std():.4f} | "
                          f"Samples: {len(data)}")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Plot odds snapshot data')
    parser.add_argument('csv_file', nargs='?', help='Path to CSV file (or will search for latest)')
    parser.add_argument('--output-dir', '-o', help='Output directory for plots', default='plots')
    parser.add_argument('--combined', action='store_true', help='Create combined overlay plot')
    parser.add_argument('--comparison', action='store_true', help='Create platform type comparison')
    parser.add_argument('--stats', action='store_true', help='Print statistics only')
    parser.add_argument('--all', action='store_true', help='Create all plot types')
    
    args = parser.parse_args()
    
    # Find CSV file
    if args.csv_file:
        csv_file = Path(args.csv_file)
    else:
        # Find latest CSV file
        csv_files = sorted(Path('.').glob('odds_snapshots_*.csv'))
        if not csv_files:
            print("❌ No CSV files found. Please specify a file.")
            return 1
        csv_file = csv_files[-1]
    
    if not csv_file.exists():
        print(f"❌ File not found: {csv_file}")
        return 1
    
    # Load data
    df = load_and_prepare_data(csv_file)
    
    # Print statistics if requested
    if args.stats or args.all:
        print_statistics(df)
        if args.stats:
            return 0
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # Generate base filename from CSV
    base_name = csv_file.stem
    
    # Create plots
    if args.all or not (args.combined or args.comparison):
        # Default: create separate outcome plots
        output_file = output_dir / f"{base_name}_comparison.png"
        create_full_comparison_plot(df, output_file)
    
    if args.combined or args.all:
        output_file = output_dir / f"{base_name}_combined.png"
        create_combined_plot(df, output_file)
    
    if args.comparison or args.all:
        output_file = output_dir / f"{base_name}_platform_comparison.png"
        create_platform_comparison(df, output_file)
    
    print("\n✅ Done!")
    return 0


if __name__ == '__main__':
    sys.exit(main())

