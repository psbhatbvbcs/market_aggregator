import requests
import json
import csv
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
from py_clob_client.client import ClobClient
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
POLYMARKET_CLOB = "https://clob.polymarket.com"
POLYMARKET_DATA = "https://data-api.polymarket.com"

API_KEY_ID = "39bb4b72-782d-432e-84e6-f228d2e4703d"
PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692B
gGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2lj
z4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1E
X8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u8
8DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eru
M1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUk
xxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5
F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPp
oLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb
778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3d
OygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobf
KQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1
uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJ
WvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jza
lm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5
qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI
1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6
c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4
eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCw
GsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8
R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa
98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoe
dYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxO
Fmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX
3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo
-----END RSA PRIVATE KEY-----"""

POLYMARKET_PRIVATE_KEY = "0xb0240ca09fd5169f06f95655788ef9f8e9f6b73dc4242721903b540c81635d7a"
POLYMARKET_FUNDER = "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
CHAIN_ID = 137

KALSHI_SLUG = "kxnflgame-25oct12dalcar"
POLYMARKET_SLUG = "nfl-dal-car-2025-10-12"

JSONL_INPUT = "arbitrage_executions.jsonl"
CSV_OUTPUT = "arbitrage_data_with_actuals.csv"

class KalshiAuth:
    def __init__(self, api_key_id: str, private_key_pem: str):
        self.api_key_id = api_key_id
        self.private_key = self._load_private_key(private_key_pem)

    def _load_private_key(self, key_pem: str):
        return serialization.load_pem_private_key(
            key_pem.encode('utf-8'),
            password=None,
            backend=default_backend()
        )

    def create_signature(self, timestamp: str, method: str, path: str) -> str:
        message = f"{timestamp}{method}{path}".encode('utf-8')
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH
            ),
            hashes.SHA256()
        )
        return base64.b64encode(signature).decode('utf-8')

    def get_auth_headers(self, method: str, path: str) -> Dict[str, str]:
        timestamp = str(int(datetime.now().timestamp() * 1000))
        signature = self.create_signature(timestamp, method, path)
        return {
            'KALSHI-ACCESS-KEY': self.api_key_id,
            'KALSHI-ACCESS-SIGNATURE': signature,
            'KALSHI-ACCESS-TIMESTAMP': timestamp
        }

def fetch_kalshi_trades_comprehensive(auth: KalshiAuth, event_ticker: str) -> List[Dict]:
    trades = []
    try:
        logger.info(f"Fetching markets for event: {event_ticker}")
        headers = auth.get_auth_headers("GET", f"/trade-api/v2/markets")
        response = requests.get(
            f"{KALSHI_BASE}/markets",
            headers=headers,
            params={"event_ticker": event_ticker.upper(), "limit": 100},
            timeout=10
        )
        if response.status_code != 200:
            logger.error(f"Failed to get markets: {response.status_code}")
            return trades

        markets = response.json().get("markets", [])
        market_tickers = [m["ticker"] for m in markets]
        ticker_to_team = {}
        for market in markets:
            ticker = market["ticker"]
            title = market.get("title", "")
            if "DAL" in ticker.upper() or "Dallas" in title or "Cowboys" in title:
                ticker_to_team[ticker] = "Dallas Cowboys"
            elif "CAR" in ticker.upper() or "Carolina" in title or "Panthers" in title:
                ticker_to_team[ticker] = "Carolina Panthers"

        logger.info("Fetching portfolio fills...")
        headers = auth.get_auth_headers("GET", "/trade-api/v2/portfolio/fills")
        response = requests.get(
            f"{KALSHI_BASE}/portfolio/fills",
            headers=headers,
            params={"limit": 1000},
            timeout=10
        )

        if response.status_code == 200:
            fills = response.json().get("fills", [])
            fills_for_game = [f for f in fills if f.get("ticker") in market_tickers]
            fills_by_order = {}
            for fill in fills_for_game:
                order_id = fill.get("order_id")
                if order_id:
                    if order_id not in fills_by_order:
                        fills_by_order[order_id] = []
                    fills_by_order[order_id].append(fill)

            for order_id, order_fills in fills_by_order.items():
                total_count = sum(f.get("count", 0) for f in order_fills)
                first_fill = order_fills[0]
                ticker = first_fill.get("ticker")
                side = first_fill.get("side")
                action = first_fill.get("action")
                total_cost = sum(f.get("count", 0) * f.get("price", 0) for f in order_fills)
                avg_price = total_cost / total_count if total_count > 0 else 0
                trade = {
                    "exchange": "kalshi",
                    "order_id": order_id,
                    "ticker": ticker,
                    "team": ticker_to_team.get(ticker, "Unknown"),
                    "side": side,
                    "action": action,
                    "filled_count": total_count,
                    "execution_price": avg_price,
                    "created_time": first_fill.get("created_time")
                }
                trades.append(trade)
    except Exception as e:
        logger.error(f"Error fetching Kalshi trades: {e}")
    return trades

def fetch_polymarket_trades_comprehensive(private_key: str, funder: str, slug: str) -> List[Dict]:
    trades = []
    try:
        client = ClobClient(POLYMARKET_CLOB, key=private_key, chain_id=CHAIN_ID, signature_type=1, funder=funder)
        client.set_api_creds(client.create_or_derive_api_creds())
        api_creds = client.derive_api_key()

        logger.info(f"Fetching market info for: {slug}")
        resp = requests.get(f"https://gamma-api.polymarket.com/markets?slug={slug}", timeout=10)
        token_to_team = {}
        token_ids = []

        if resp.status_code == 200:
            markets = resp.json()
            if isinstance(markets, list) and len(markets) > 0:
                market = markets[0]
                outcomes = market.get('outcomes', [])
                clob_token_ids = market.get('clobTokenIds', [])
                if isinstance(outcomes, str):
                    try:
                        outcomes = json.loads(outcomes)
                    except:
                        import ast
                        outcomes = ast.literal_eval(outcomes)
                if isinstance(clob_token_ids, str):
                    try:
                        clob_token_ids = json.loads(clob_token_ids)
                    except:
                        import ast
                        clob_token_ids = ast.literal_eval(clob_token_ids)

                for i, outcome in enumerate(outcomes):
                    if i < len(clob_token_ids):
                        token_id = str(clob_token_ids[i])
                        token_ids.append(token_id)
                        if "Dallas" in outcome or "Cowboys" in outcome or "DAL" in outcome:
                            token_to_team[token_id] = "Dallas Cowboys"
                        elif "Carolina" in outcome or "Panthers" in outcome or "CAR" in outcome:
                            token_to_team[token_id] = "Carolina Panthers"

        headers = {
            "POLY-API-KEY": api_creds.api_key,
            "POLY-API-SECRET": api_creds.api_secret,
            "POLY-API-PASSPHRASE": api_creds.api_passphrase
        }

        for token_id in token_ids:
            url = f"{POLYMARKET_CLOB}/orders?asset_id={token_id}"
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                orders = response.json()
                for order in orders:
                    size_matched = float(order.get("size_matched", 0))
                    if size_matched > 0:
                        trades.append({
                            "exchange": "polymarket",
                            "order_id": order.get("id"),
                            "token_id": token_id,
                            "team": token_to_team.get(token_id, "Unknown"),
                            "side": order.get("side"),
                            "size_matched": size_matched,
                            "price": float(order.get("price", 0)),
                            "execution_price": float(order.get("price", 0)),
                            "created_at": order.get("created_at")
                        })

        url = f"{POLYMARKET_DATA}/trades"
        params = {"user": funder.lower(), "limit": 1000}
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            trades_data = response.json()
            for trade_item in trades_data:
                asset_id = trade_item.get("asset_id")
                market_slug = trade_item.get("market_slug", "")
                outcome = trade_item.get("outcome", "")
                is_our_market = False
                if asset_id in token_ids:
                    is_our_market = True
                elif slug.lower() in market_slug.lower():
                    is_our_market = True

                if is_our_market:
                    team = "Unknown"
                    if "cowboys" in outcome.lower() or "dal" in outcome.lower():
                        team = "Dallas Cowboys"
                    elif "panthers" in outcome.lower() or "car" in outcome.lower():
                        team = "Carolina Panthers"
                    trades.append({
                        "exchange": "polymarket",
                        "trade_id": trade_item.get("id"),
                        "order_id": trade_item.get("order_id"),
                        "token_id": asset_id,
                        "team": team,
                        "outcome": outcome,
                        "side": trade_item.get("side"),
                        "size": float(trade_item.get("size", 0)),
                        "price": float(trade_item.get("price", 0)),
                        "execution_price": float(trade_item.get("price", 0)),
                        "timestamp": float(trade_item.get("timestamp", 0))
                    })
    except Exception as e:
        logger.error(f"Error fetching Polymarket trades: {e}")
    return trades

def iso_to_epoch(ts_str):
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
    except Exception:
        return None

def generate_base_csv_data(jsonl_file: str) -> List[Dict]:
    rows = []
    with open(jsonl_file, "r") as infile:
        for line in infile:
            if not line.strip():
                continue
            data = json.loads(line)
            arb = data.get("arbitrage", {})
            timestamp = data.get("timestamp")
            arbitrage_type = arb.get("type", "")
            home = arb.get("home_win", {})
            away = arb.get("away_win", {})
            first_trade_exchange = home.get("exchange", "")
            second_trade_exchange = away.get("exchange", "")
            home_win_price = home.get("price", "")
            away_win_price = away.get("price", "")

            kalshi_order_id = ""
            polymarket_order_id = ""
            orders = data.get("orders", [])
            for order_entry in orders:
                exchange = order_entry.get("exchange", "")
                if exchange == "kalshi":
                    order_data = order_entry.get("order", {})
                    kalshi_order_id = order_data.get("order_id", "")
                elif exchange == "polymarket":
                    order_data = order_entry.get("order", {})
                    orders_list = order_data.get("orders", [])
                    if orders_list:
                        polymarket_order_id = orders_list[0].get("orderID", "")

            rows.append({
                "timestamp": timestamp,
                "first_trade_exchange": first_trade_exchange,
                "second_trade_exchange": second_trade_exchange,
                "arbitrage_type": arbitrage_type,
                "home_win_price": home_win_price,
                "away_win_price": away_win_price,
                "kalshi_order_id": kalshi_order_id,
                "polymarket_order_id": polymarket_order_id
            })
    return rows

def main():
    logger.info("="*80)
    logger.info("COMPLETE ARBITRAGE ANALYSIS")
    logger.info("="*80)

    logger.info("Step 1: Parsing JSONL file...")
    csv_data = generate_base_csv_data(JSONL_INPUT)
    logger.info(f"Found {len(csv_data)} arbitrage executions")

    logger.info("\nStep 2: Fetching Kalshi trades...")
    kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)
    kalshi_trades = fetch_kalshi_trades_comprehensive(kalshi_auth, KALSHI_SLUG)
    logger.info(f"Found {len(kalshi_trades)} Kalshi trades")

    logger.info("\nStep 3: Fetching Polymarket trades...")
    polymarket_trades = fetch_polymarket_trades_comprehensive(POLYMARKET_PRIVATE_KEY, POLYMARKET_FUNDER, POLYMARKET_SLUG)
    logger.info(f"Found {len(polymarket_trades)} Polymarket trades")

    kalshi_lookup = {t.get("order_id"): t for t in kalshi_trades if t.get("order_id")}
    polymarket_lookup = {t.get("order_id"): t for t in polymarket_trades if t.get("order_id")}
    poly_by_timestamp = sorted([t for t in polymarket_trades if t.get("timestamp")], key=lambda x: x["timestamp"])

    logger.info("\nStep 4: Matching trades with arbitrage executions...")

    for idx, row in enumerate(csv_data):
        first_exchange = row["first_trade_exchange"]
        second_exchange = row["second_trade_exchange"]
        kalshi_oid = row.get("kalshi_order_id")
        poly_oid = row.get("polymarket_order_id")
        timestamp = iso_to_epoch(row["timestamp"])

        row["first_trade_actual_price"] = None
        row["second_trade_actual_price"] = None
        row["first_trade_filled_count"] = None
        row["second_trade_filled_count"] = None

        if first_exchange == "kalshi":
            if kalshi_oid and kalshi_oid in kalshi_lookup:
                trade = kalshi_lookup[kalshi_oid]
                row["first_trade_actual_price"] = trade.get("execution_price")
                row["first_trade_filled_count"] = trade.get("filled_count")
        elif first_exchange == "polymarket":
            if poly_oid and poly_oid in polymarket_lookup:
                trade = polymarket_lookup[poly_oid]
                row["first_trade_actual_price"] = trade.get("execution_price")
                row["first_trade_filled_count"] = trade.get("size_matched", trade.get("size"))
            elif timestamp and poly_by_timestamp:
                OFFSET_SECONDS = 5.5 * 3600
                arb_ts_corrected = timestamp + OFFSET_SECONDS
                closest = None
                min_diff = float("inf")
                for t in poly_by_timestamp:
                    diff = abs(t["timestamp"] - arb_ts_corrected)
                    if diff < min_diff:
                        min_diff = diff
                        closest = t
                if closest and min_diff <= 3600:
                    row["first_trade_actual_price"] = closest.get("execution_price")
                    row["first_trade_filled_count"] = closest.get("size")

        if second_exchange == "kalshi":
            if kalshi_oid and kalshi_oid in kalshi_lookup:
                trade = kalshi_lookup[kalshi_oid]
                row["second_trade_actual_price"] = trade.get("execution_price")
                row["second_trade_filled_count"] = trade.get("filled_count")
        elif second_exchange == "polymarket":
            if poly_oid and poly_oid in polymarket_lookup:
                trade = polymarket_lookup[poly_oid]
                row["second_trade_actual_price"] = trade.get("execution_price")
                row["second_trade_filled_count"] = trade.get("size_matched", trade.get("size"))
            elif timestamp and poly_by_timestamp:
                OFFSET_SECONDS = 5.5 * 3600
                arb_ts_corrected = timestamp + OFFSET_SECONDS
                closest = None
                min_diff = float("inf")
                for t in poly_by_timestamp:
                    diff = abs(t["timestamp"] - arb_ts_corrected)
                    if diff < min_diff:
                        min_diff = diff
                        closest = t
                if closest and min_diff <= 3600:
                    row["second_trade_actual_price"] = closest.get("execution_price")
                    row["second_trade_filled_count"] = closest.get("size")

    logger.info("\nStep 5: Writing output CSV...")
    df = pd.DataFrame(csv_data)
    df.to_csv(CSV_OUTPUT, index=False)
    logger.info(f"✅ Final CSV saved to {CSV_OUTPUT}")

    matched_first = df["first_trade_actual_price"].notna().sum()
    matched_second = df["second_trade_actual_price"].notna().sum()
    total = len(df)
    logger.info("\n" + "="*80)
    logger.info("SUMMARY")
    logger.info("="*80)
    logger.info(f"Total arbitrage executions: {total}")
    logger.info(f"Matched first trades: {matched_first}/{total} ({matched_first/total*100:.1f}%)")
    logger.info(f"Matched second trades: {matched_second}/{total} ({matched_second/total*100:.1f}%)")
    logger.info("="*80)

if __name__ == "__main__":
    main()
