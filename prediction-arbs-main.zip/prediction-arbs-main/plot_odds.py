"""
Plot Odds Snapshots

Creates time-series visualizations from synchronized odds snapshots.
Shows price divergence/convergence across platforms over time.
"""

import pandas as pd
import sys
from datetime import datetime
from typing import Optional

# Try to import matplotlib, but make it optional
try:
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("⚠️  matplotlib not installed. Install with: pip install matplotlib")


def plot_odds_comparison(csv_file: str, outcome: Optional[str] = None, output_file: Optional[str] = None):
    """
    Plot odds comparison from snapshot CSV
    
    Args:
        csv_file: Path to the odds_snapshots_*.csv file
        outcome: Specific outcome to plot (e.g., "Leeds United"), or None for all
        output_file: Save plot to file instead of showing
    """
    if not HAS_MATPLOTLIB:
        print("Cannot plot without matplotlib. Please install it first.")
        return
    
    # Load data
    df = pd.read_csv(csv_file)
    
    # Convert timestamp to datetime
    df['datetime'] = pd.to_datetime(df['datetime_utc'])
    
    # Get unique outcomes
    outcomes = df['outcome'].unique()
    
    if outcome:
        # Plot single outcome
        _plot_single_outcome(df, outcome, output_file)
    else:
        # Plot all outcomes in subplots
        _plot_all_outcomes(df, outcomes, output_file)


def _plot_single_outcome(df: pd.DataFrame, outcome: str, output_file: Optional[str] = None):
    """Plot a single outcome"""
    # Filter data
    data = df[df['outcome'] == outcome].copy()
    data = data.sort_values('datetime')
    
    # Create figure
    fig, ax = plt.subplots(figsize=(14, 6))
    
    # Plot each platform
    if data['polymarket_price'].notna().any():
        ax.plot(data['datetime'], data['polymarket_price'], 
                label='Polymarket', marker='o', markersize=3, linewidth=2)
    
    if data['kalshi_price'].notna().any():
        ax.plot(data['datetime'], data['kalshi_price'], 
                label='Kalshi', marker='s', markersize=3, linewidth=2)
    
    if data['rundown_price'].notna().any():
        ax.plot(data['datetime'], data['rundown_price'], 
                label='Rundown', marker='^', markersize=3, linewidth=2)
    
    # Formatting
    ax.set_xlabel('Time', fontsize=12)
    ax.set_ylabel('Probability', fontsize=12)
    ax.set_title(f'{outcome} - Odds Comparison Across Platforms', fontsize=14, fontweight='bold')
    ax.legend(loc='best', fontsize=11)
    ax.grid(True, alpha=0.3)
    
    # Format x-axis
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
    plt.xticks(rotation=45)
    
    # Add spread area
    if data['polymarket_price'].notna().any() and data['kalshi_price'].notna().any():
        spread = (data['polymarket_price'] - data['kalshi_price']).abs()
        ax2 = ax.twinx()
        ax2.fill_between(data['datetime'], 0, spread, alpha=0.2, color='red', label='Spread')
        ax2.set_ylabel('Price Spread (absolute)', fontsize=10, color='red')
        ax2.tick_params(axis='y', labelcolor='red')
    
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Plot saved to {output_file}")
    else:
        plt.show()


def _plot_all_outcomes(df: pd.DataFrame, outcomes: list, output_file: Optional[str] = None):
    """Plot all outcomes in subplots"""
    n_outcomes = len(outcomes)
    
    # Create subplots
    fig, axes = plt.subplots(n_outcomes, 1, figsize=(14, 4*n_outcomes), sharex=True)
    
    if n_outcomes == 1:
        axes = [axes]
    
    for idx, outcome in enumerate(outcomes):
        ax = axes[idx]
        data = df[df['outcome'] == outcome].copy()
        data = data.sort_values('datetime')
        
        # Plot each platform
        if data['polymarket_price'].notna().any():
            ax.plot(data['datetime'], data['polymarket_price'], 
                   label='Polymarket', marker='o', markersize=2, linewidth=2)
        
        if data['kalshi_price'].notna().any():
            ax.plot(data['datetime'], data['kalshi_price'], 
                   label='Kalshi', marker='s', markersize=2, linewidth=2)
        
        if data['rundown_price'].notna().any():
            ax.plot(data['datetime'], data['rundown_price'], 
                   label='Rundown', marker='^', markersize=2, linewidth=2)
        
        # Formatting
        ax.set_ylabel('Probability', fontsize=10)
        ax.set_title(f'{outcome}', fontsize=12, fontweight='bold')
        ax.legend(loc='best', fontsize=9)
        ax.grid(True, alpha=0.3)
    
    # Format x-axis on bottom plot
    axes[-1].set_xlabel('Time', fontsize=12)
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
    plt.xticks(rotation=45)
    
    plt.suptitle('Odds Comparison Across All Outcomes', fontsize=16, fontweight='bold', y=0.995)
    plt.tight_layout()
    
    if output_file:
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Plot saved to {output_file}")
    else:
        plt.show()


def print_summary_stats(csv_file: str):
    """Print summary statistics from the snapshot data"""
    df = pd.read_csv(csv_file)
    
    print("\n" + "="*80)
    print("ODDS SNAPSHOT SUMMARY")
    print("="*80)
    
    # Overall stats
    print(f"\nTotal snapshots: {len(df) // len(df['outcome'].unique())}")
    print(f"Outcomes tracked: {len(df['outcome'].unique())}")
    print(f"Time range: {df['datetime_utc'].min()} to {df['datetime_utc'].max()}")
    
    # Per-outcome stats
    print("\n" + "-"*80)
    print("Per-Outcome Statistics:")
    print("-"*80)
    
    for outcome in df['outcome'].unique():
        data = df[df['outcome'] == outcome]
        
        print(f"\n{outcome}:")
        
        # Polymarket stats
        if data['polymarket_price'].notna().any():
            poly_prices = data['polymarket_price'].dropna()
            print(f"  Polymarket:")
            print(f"    Mean: ${poly_prices.mean():.4f}")
            print(f"    Min:  ${poly_prices.min():.4f}")
            print(f"    Max:  ${poly_prices.max():.4f}")
            print(f"    Std:  ${poly_prices.std():.4f}")
        
        # Kalshi stats
        if data['kalshi_price'].notna().any():
            kalshi_prices = data['kalshi_price'].dropna()
            print(f"  Kalshi:")
            print(f"    Mean: ${kalshi_prices.mean():.4f}")
            print(f"    Min:  ${kalshi_prices.min():.4f}")
            print(f"    Max:  ${kalshi_prices.max():.4f}")
            print(f"    Std:  ${kalshi_prices.std():.4f}")
        
        # Spread stats
        if data['polymarket_price'].notna().any() and data['kalshi_price'].notna().any():
            spread = (data['polymarket_price'] - data['kalshi_price']).abs()
            print(f"  Spread (|Poly - Kalshi|):")
            print(f"    Mean: ${spread.mean():.4f}")
            print(f"    Max:  ${spread.max():.4f}")
    
    print("\n" + "="*80)


def export_divergence_events(csv_file: str, threshold: float = 0.02, output_file: Optional[str] = None):
    """
    Export moments when prices diverged significantly
    
    Args:
        csv_file: Path to snapshot CSV
        threshold: Price difference threshold (default: 0.02 = 2%)
        output_file: Output CSV file (default: auto-generated)
    """
    df = pd.read_csv(csv_file)
    
    # Calculate spread
    df['spread'] = (df['polymarket_price'] - df['kalshi_price']).abs()
    
    # Filter significant divergences
    divergences = df[df['spread'] >= threshold].copy()
    divergences = divergences.sort_values('spread', ascending=False)
    
    if output_file is None:
        output_file = csv_file.replace('.csv', '_divergences.csv')
    
    divergences.to_csv(output_file, index=False)
    
    print(f"\n✓ Found {len(divergences)} divergence events (>{threshold*100}% spread)")
    print(f"✓ Exported to {output_file}")
    
    # Show top 10
    if len(divergences) > 0:
        print(f"\nTop 10 largest divergences:")
        print("-"*80)
        for idx, row in divergences.head(10).iterrows():
            print(f"{row['datetime_utc']:20} | {row['outcome']:15} | "
                  f"Poly: ${row['polymarket_price']:.4f} | "
                  f"Kalshi: ${row['kalshi_price']:.4f} | "
                  f"Spread: ${row['spread']:.4f}")


def main():
    """Main CLI"""
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python plot_odds.py <snapshot_csv_file> [options]")
        print("\nOptions:")
        print("  --outcome <name>     Plot specific outcome only")
        print("  --save <file>        Save plot to file instead of showing")
        print("  --stats              Print summary statistics only")
        print("  --divergences        Export divergence events")
        print("\nExamples:")
        print("  python plot_odds.py odds_snapshots_*.csv")
        print("  python plot_odds.py odds_snapshots_*.csv --outcome 'Leeds United'")
        print("  python plot_odds.py odds_snapshots_*.csv --save plot.png")
        print("  python plot_odds.py odds_snapshots_*.csv --stats")
        print("  python plot_odds.py odds_snapshots_*.csv --divergences")
        sys.exit(1)
    
    csv_file = sys.argv[1]
    
    # Parse options
    outcome = None
    output_file = None
    stats_only = False
    export_div = False
    
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == '--outcome' and i+1 < len(sys.argv):
            outcome = sys.argv[i+1]
            i += 2
        elif sys.argv[i] == '--save' and i+1 < len(sys.argv):
            output_file = sys.argv[i+1]
            i += 2
        elif sys.argv[i] == '--stats':
            stats_only = True
            i += 1
        elif sys.argv[i] == '--divergences':
            export_div = True
            i += 1
        else:
            i += 1
    
    # Execute
    if stats_only:
        print_summary_stats(csv_file)
    elif export_div:
        export_divergence_events(csv_file)
    else:
        plot_odds_comparison(csv_file, outcome, output_file)


if __name__ == "__main__":
    main()

