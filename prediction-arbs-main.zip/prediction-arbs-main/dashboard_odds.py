#!/usr/bin/env python3
"""
Interactive Dashboard for Odds Tracking
Run with: python dashboard_odds.py [csv_file]
Opens in browser at http://localhost:8050
"""

import dash
from dash import dcc, html, Input, Output, State
import plotly.graph_objs as go
import pandas as pd
import sys
from pathlib import Path
from datetime import datetime
import plotly.express as px

# Color schemes
PREDICTION_MARKET_COLORS = {
    'polymarket_price': '#7C3AED',  # Purple
    'kalshi_price': '#2563EB',      # Blue
}

TRADITIONAL_SPORTSBOOK_COLORS = {
    'youwager_odds': '#EF4444',      'matchbook_odds': '#F59E0B',
    'unibet_odds': '#10B981',        'betmgm_odds': '#06B6D4',
    'betonline_odds': '#8B5CF6',     'bodog_odds': '#EC4899',
    'fanduel_odds': '#F97316',       'draftkings_odds': '#14B8A6',
    'sportsbetting_odds': '#6366F1', 'lowvig_odds': '#A855F7',
    'bovada_odds': '#D946EF',        'pinnacle_odds': '#84CC16',
    'intertops_odds': '#22C55E',
}

PLATFORM_NAMES = {
    'polymarket_price': 'Polymarket', 'kalshi_price': 'Kalshi',
    'youwager_odds': 'YouWager', 'matchbook_odds': 'Matchbook',
    'unibet_odds': 'Unibet', 'betmgm_odds': 'BetMGM',
    'betonline_odds': 'BetOnline', 'bodog_odds': 'Bodog',
    'fanduel_odds': 'FanDuel', 'draftkings_odds': 'DraftKings',
    'sportsbetting_odds': 'SportsBetting', 'lowvig_odds': 'LowVig',
    'bovada_odds': 'Bovada', 'pinnacle_odds': 'Pinnacle',
    'intertops_odds': 'Intertops',
}

def american_to_probability(odds):
    """Convert American odds to implied probability"""
    if pd.isna(odds) or odds == 0:
        return None
    if odds > 0:
        return 100 / (odds + 100)
    else:
        return abs(odds) / (abs(odds) + 100)

def load_and_prepare_data(csv_file):
    """Load CSV and prepare data for plotting"""
    print(f"📂 Loading data from: {csv_file}")
    df = pd.read_csv(csv_file)
    
    # Convert timestamp to datetime
    df['datetime'] = pd.to_datetime(df['timestamp'], unit='s')
    
    # Convert American odds to probabilities for traditional sportsbooks
    for col in TRADITIONAL_SPORTSBOOK_COLORS.keys():
        if col in df.columns:
            prob_col = col.replace('_odds', '_prob')
            df[prob_col] = df[col].apply(american_to_probability)
    
    print(f"✅ Loaded {len(df)} rows")
    print(f"📊 Outcomes: {df['outcome'].unique().tolist()}")
    print(f"⏰ Time range: {df['datetime'].min()} to {df['datetime'].max()}")
    
    return df

# Find CSV file
if len(sys.argv) > 1:
    csv_file = Path(sys.argv[1])
else:
    csv_files = sorted(Path('.').glob('odds_snapshots_*.csv'))
    if not csv_files:
        print("❌ No CSV files found. Please specify a file.")
        sys.exit(1)
    csv_file = csv_files[-1]

if not csv_file.exists():
    print(f"❌ File not found: {csv_file}")
    sys.exit(1)

# Load data
df = load_and_prepare_data(csv_file)
outcomes = sorted(df['outcome'].unique())

# Initialize Dash app
app = dash.Dash(__name__, 
                title="Odds Tracking Dashboard",
                update_title="Loading...")

# Create layout
app.layout = html.Div([
    html.Div([
        html.H1("🎯 Odds Tracking Dashboard", 
                style={'textAlign': 'center', 'color': '#1f2937', 'marginBottom': '10px'}),
        html.P(f"Data: {df['datetime'].min().strftime('%Y-%m-%d %H:%M')} to {df['datetime'].max().strftime('%H:%M')} "
               f"({(df['datetime'].max() - df['datetime'].min()).total_seconds() / 60:.1f} minutes)",
               style={'textAlign': 'center', 'color': '#6b7280', 'fontSize': '14px'}),
    ], style={'backgroundColor': '#f9fafb', 'padding': '20px', 'marginBottom': '20px'}),
    
    # Controls
    html.Div([
        html.Div([
            html.Label("Select View:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
            dcc.RadioItems(
                id='view-type',
                options=[
                    {'label': ' Separate Outcomes', 'value': 'separate'},
                    {'label': ' Combined Overlay', 'value': 'combined'},
                    {'label': ' Platform Comparison', 'value': 'comparison'},
                ],
                value='separate',
                inline=True,
                style={'marginBottom': '15px'}
            ),
        ], style={'marginBottom': '20px'}),
        
        html.Div([
            html.Div([
                html.Label("Select Outcomes:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
                dcc.Checklist(
                    id='outcome-filter',
                    options=[{'label': f' {outcome}', 'value': outcome} for outcome in outcomes],
                    value=outcomes,
                    inline=True,
                ),
            ], style={'flex': '1', 'marginRight': '20px'}),
            
            html.Div([
                html.Label("Platform Type:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
                dcc.Checklist(
                    id='platform-type-filter',
                    options=[
                        {'label': ' Prediction Markets', 'value': 'prediction'},
                        {'label': ' Traditional Sportsbooks', 'value': 'traditional'},
                    ],
                    value=['prediction', 'traditional'],
                    inline=True,
                ),
            ], style={'flex': '1'}),
        ], style={'display': 'flex', 'marginBottom': '20px'}),
        
        html.Div([
            html.Label("Select Platforms:", style={'fontWeight': 'bold', 'marginBottom': '5px'}),
            html.Div([
                html.Div([
                    html.Strong("Prediction Markets:", style={'color': '#7C3AED'}),
                    dcc.Checklist(
                        id='prediction-platforms',
                        options=[
                            {'label': f' {PLATFORM_NAMES[k]}', 'value': k} 
                            for k in PREDICTION_MARKET_COLORS.keys()
                        ],
                        value=list(PREDICTION_MARKET_COLORS.keys()),
                        inline=True,
                    ),
                ], style={'marginBottom': '10px'}),
                
                html.Div([
                    html.Strong("Traditional Sportsbooks:", style={'color': '#EF4444'}),
                    dcc.Checklist(
                        id='traditional-platforms',
                        options=[
                            {'label': f' {PLATFORM_NAMES[k]}', 'value': k} 
                            for k in TRADITIONAL_SPORTSBOOK_COLORS.keys()
                        ],
                        value=list(TRADITIONAL_SPORTSBOOK_COLORS.keys())[:5],  # Default: first 5
                        inline=True,
                        style={'display': 'flex', 'flexWrap': 'wrap'}
                    ),
                ]),
            ]),
        ], style={'marginBottom': '20px'}),
        
        html.Div([
            html.Button('Select All Platforms', id='select-all-btn', n_clicks=0,
                       style={'marginRight': '10px', 'padding': '8px 16px', 'cursor': 'pointer'}),
            html.Button('Deselect All', id='deselect-all-btn', n_clicks=0,
                       style={'marginRight': '10px', 'padding': '8px 16px', 'cursor': 'pointer'}),
            html.Button('Reset to Defaults', id='reset-btn', n_clicks=0,
                       style={'padding': '8px 16px', 'cursor': 'pointer'}),
        ], style={'marginBottom': '20px'}),
        
    ], style={
        'backgroundColor': 'white',
        'padding': '20px',
        'borderRadius': '8px',
        'boxShadow': '0 1px 3px rgba(0,0,0,0.1)',
        'marginBottom': '20px'
    }),
    
    # Statistics summary
    html.Div(id='stats-summary', style={
        'backgroundColor': 'white',
        'padding': '20px',
        'borderRadius': '8px',
        'boxShadow': '0 1px 3px rgba(0,0,0,0.1)',
        'marginBottom': '20px'
    }),
    
    # Graph
    html.Div([
        dcc.Loading(
            id="loading",
            type="default",
            children=dcc.Graph(
                id='odds-graph',
                config={
                    'displayModeBar': True,
                    'displaylogo': False,
                    'modeBarButtonsToAdd': ['drawline', 'drawopenpath', 'eraseshape'],
                    'toImageButtonOptions': {
                        'format': 'png',
                        'filename': 'odds_tracking',
                        'height': 1080,
                        'width': 1920,
                        'scale': 2
                    }
                },
                style={'height': '800px'}
            )
        ),
    ], style={
        'backgroundColor': 'white',
        'padding': '20px',
        'borderRadius': '8px',
        'boxShadow': '0 1px 3px rgba(0,0,0,0.1)',
    }),
    
], style={
    'fontFamily': 'system-ui, -apple-system, sans-serif',
    'backgroundColor': '#f3f4f6',
    'padding': '20px',
    'minHeight': '100vh'
})

# Callbacks
@app.callback(
    [Output('prediction-platforms', 'value'),
     Output('traditional-platforms', 'value')],
    [Input('select-all-btn', 'n_clicks'),
     Input('deselect-all-btn', 'n_clicks'),
     Input('reset-btn', 'n_clicks')],
    prevent_initial_call=True
)
def update_platform_selection(select_all, deselect_all, reset):
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update
    
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if button_id == 'select-all-btn':
        return list(PREDICTION_MARKET_COLORS.keys()), list(TRADITIONAL_SPORTSBOOK_COLORS.keys())
    elif button_id == 'deselect-all-btn':
        return [], []
    elif button_id == 'reset-btn':
        return list(PREDICTION_MARKET_COLORS.keys()), list(TRADITIONAL_SPORTSBOOK_COLORS.keys())[:5]
    
    return dash.no_update, dash.no_update

@app.callback(
    Output('stats-summary', 'children'),
    [Input('outcome-filter', 'value'),
     Input('prediction-platforms', 'value'),
     Input('traditional-platforms', 'value')]
)
def update_stats(selected_outcomes, pred_platforms, trad_platforms):
    if not selected_outcomes:
        return html.P("Select at least one outcome to see statistics.", 
                     style={'color': '#9ca3af', 'textAlign': 'center'})
    
    stats_divs = []
    for outcome in selected_outcomes:
        outcome_data = df[df['outcome'] == outcome]
        
        outcome_stats = [html.H4(outcome, style={'color': '#1f2937', 'marginBottom': '10px'})]
        
        # Prediction markets
        if pred_platforms:
            pred_stats = []
            for platform in pred_platforms:
                if platform in outcome_data.columns:
                    data = outcome_data[platform].dropna()
                    if len(data) > 0:
                        pred_stats.append(
                            html.Div([
                                html.Strong(f"{PLATFORM_NAMES[platform]}: ", 
                                          style={'color': PREDICTION_MARKET_COLORS[platform]}),
                                html.Span(f"Mean: {data.mean():.1%} | "
                                        f"Range: {data.min():.1%} - {data.max():.1%} | "
                                        f"Std: {data.std():.2%}")
                            ], style={'marginBottom': '5px'})
                        )
            if pred_stats:
                outcome_stats.extend(pred_stats)
        
        # Traditional sportsbooks
        if trad_platforms:
            trad_stats = []
            for platform in trad_platforms:
                prob_col = platform.replace('_odds', '_prob')
                if prob_col in outcome_data.columns:
                    data = outcome_data[prob_col].dropna()
                    if len(data) > 0:
                        trad_stats.append(
                            html.Div([
                                html.Strong(f"{PLATFORM_NAMES[platform]}: ", 
                                          style={'color': TRADITIONAL_SPORTSBOOK_COLORS[platform]}),
                                html.Span(f"Mean: {data.mean():.1%} | "
                                        f"Range: {data.min():.1%} - {data.max():.1%} | "
                                        f"Std: {data.std():.2%}")
                            ], style={'marginBottom': '5px'})
                        )
            if trad_stats:
                outcome_stats.extend(trad_stats)
        
        stats_divs.append(
            html.Div(outcome_stats, style={
                'marginBottom': '20px',
                'padding': '15px',
                'backgroundColor': '#f9fafb',
                'borderRadius': '6px'
            })
        )
    
    return html.Div(stats_divs)

@app.callback(
    Output('odds-graph', 'figure'),
    [Input('view-type', 'value'),
     Input('outcome-filter', 'value'),
     Input('prediction-platforms', 'value'),
     Input('traditional-platforms', 'value'),
     Input('platform-type-filter', 'value')]
)
def update_graph(view_type, selected_outcomes, pred_platforms, trad_platforms, platform_types):
    if not selected_outcomes:
        return go.Figure().add_annotation(
            text="Please select at least one outcome",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=20, color="gray")
        )
    
    # Filter platforms by type
    if 'prediction' not in platform_types:
        pred_platforms = []
    if 'traditional' not in platform_types:
        trad_platforms = []
    
    if not pred_platforms and not trad_platforms:
        return go.Figure().add_annotation(
            text="Please select at least one platform type",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=20, color="gray")
        )
    
    if view_type == 'separate':
        return create_separate_view(selected_outcomes, pred_platforms, trad_platforms)
    elif view_type == 'combined':
        return create_combined_view(selected_outcomes, pred_platforms, trad_platforms)
    elif view_type == 'comparison':
        return create_comparison_view(selected_outcomes, pred_platforms, trad_platforms)

def create_separate_view(outcomes, pred_platforms, trad_platforms):
    """Create separate subplots for each outcome"""
    from plotly.subplots import make_subplots
    
    n_outcomes = len(outcomes)
    fig = make_subplots(
        rows=n_outcomes, cols=1,
        subplot_titles=outcomes,
        vertical_spacing=0.08,
        row_heights=[1/n_outcomes] * n_outcomes
    )
    
    for idx, outcome in enumerate(outcomes, 1):
        outcome_data = df[df['outcome'] == outcome].sort_values('datetime')
        
        # Prediction markets
        for platform in pred_platforms:
            if platform in outcome_data.columns:
                data = outcome_data[['datetime', platform]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[platform],
                            name=PLATFORM_NAMES[platform],
                            line=dict(color=PREDICTION_MARKET_COLORS[platform], width=2.5),
                            mode='lines+markers',
                            marker=dict(size=3),
                            legendgroup=platform,
                            showlegend=(idx == 1),
                            hovertemplate=f"<b>{PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        ),
                        row=idx, col=1
                    )
        
        # Traditional sportsbooks
        for platform in trad_platforms:
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[['datetime', prob_col]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[prob_col],
                            name=PLATFORM_NAMES[platform],
                            line=dict(color=TRADITIONAL_SPORTSBOOK_COLORS[platform], width=1.5),
                            mode='lines',
                            opacity=0.7,
                            legendgroup=platform,
                            showlegend=(idx == 1),
                            hovertemplate=f"<b>{PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        ),
                        row=idx, col=1
                    )
        
        # Update y-axis for each subplot
        fig.update_yaxes(
            title_text="Implied Probability",
            tickformat=".0%",
            range=[0, 1],
            row=idx, col=1
        )
        fig.update_xaxes(title_text="Time" if idx == n_outcomes else "", row=idx, col=1)
    
    fig.update_layout(
        height=400 * n_outcomes,
        hovermode='x unified',
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.01
        ),
        margin=dict(r=200)
    )
    
    return fig

def create_combined_view(outcomes, pred_platforms, trad_platforms):
    """Create combined overlay view"""
    fig = go.Figure()
    
    line_styles = {outcomes[i]: style for i, style in enumerate(['solid', 'dash', 'dot'])}
    
    for outcome in outcomes:
        outcome_data = df[df['outcome'] == outcome].sort_values('datetime')
        linestyle = line_styles.get(outcome, 'solid')
        
        # Prediction markets
        for platform in pred_platforms:
            if platform in outcome_data.columns:
                data = outcome_data[['datetime', platform]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[platform],
                            name=f"{outcome} - {PLATFORM_NAMES[platform]}",
                            line=dict(
                                color=PREDICTION_MARKET_COLORS[platform],
                                width=2.5,
                                dash=linestyle
                            ),
                            mode='lines+markers',
                            marker=dict(size=3),
                            hovertemplate=f"<b>{outcome} - {PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        )
                    )
        
        # Traditional sportsbooks
        for platform in trad_platforms:
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[['datetime', prob_col]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[prob_col],
                            name=f"{outcome} - {PLATFORM_NAMES[platform]}",
                            line=dict(
                                color=TRADITIONAL_SPORTSBOOK_COLORS[platform],
                                width=1.5,
                                dash=linestyle
                            ),
                            mode='lines',
                            opacity=0.6,
                            hovertemplate=f"<b>{outcome} - {PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        )
                    )
    
    fig.update_layout(
        height=800,
        yaxis=dict(
            title="Implied Probability",
            tickformat=".0%",
            range=[0, 1]
        ),
        xaxis=dict(title="Time"),
        hovermode='x unified',
        legend=dict(
            orientation="v",
            yanchor="top",
            y=1,
            xanchor="left",
            x=1.01
        ),
        margin=dict(r=250)
    )
    
    return fig

def create_comparison_view(outcomes, pred_platforms, trad_platforms):
    """Create platform type comparison view"""
    from plotly.subplots import make_subplots
    
    n_outcomes = len(outcomes)
    fig = make_subplots(
        rows=n_outcomes, cols=2,
        subplot_titles=[f"{outcome} - Prediction Markets" if i % 2 == 0 else f"{outcome} - Traditional Sportsbooks"
                       for outcome in outcomes for i in range(2)],
        vertical_spacing=0.08,
        horizontal_spacing=0.08,
        row_heights=[1/n_outcomes] * n_outcomes,
        column_widths=[0.5, 0.5]
    )
    
    for idx, outcome in enumerate(outcomes, 1):
        outcome_data = df[df['outcome'] == outcome].sort_values('datetime')
        
        # Left: Prediction markets
        for platform in pred_platforms:
            if platform in outcome_data.columns:
                data = outcome_data[['datetime', platform]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[platform],
                            name=PLATFORM_NAMES[platform],
                            line=dict(color=PREDICTION_MARKET_COLORS[platform], width=3),
                            mode='lines+markers',
                            marker=dict(size=4),
                            legendgroup=f"pred_{platform}",
                            showlegend=(idx == 1),
                            hovertemplate=f"<b>{PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        ),
                        row=idx, col=1
                    )
        
        # Right: Traditional sportsbooks
        for platform in trad_platforms:
            prob_col = platform.replace('_odds', '_prob')
            if prob_col in outcome_data.columns:
                data = outcome_data[['datetime', prob_col]].dropna()
                if len(data) > 0:
                    fig.add_trace(
                        go.Scatter(
                            x=data['datetime'],
                            y=data[prob_col],
                            name=PLATFORM_NAMES[platform],
                            line=dict(color=TRADITIONAL_SPORTSBOOK_COLORS[platform], width=2),
                            mode='lines',
                            opacity=0.8,
                            legendgroup=f"trad_{platform}",
                            showlegend=(idx == 1),
                            hovertemplate=f"<b>{PLATFORM_NAMES[platform]}</b><br>" +
                                        "Time: %{x|%H:%M:%S}<br>" +
                                        "Probability: %{y:.2%}<extra></extra>"
                        ),
                        row=idx, col=2
                    )
        
        # Update axes
        fig.update_yaxes(title_text="Probability", tickformat=".0%", range=[0, 1], row=idx, col=1)
        fig.update_yaxes(title_text="Probability", tickformat=".0%", range=[0, 1], row=idx, col=2)
        if idx == n_outcomes:
            fig.update_xaxes(title_text="Time", row=idx, col=1)
            fig.update_xaxes(title_text="Time", row=idx, col=2)
    
    fig.update_layout(
        height=400 * n_outcomes,
        hovermode='x unified',
        margin=dict(r=50)
    )
    
    return fig

if __name__ == '__main__':
    print("\n" + "="*80)
    print("🚀 Starting Interactive Odds Dashboard")
    print("="*80)
    print(f"📂 Data file: {csv_file}")
    print(f"📊 Outcomes: {', '.join(outcomes)}")
    print(f"🌐 Opening dashboard at: http://localhost:8050")
    print("="*80)
    print("\n💡 Features:")
    print("  • Interactive zooming and panning")
    print("  • Hover for detailed information")
    print("  • Filter by outcomes and platforms")
    print("  • Multiple view types")
    print("  • Export graphs as PNG")
    print("\n⌨️  Press Ctrl+C to stop the server\n")
    
    app.run(debug=True, host='0.0.0.0', port=8050)

