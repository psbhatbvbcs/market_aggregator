import json
import csv

# Input and output file paths
input_file = "arbitrage_executions.jsonl"     # your input JSONL file
output_file = "arbitrage_data.csv"      # desired CSV file

# Open input JSONL and output CSV
with open(input_file, "r") as infile, open(output_file, "w", newline="") as outfile:
    writer = csv.writer(outfile)

    # Write CSV header
    writer.writerow([
        "timestamp",
        "first_trade_exchange",
        "second_trade_exchange",
        "arbitrage_type",
        "home_win_price",
        "away_win_price"
    ])

    # Process each JSON object line by line
    for line in infile:
        if not line.strip():
            continue  # skip empty lines

        data = json.loads(line)
        arb = data.get("arbitrage", {})

        # Extract the fields
        timestamp = data.get("timestamp")
        arbitrage_type = arb.get("type", "")
        home = arb.get("home_win", {})
        away = arb.get("away_win", {})
        first_trade_exchange = home.get("exchange", "")
        second_trade_exchange = away.get("exchange", "")
        home_win_price = home.get("price", "")
        away_win_price = away.get("price", "")

        # Write row
        writer.writerow([
            timestamp,
            first_trade_exchange,
            second_trade_exchange,
            arbitrage_type,
            home_win_price,
            away_win_price
        ])

print(f"✅ CSV successfully created: {output_file}")
