import requests
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
from py_clob_client.client import ClobClient
import logging

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Configuration - use your existing credentials
KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
POLYMARKET_CLOB = "https://clob.polymarket.com"
POLYMARKET_DATA = "https://data-api.polymarket.com"

# Your credentials (from your bot)
API_KEY_ID = "39bb4b72-782d-432e-84e6-f228d2e4703d"
PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692B
gGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2lj
z4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1E
X8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u8
8DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eru
M1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUk
xxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5
F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPp
oLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb
778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3d
OygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobf
KQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1
uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJ
WvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jza
lm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5
qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI
1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6
c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4
eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCw
GsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8
R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa
98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoe
dYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxO
Fmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX
3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo
-----END RSA PRIVATE KEY-----"""

POLYMARKET_PRIVATE_KEY = "0xb0240ca09fd5169f06f95655788ef9f8e9f6b73dc4242721903b540c81635d7a"
POLYMARKET_FUNDER = "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
CHAIN_ID = 137

# Target game identifiers
KALSHI_SLUG = "kxnflgame-25oct12dalcar"
POLYMARKET_SLUG = "nfl-dal-car-2025-10-12"


class KalshiAuth:
    def __init__(self, api_key_id: str, private_key_pem: str):
        self.api_key_id = api_key_id
        self.private_key = self._load_private_key(private_key_pem)

    def _load_private_key(self, key_pem: str):
        return serialization.load_pem_private_key(
            key_pem.encode('utf-8'),
            password=None,
            backend=default_backend()
        )

    def create_signature(self, timestamp: str, method: str, path: str) -> str:
        message = f"{timestamp}{method}{path}".encode('utf-8')
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH
            ),
            hashes.SHA256()
        )
        return base64.b64encode(signature).decode('utf-8')

    def get_auth_headers(self, method: str, path: str) -> Dict[str, str]:
        timestamp = str(int(datetime.now().timestamp() * 1000))
        signature = self.create_signature(timestamp, method, path)

        return {
            'KALSHI-ACCESS-KEY': self.api_key_id,
            'KALSHI-ACCESS-SIGNATURE': signature,
            'KALSHI-ACCESS-TIMESTAMP': timestamp
        }


def fetch_kalshi_trades_comprehensive(auth: KalshiAuth, event_ticker: str) -> List[Dict]:
    """Fetch all orders for a specific Kalshi event with comprehensive debugging"""
    trades = []
    all_orders_debug = []

    try:
        # First, get all markets for this event
        logger.info(f"Fetching markets for event: {event_ticker}")
        headers = auth.get_auth_headers("GET", f"/trade-api/v2/markets")
        response = requests.get(
            f"{KALSHI_BASE}/markets",
            headers=headers,
            params={"event_ticker": event_ticker.upper(), "limit": 100},
            timeout=10
        )

        if response.status_code != 200:
            logger.error(f"Failed to get markets: {response.status_code} - {response.text}")
            return trades

        markets = response.json().get("markets", [])
        market_tickers = [m["ticker"] for m in markets]
        logger.info(f"Found {len(market_tickers)} markets: {market_tickers}")

        # Map tickers to team names
        ticker_to_team = {}
        for market in markets:
            ticker = market["ticker"]
            title = market.get("title", "")
            logger.info(f"Market: {ticker} - {title}")

            # Extract team from ticker or title
            if "DAL" in ticker.upper() or "Dallas" in title or "Cowboys" in title:
                ticker_to_team[ticker] = "Dallas Cowboys"
            elif "CAR" in ticker.upper() or "Carolina" in title or "Panthers" in title:
                ticker_to_team[ticker] = "Carolina Panthers"

        # Try getting ALL orders first (not just executed)
        logger.info("Fetching ALL orders from portfolio...")
        headers = auth.get_auth_headers("GET", "/trade-api/v2/portfolio/orders")

        # Try without status filter first
        response = requests.get(
            f"{KALSHI_BASE}/portfolio/orders",
            headers=headers,
            params={"limit": 1000},
            timeout=10
        )

        if response.status_code != 200:
            logger.error(f"Failed to get orders: {response.status_code} - {response.text}")
        else:
            all_orders = response.json().get("orders", [])
            logger.info(f"Total orders found: {len(all_orders)}")

            # Debug: Show all orders for this game
            for order in all_orders:
                if order.get("ticker") in market_tickers:
                    all_orders_debug.append({
                        "ticker": order.get("ticker"),
                        "status": order.get("status"),
                        "action": order.get("action"),
                        "side": order.get("side"),
                        "order_count": order.get("order_count"),
                        "filled_count": order.get("filled_count"),
                        "remaining_count": order.get("remaining_count"),
                        "created_time": order.get("created_time")
                    })

                    # DON'T create trades here - wait for fills data which has correct prices

        # Also try getting fills endpoint - THIS IS THE PRIMARY DATA SOURCE
        logger.info("Trying portfolio fills endpoint...")
        headers = auth.get_auth_headers("GET", "/trade-api/v2/portfolio/fills")
        response = requests.get(
            f"{KALSHI_BASE}/portfolio/fills",
            headers=headers,
            params={"limit": 1000},
            timeout=10
        )

        if response.status_code == 200:
            fills = response.json().get("fills", [])
            logger.info(f"Found {len(fills)} fills total")

            # Process fills directly - don't rely on orders endpoint
            fills_for_game = []
            for fill in fills:
                if fill.get("ticker") in market_tickers:
                    logger.info(f"Fill for our game: {fill}")
                    fills_for_game.append(fill)

            # Group fills by order_id to aggregate
            fills_by_order = {}
            for fill in fills_for_game:
                order_id = fill.get("order_id")
                if order_id:
                    if order_id not in fills_by_order:
                        fills_by_order[order_id] = []
                    fills_by_order[order_id].append(fill)

            # Create trades directly from fills data
            logger.info(f"Creating trades from {len(fills_by_order)} unique orders with fills")
            for order_id, order_fills in fills_by_order.items():
                # Aggregate all fills for this order
                total_count = sum(f.get("count", 0) for f in order_fills)

                # Get the first fill to extract order details
                first_fill = order_fills[0]
                ticker = first_fill.get("ticker")
                side = first_fill.get("side")
                action = first_fill.get("action")

                # Calculate weighted average price
                total_cost = 0
                for f in order_fills:
                    count = f.get("count", 0)
                    # Use the actual price field from the fill
                    price = f.get("price", 0)
                    total_cost += count * price

                avg_price = total_cost / total_count if total_count > 0 else 0

                trade = {
                    "exchange": "kalshi",
                    "order_id": order_id,
                    "ticker": ticker,
                    "team": ticker_to_team.get(ticker, "Unknown"),
                    "side": side,
                    "action": action,
                    "filled_count": total_count,
                    "execution_price": avg_price,
                    "yes_price": first_fill.get("yes_price", 0) / 100.0 if first_fill.get("yes_price") else None,
                    "no_price": first_fill.get("no_price", 0) / 100.0 if first_fill.get("no_price") else None,
                    "created_time": first_fill.get("created_time"),
                    "fills": order_fills,
                    "num_fills": len(order_fills),
                    "note": "Created from fills data"
                }
                trades.append(trade)

    except Exception as e:
        logger.error(f"Error fetching Kalshi trades: {e}")

    # Debug output
    if all_orders_debug:
        logger.info("\nDEBUG - All orders for this game:")
        for order in all_orders_debug:
            logger.info(f"  {order}")

    return trades


def fetch_polymarket_trades_comprehensive(private_key: str, funder: str, slug: str) -> List[Dict]:
    """Fetch all orders for a specific Polymarket market with comprehensive debugging"""
    trades = []
    all_orders_debug = []

    try:
        # Initialize Polymarket client
        client = ClobClient(
            POLYMARKET_CLOB,
            key=private_key,
            chain_id=CHAIN_ID,
            signature_type=1,
            funder=funder
        )

        client.set_api_creds(client.create_or_derive_api_creds())
        api_creds = client.derive_api_key()

        # Get market info first
        logger.info(f"Fetching market info for: {slug}")
        resp = requests.get(f"https://gamma-api.polymarket.com/markets?slug={slug}", timeout=10)

        token_to_team = {}
        token_ids = []

        if resp.status_code == 200:
            markets = resp.json()
            if isinstance(markets, list) and len(markets) > 0:
                market = markets[0]
                outcomes = market.get('outcomes', [])
                clob_token_ids = market.get('clobTokenIds', [])

                # Parse outcomes and token IDs
                import ast
                if isinstance(outcomes, str):
                    try:
                        outcomes = json.loads(outcomes)
                    except:
                        outcomes = ast.literal_eval(outcomes)
                if isinstance(clob_token_ids, str):
                    try:
                        clob_token_ids = json.loads(clob_token_ids)
                    except:
                        clob_token_ids = ast.literal_eval(clob_token_ids)

                logger.info(f"Market outcomes: {outcomes}")
                logger.info(f"Token IDs: {clob_token_ids}")

                # Map token IDs to teams
                for i, outcome in enumerate(outcomes):
                    if i < len(clob_token_ids):
                        token_id = str(clob_token_ids[i])
                        token_ids.append(token_id)
                        if "Dallas" in outcome or "Cowboys" in outcome or "DAL" in outcome:
                            token_to_team[token_id] = "Dallas Cowboys"
                        elif "Carolina" in outcome or "Panthers" in outcome or "CAR" in outcome:
                            token_to_team[token_id] = "Carolina Panthers"

        # Method 1: Try using the client's get_orders
        logger.info("Method 1: Fetching orders via py-clob-client...")
        try:
            orders = client.get_orders()
            logger.info(f"Found {len(orders) if orders else 0} orders via client")

            if orders:
                for order in orders:
                    if isinstance(order, dict):
                        token_id = order.get("asset_id", order.get("token_id"))
                        if token_id in token_ids:
                            all_orders_debug.append({
                                "token_id": token_id,
                                "status": order.get("status"),
                                "side": order.get("side"),
                                "size": order.get("size"),
                                "size_matched": order.get("size_matched"),
                                "price": order.get("price")
                            })

                            size_matched = float(order.get("size_matched", 0))
                            if size_matched > 0:
                                trades.append({
                                    "exchange": "polymarket",
                                    "order_id": order.get("id", order.get("order_id")),
                                    "token_id": token_id,
                                    "team": token_to_team.get(token_id, "Unknown"),
                                    "side": order.get("side"),
                                    "size_matched": size_matched,
                                    "original_size": float(order.get("original_size", order.get("size", 0))),
                                    "price": float(order.get("price", 0)),
                                    "execution_price": float(order.get("price", 0)),
                                    "status": order.get("status"),
                                    "created_at": order.get("created_at")
                                })
        except Exception as e:
            logger.error(f"Error in Method 1: {e}")

        # Method 2: Direct API call to get orders
        logger.info("Method 2: Direct API call to CLOB...")
        try:
            headers = {
                "POLY-API-KEY": api_creds.api_key,
                "POLY-API-SECRET": api_creds.api_secret,
                "POLY-API-PASSPHRASE": api_creds.api_passphrase
            }

            # Try getting orders for each token
            for token_id in token_ids:
                url = f"{POLYMARKET_CLOB}/orders?asset_id={token_id}"
                response = requests.get(url, headers=headers, timeout=10)

                if response.status_code == 200:
                    orders = response.json()
                    logger.info(f"Found {len(orders)} orders for token {token_id}")

                    for order in orders:
                        all_orders_debug.append({
                            "token_id": token_id,
                            "order_id": order.get("id"),
                            "status": order.get("status"),
                            "side": order.get("side"),
                            "size": order.get("size"),
                            "size_matched": order.get("size_matched")
                        })
        except Exception as e:
            logger.error(f"Error in Method 2: {e}")

        # Method 3: Try data-api for historical trades and positions
        logger.info("Method 3: Checking data-api for trades and positions...")
        try:
            # First get positions
            url = f"{POLYMARKET_DATA}/positions"
            params = {"user": funder.lower()}
            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                positions = response.json()
                logger.info(f"Found {len(positions)} positions")

                # Debug: Show all positions to understand the data structure
                for i, position in enumerate(positions[:3]):  # Show first 3 for debugging
                    logger.info(f"Position {i}: {position}")

                # Check positions for our market - be more flexible with matching
                for position in positions:
                    # Try multiple ways to match the position to our market
                    asset_id = position.get("asset_id")
                    market_slug = position.get("market_slug", "")
                    outcome = position.get("outcome", "")

                    # Check if this position is for our game
                    is_our_market = False

                    # Method 1: Check by token ID
                    if asset_id in token_ids:
                        is_our_market = True
                        logger.info(f"Matched position by token ID: {asset_id}")

                    # Method 2: Check by market slug
                    elif slug.lower() in market_slug.lower() or market_slug.lower() in slug.lower():
                        is_our_market = True
                        logger.info(f"Matched position by market slug: {market_slug}")

                    # Method 3: Check if it's Cowboys vs Panthers
                    elif ("cowboys" in outcome.lower() or "dal" in outcome.lower() or
                          "panthers" in outcome.lower() or "car" in outcome.lower()):
                        # Additional check for date
                        if "2025-10-12" in str(position):
                            is_our_market = True
                            logger.info(f"Matched position by team names and date: {outcome}")

                    if is_our_market:
                        logger.info(f"Position in our market: {position}")

                        # Create trade entry from position data
                        total_quantity = float(position.get("total_quantity", 0))

                        if total_quantity > 0:
                            # Determine team based on outcome
                            team = "Unknown"
                            if "cowboys" in outcome.lower() or "dal" in outcome.lower():
                                team = "Dallas Cowboys"
                            elif "panthers" in outcome.lower() or "car" in outcome.lower():
                                team = "Carolina Panthers"

                            trades.append({
                                "exchange": "polymarket",
                                "position_id": position.get("id"),
                                "token_id": asset_id,
                                "team": team,
                                "outcome": outcome,
                                "side": "BUY",
                                "total_quantity": total_quantity,
                                "realized_pnl": float(position.get("realized_pnl", 0)),
                                "initial_value": float(position.get("initial_value", 0)),
                                "current_value": float(position.get("current_value", 0)),
                                "execution_price": float(position.get("initial_value", 0)) / total_quantity if total_quantity > 0 else 0,
                                "created_at": position.get("created_at"),
                                "updated_at": position.get("updated_at"),
                                "market_slug": market_slug,
                                "note": "Created from positions endpoint"
                            })

            # Also try getting trades directly
            logger.info("Fetching trades from data-api...")
            url = f"{POLYMARKET_DATA}/trades"
            params = {"user": funder.lower(), "limit": 1000}
            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                trades_data = response.json()
                logger.info(f"Found {len(trades_data)} total trades")

                # Debug: Show a sample trade
                if trades_data:
                    logger.info(f"Sample trade structure: {trades_data[0]}")

                for trade_item in trades_data:
                    # More flexible matching for trades
                    asset_id = trade_item.get("asset_id")
                    market_slug = trade_item.get("market_slug", "")
                    outcome = trade_item.get("outcome", "")

                    is_our_market = False

                    # Check multiple ways to match
                    if asset_id in token_ids:
                        is_our_market = True
                    elif slug.lower() in market_slug.lower():
                        is_our_market = True
                    elif ("cowboys" in str(trade_item).lower() or "panthers" in str(trade_item).lower()) and "2025-10-12" in str(trade_item):
                        is_our_market = True

                    if is_our_market:
                        logger.info(f"Trade in our market: {trade_item}")

                        # Determine team
                        team = "Unknown"
                        if "cowboys" in outcome.lower() or "dal" in outcome.lower():
                            team = "Dallas Cowboys"
                        elif "panthers" in outcome.lower() or "car" in outcome.lower():
                            team = "Carolina Panthers"

                        trades.append({
                            "exchange": "polymarket",
                            "trade_id": trade_item.get("id"),
                            "order_id": trade_item.get("order_id"),
                            "token_id": asset_id,
                            "team": team,
                            "outcome": outcome,
                            "side": trade_item.get("side"),
                            "size": float(trade_item.get("size", 0)),
                            "price": float(trade_item.get("price", 0)),
                            "execution_price": float(trade_item.get("price", 0)),
                            "fee": float(trade_item.get("fee", 0)),
                            "timestamp": trade_item.get("timestamp"),
                            "market_slug": market_slug,
                            "note": "Created from trades endpoint"
                        })

        except Exception as e:
            logger.error(f"Error in Method 3: {e}")
            import traceback
            logger.error(traceback.format_exc())

    except Exception as e:
        logger.error(f"Error fetching Polymarket trades: {e}")

    # Debug output
    if all_orders_debug:
        logger.info("\nDEBUG - All Polymarket orders found:")
        for order in all_orders_debug:
            logger.info(f"  {order}")

    return trades


def main():
    logger.info("="*80)
    logger.info("COMPREHENSIVE TRADE HISTORY FETCHER")
    logger.info("Game: Dallas Cowboys vs Carolina Panthers (Oct 12, 2025)")
    logger.info("="*80)

    # Initialize Kalshi auth
    kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)

    # Fetch trades from both exchanges with comprehensive debugging
    logger.info(f"\nFetching Kalshi trades for {KALSHI_SLUG}...")
    logger.info("-"*60)
    kalshi_trades = fetch_kalshi_trades_comprehensive(kalshi_auth, KALSHI_SLUG)
    logger.info(f"Result: Found {len(kalshi_trades)} Kalshi trades with fills")

    logger.info(f"\nFetching Polymarket trades for {POLYMARKET_SLUG}...")
    logger.info("-"*60)
    polymarket_trades = fetch_polymarket_trades_comprehensive(
        POLYMARKET_PRIVATE_KEY,
        POLYMARKET_FUNDER,
        POLYMARKET_SLUG
    )
    logger.info(f"Result: Found {len(polymarket_trades)} Polymarket trades with fills")

    # Combine all trades
    all_trades = {
        "game": {
            "kalshi_event": KALSHI_SLUG,
            "polymarket_slug": POLYMARKET_SLUG,
            "home_team": "Dallas Cowboys",
            "away_team": "Carolina Panthers",
            "date": "2025-10-12"
        },
        "summary": {
            "total_kalshi_trades": len(kalshi_trades),
            "total_polymarket_trades": len(polymarket_trades),
            "total_trades": len(kalshi_trades) + len(polymarket_trades)
        },
        "kalshi_trades": kalshi_trades,
        "polymarket_trades": polymarket_trades,
        "timestamp": datetime.now().isoformat()
    }

    # Calculate totals
    kalshi_total_volume = 0
    for t in kalshi_trades:
        filled = t.get("filled_count", 0)
        if filled is None:
            filled = 10  # Default estimate for None values
        price = t.get("execution_price", 0)
        if price is None:
            price = 0
        volume = filled * price
        kalshi_total_volume += volume

    poly_total_volume = 0
    for t in polymarket_trades:
        size = t.get("size_matched", 0)
        if size is None:
            size = 0
        price = t.get("execution_price", 0)
        if price is None:
            price = 0
        volume = size * price
        poly_total_volume += volume

    all_trades["summary"]["kalshi_total_volume"] = round(kalshi_total_volume, 2)
    all_trades["summary"]["polymarket_total_volume"] = round(poly_total_volume, 2)
    all_trades["summary"]["total_volume"] = round(kalshi_total_volume + poly_total_volume, 2)

    # Save to JSON file
    output_filename = f"trades_{KALSHI_SLUG}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_filename, 'w') as f:
        json.dump(all_trades, f, indent=2, default=str)

    logger.info(f"\nTrade history saved to {output_filename}")

    # Print summary
    print("\n" + "="*80)
    print("TRADE EXECUTION SUMMARY")
    print("="*80)
    print(f"Game: Dallas Cowboys vs Carolina Panthers (Oct 12, 2025)")
    print(f"Kalshi Event: {KALSHI_SLUG}")
    print(f"Polymarket: {POLYMARKET_SLUG}")
    print("-"*80)
    print(f"Total Kalshi Trades: {len(kalshi_trades)}")
    print(f"Total Polymarket Trades: {len(polymarket_trades)}")
    print(f"Total Volume: ${all_trades['summary']['total_volume']:.2f}")
    print("="*80)

    # Print individual trades if found
    if kalshi_trades:
        print("\nKALSHI TRADES:")
        for trade in kalshi_trades:
            order_id = trade.get('order_id', 'unknown')
            if len(order_id) > 8:
                order_id_display = f"{order_id[:8]}..."
            else:
                order_id_display = order_id

            print(f"  - Order {order_id_display}")
            print(f"    {trade['team']} {trade['side'].upper()} @ ${trade['execution_price']:.3f}")
            print(f"    Filled: {trade['filled_count']} shares")

            if 'action' in trade:
                print(f"    Action: {trade['action'].upper()}")
            if 'num_fills' in trade:
                print(f"    Fills: {trade['num_fills']} separate fills")
            if 'created_time' in trade:
                print(f"    Time: {trade['created_time']}")
    else:
        print("\nNo Kalshi trades with fills found.")
        print("Check the debug output above to see if there are pending/resting orders.")

    if polymarket_trades:
        print("\nPOLYMARKET TRADES:")
        for trade in polymarket_trades:
            # Handle different trade structures from different endpoints
            if 'order_id' in trade and trade['order_id']:
                order_id = str(trade['order_id'])
                if len(order_id) > 8:
                    order_id_display = f"{order_id[:8]}..."
                else:
                    order_id_display = order_id
                print(f"  - Order {order_id_display}")
            elif 'trade_id' in trade and trade['trade_id']:
                trade_id = str(trade['trade_id'])
                if len(trade_id) > 8:
                    trade_id_display = f"{trade_id[:8]}..."
                else:
                    trade_id_display = trade_id
                print(f"  - Trade {trade_id_display}")
            elif 'position_id' in trade and trade['position_id']:
                position_id = str(trade['position_id'])
                if len(position_id) > 8:
                    position_id_display = f"{position_id[:8]}..."
                else:
                    position_id_display = position_id
                print(f"  - Position {position_id_display}")
            else:
                print(f"  - Trade (no ID)")

            team = trade.get('team', trade.get('outcome', 'Unknown'))
            side = trade.get('side', 'BUY')
            price = trade.get('execution_price', trade.get('price', 0))

            print(f"    {team} {side} @ ${price:.3f}")

            # Handle different quantity fields
            if 'size_matched' in trade:
                print(f"    Filled: {trade['size_matched']:.2f} shares")
            elif 'size' in trade:
                print(f"    Size: {trade['size']:.2f} shares")
            elif 'total_quantity' in trade:
                print(f"    Total Quantity: {trade['total_quantity']:.2f} shares")

            if 'timestamp' in trade:
                print(f"    Time: {trade['timestamp']}")
            elif 'created_at' in trade:
                print(f"    Time: {trade['created_at']}")
    else:
        print("\nNo Polymarket trades with fills found.")
        print("Check the debug output above to see if there are pending orders.")

    return all_trades


if __name__ == "__main__":
    trades = main()
