import requests
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Tuple
import re

class SportsMarketSlugFinder:
    def __init__(self):
        self.kalshi_base = "https://api.elections.kalshi.com/trade-api/v2"
        self.polymarket_gamma = "https://gamma-api.polymarket.com"

        self.league_mappings = {
            "nfl": {
                "kalshi_prefix": "kxnflgame",
                "kalshi_category": "professional-football-game",
                "polymarket_prefix": "nfl"
            },
            "cfb": {
                "kalshi_prefix": "kxncaafgame",
                "kalshi_category": "college-football-game",
                "polymarket_prefix": "cfb"
            },
            "mlb": {
                "kalshi_prefix": "kxmlbgame",
                "kalshi_category": "professional-baseball-game",
                "polymarket_prefix": "mlb"
            },
            "epl": {
                "kalshi_prefix": "kxeplgame",
                "kalshi_category": "english-premier-league-game",
                "polymarket_prefix": "epl"
            },
            "serie a": {
                "kalshi_prefix": "kxserieagame",
                "kalshi_category": "serie-a-game",
                "polymarket_prefix": "sea"
            },
            "bundesliga": {
                "kalshi_prefix": "kxbundesligagame",
                "kalshi_category": "bundesliga-game",
                "polymarket_prefix": "bun"
            },
            "la liga": {
                "kalshi_prefix": "kxlaligagame",
                "kalshi_category": "la-liga-game",
                "polymarket_prefix": "lal"
            },
            "ligue 1": {
                "kalshi_prefix": "kxligue1game",
                "kalshi_category": "ligue-1-game",
                "polymarket_prefix": "fl1"
            },
            "champions league": {
                "kalshi_prefix": "kxuclgame",
                "kalshi_category": "uefa-champions-league-game",
                "polymarket_prefix": "ucl"
            }
        }

        self.team_abbreviations = {
            "san francisco": ["sf", "sfo", "sfr"],
            "los angeles": ["la", "lax", "lar"],
            "boston": ["bos", "bst"],
            "new york": ["ny", "nyc", "nyy"],
            "charlotte": ["char", "charl", "cha"],
            "south florida": ["sfl", "usf", "sfl"],
            "hoffenheim": ["hof", "tsg"],
            "koln": ["koe", "col", "fckoln"],
            "leeds": ["lee", "leed", "leedsutd"],
            "tottenham": ["tot", "thfc", "spurs"],
            "osasuna": ["osa", "osasu"],
            "getafe": ["get", "geta", "gtfe"],
            "paris": ["par", "psg", "pfc"],
            "lorient": ["lor", "fcl"],
            "verona": ["ver", "vero", "hellas"],
            "sassuolo": ["sas", "sass"]
        }

    def normalize_team_name(self, team_name: str) -> List[str]:
        team_name_lower = team_name.lower().strip()

        for full_name, abbrevs in self.team_abbreviations.items():
            if full_name in team_name_lower:
                return abbrevs
            for abbrev in abbrevs:
                if abbrev == team_name_lower:
                    return abbrevs

        parts = team_name_lower.split()
        if len(parts) > 1:
            return [parts[0][:3], parts[-1][:3], ''.join([p[0] for p in parts])]
        else:
            return [team_name_lower[:3], team_name_lower[:4]]

    def get_kalshi_slug(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Optional[str]:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]

        try:
            response = requests.get(
                f"{self.kalshi_base}/events",
                params={
                    "status": "open",
                    "limit": 200,
                    "with_nested_markets": "false"
                },
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                events = data.get("events", [])
                team1_variants = self.normalize_team_name(team1)
                team2_variants = self.normalize_team_name(team2)

                for event in events:
                    event_ticker = event.get("event_ticker", "").lower()

                    if league_info["kalshi_prefix"] in event_ticker:
                        matches_found = 0
                        for t1_var in team1_variants:
                            if t1_var in event_ticker:
                                matches_found += 1
                                break
                        for t2_var in team2_variants:
                            if t2_var in event_ticker:
                                matches_found += 1
                                break

                        if matches_found == 2:
                            return f"https://kalshi.com/markets/{league_info['kalshi_prefix']}/{league_info['kalshi_category']}/{event_ticker}"

            if game_date:
                date_str = game_date.strftime("%y%b%d").lower()
                team1_abbrev = self.normalize_team_name(team1)[0]
                team2_abbrev = self.normalize_team_name(team2)[0]

                possible_slugs = [
                    f"{league_info['kalshi_prefix']}-{date_str}{team1_abbrev}{team2_abbrev}",
                    f"{league_info['kalshi_prefix']}-{date_str}{team2_abbrev}{team1_abbrev}"
                ]

                for slug in possible_slugs:
                    return f"https://kalshi.com/markets/{league_info['kalshi_prefix']}/{league_info['kalshi_category']}/{slug}"

        except Exception as e:
            print(f"Error fetching Kalshi data: {e}")

        return None

    def get_polymarket_slug(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Optional[str]:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]

        try:
            response = requests.get(
                f"{self.polymarket_gamma}/markets",
                params={
                    "active": "true",
                    "closed": "false",
                    "limit": 100
                },
                timeout=10
            )

            if response.status_code == 200:
                markets = response.json()

                team1_lower = team1.lower()
                team2_lower = team2.lower()

                for market in markets:
                    slug = market.get("slug", "").lower()
                    title = market.get("question", "").lower()

                    if league_info["polymarket_prefix"] in slug:
                        if (team1_lower in title or team2_lower in title) or \
                           (any(t in slug for t in self.normalize_team_name(team1)) and \
                            any(t in slug for t in self.normalize_team_name(team2))):
                            return f"https://polymarket.com/event/{slug}"

            if game_date:
                date_str = game_date.strftime("%Y-%m-%d")
                team1_abbrev = self.normalize_team_name(team1)[0]
                team2_abbrev = self.normalize_team_name(team2)[0]

                possible_slugs = [
                    f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}",
                    f"{league_info['polymarket_prefix']}-{team2_abbrev}-{team1_abbrev}-{date_str}"
                ]

                for slug in possible_slugs:
                    return f"https://polymarket.com/event/{slug}"

        except Exception as e:
            print(f"Error fetching Polymarket data: {e}")

        return None

    def find_market_slugs(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict[str, Optional[str]]:
        result = {
            "kalshi": self.get_kalshi_slug(team1, team2, league, game_date),
            "polymarket": self.get_polymarket_slug(team1, team2, league, game_date)
        }

        return result

    def batch_find_markets(self, games: List[Dict]) -> List[Dict]:
        results = []

        for game in games:
            team1 = game.get("team1")
            team2 = game.get("team2")
            league = game.get("league")
            game_date = game.get("date")

            if isinstance(game_date, str):
                try:
                    game_date = datetime.strptime(game_date, "%Y-%m-%d")
                except:
                    game_date = None

            slugs = self.find_market_slugs(team1, team2, league, game_date)

            results.append({
                "game": f"{team1} vs {team2}",
                "league": league,
                "date": game_date.strftime("%Y-%m-%d") if game_date else "N/A",
                "kalshi_url": slugs["kalshi"] or "Not found",
                "polymarket_url": slugs["polymarket"] or "Not found"
            })

        return results

finder = SportsMarketSlugFinder()

# def main():
#     finder = SportsMarketSlugFinder()

#     test_games = [
#         {"team1": "San Francisco", "team2": "Los Angeles", "league": "NFL", "date": "2025-10-02"},
#         {"team1": "Charlotte", "team2": "South Florida", "league": "CFB", "date": "2025-10-03"},
#         {"team1": "Boston", "team2": "New York Yankees", "league": "MLB", "date": "2025-09-30"},
#         {"team1": "Hoffenheim", "team2": "Koln", "league": "Bundesliga", "date": "2025-10-03"},
#         {"team1": "Leeds", "team2": "Tottenham", "league": "EPL", "date": "2025-10-04"},
#         {"team1": "Osasuna", "team2": "Getafe", "league": "La Liga", "date": "2025-10-03"},
#         {"team1": "Paris", "team2": "Lorient", "league": "Ligue 1", "date": "2025-10-03"},
#         {"team1": "Verona", "team2": "Sassuolo", "league": "Serie A", "date": "2025-10-03"}
#     ]

#     results = finder.batch_find_markets(test_games)

#     print("\n" + "="*100)
#     print("="*100)

#     for result in results:
#         print(f"\n{result['game']} ({result['league']}) - {result['date']}")
#         print(f"Kalshi:     {result['kalshi_url']}")
#         print(f"Polymarket: {result['polymarket_url']}")
#         print("-"*100)

#     print("="*100)
#     while True:
#         print("\nEnter game details (or 'quit' to exit):")
#         team1 = input("Team 1: ").strip()
#         if team1.lower() == 'quit':
#             break
#         team2 = input("Team 2: ").strip()
#         league = input("League (NFL/CFB/MLB/EPL/Serie A/Bundesliga/La Liga/Ligue 1/Champions League): ").strip()
#         date_str = input("Date (YYYY-MM-DD) or press Enter to skip: ").strip()

#         game_date = None
#         if date_str:
#             try:
#                 game_date = datetime.strptime(date_str, "%Y-%m-%d")
#             except:
#                 print("Invalid date format, proceeding without date")

#         slugs = finder.find_market_slugs(team1, team2, league, game_date)

#         print(f"\nResults for {team1} vs {team2} ({league}):")
#         print(f"Kalshi:     {slugs['kalshi'] or 'Not found'}")
#         print(f"Polymarket: {slugs['polymarket'] or 'Not found'}")


# if __name__ == "__main__":
#     main()