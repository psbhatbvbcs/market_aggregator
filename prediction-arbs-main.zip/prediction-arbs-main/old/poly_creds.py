from py_clob_client.client import ClobClient
from py_clob_client.clob_types import BookParams
from py_clob_client.clob_types import ApiCreds, MarketOrderArgs, OrderType, OrderArgs
from py_clob_client.clob_types import ApiCreds, OrderArgs, PostOrdersArgs, OrderType, OpenOrderParams
import requests
import time
import json
import csv, os, datetime
import ast
import asyncio
import websockets
import threading
from collections import defaultdict

HOST = "https://clob.polymarket.com"
CHAIN_ID = 137
PRIVATE_KEY = "0xb0240ca09fd5169f06f95655788ef9f8e9f6b73dc4242721903b540c81635d7a"
FUNDER = "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
POLYMARKET_WSS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/"

client = ClobClient(
    HOST,
    key=PRIVATE_KEY,
    chain_id=CHAIN_ID,
    signature_type=1,
    funder=FUNDER
)
client.set_api_creds(client.create_or_derive_api_creds())
api_creds = client.derive_api_key()
print(api_creds.api_key)
print(api_creds.api_secret)
print(api_creds.api_passphrase)