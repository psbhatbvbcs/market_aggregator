import requests
import asyncio
import websockets
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import threading
from collections import defaultdict
import re
import ast
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
KALSHI_WSS = "wss://api.elections.kalshi.com/trade-api/ws/v2"
POLYMARKET_GAMMA = "https://gamma-api.polymarket.com"
POLYMARKET_CLOB = "https://clob.polymarket.com"

prices = {
    'kalshi': {
        'home_yes': {'price': 0, 'size': 0},
        'home_no': {'price': 0, 'size': 0},
        'away_yes': {'price': 0, 'size': 0},
        'away_no': {'price': 0, 'size': 0},
        'tie_yes': {'price': 0, 'size': 0},
        'tie_no': {'price': 0, 'size': 0}
    },
    'polymarket': {
        'home_yes': {'price': 0, 'size': 0},
        'home_no': {'price': 0, 'size': 0},
        'away_yes': {'price': 0, 'size': 0},
        'away_no': {'price': 0, 'size': 0},
        'tie_yes': {'price': 0, 'size': 0},
        'tie_no': {'price': 0, 'size': 0}
    }
}
price_lock = threading.Lock()
last_update = {'kalshi': datetime.now(), 'polymarket': datetime.now()}


class JSONLWriter:
    def __init__(self, filename: str):
        self.file = open(filename, 'a')

    def write(self, obj: dict) -> None:
        self.file.write(json.dumps(obj) + '\n')
        self.file.flush()

    def close(self):
        self.file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class KalshiAuth:
    def __init__(self, api_key_id: str, private_key_pem: str):
        self.api_key_id = api_key_id
        self.private_key = self._load_private_key(private_key_pem)
        self.token = None
        self.token_expires = None

    def _load_private_key(self, key_pem: str):
        return serialization.load_pem_private_key(
            key_pem.encode('utf-8'),
            password=None,
            backend=default_backend()
        )

    def create_signature(self, timestamp: str, method: str, path: str) -> str:
        message = f"{timestamp}{method}{path}".encode('utf-8')
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH
            ),
            hashes.SHA256()
        )
        return base64.b64encode(signature).decode('utf-8')

    def get_auth_headers(self, method: str, path: str) -> Dict[str, str]:
        timestamp = str(int(datetime.now().timestamp() * 1000))
        signature = self.create_signature(timestamp, method, path)

        return {
            'KALSHI-ACCESS-KEY': self.api_key_id,
            'KALSHI-ACCESS-SIGNATURE': signature,
            'KALSHI-ACCESS-TIMESTAMP': timestamp
        }

    def authenticate(self) -> bool:
        try:
            headers = self.get_auth_headers("GET", "/trade-api/v2/portfolio/balance")
            response = requests.get(
                f"{KALSHI_BASE}/portfolio/balance",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                logger.info("Successfully authenticated with Kalshi")
                self.token_expires = datetime.now() + timedelta(minutes=29)
                return True
            else:
                logger.error(f"Authentication failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return False

    def needs_refresh(self) -> bool:
        if not self.token_expires:
            return True
        return datetime.now() >= self.token_expires


class KalshiWebSocketClient:
    def __init__(self, auth: KalshiAuth, tickers: List[str], slug: str):
        self.auth = auth
        self.tickers = tickers
        self.ticker_map = {}
        self.websocket = None
        self.subscription_ids = {}
        self.orderbook_writer = JSONLWriter(f"kalshi_ws_ob_{slug}.jsonl")
        self.running = False
        self.message_id = 1

    def set_ticker_mapping(self, ticker: str, market_type: str):
        self.ticker_map[ticker] = market_type

    async def connect(self):
        try:
            headers = self.auth.get_auth_headers("GET", "/trade-api/ws/v2")

            logger.info(f"Connecting to {KALSHI_WSS}")
            logger.info(f"Headers: {headers}")

            self.websocket = await websockets.connect(
                KALSHI_WSS,
                additional_headers=headers
            )

            logger.info("Connected to Kalshi WebSocket")
            self.running = True

            await self.subscribe_to_orderbooks()
            await self.listen()

        except Exception as e:
            logger.error(f"WebSocket connection error: {e}")
            await self.reconnect()

    async def reconnect(self):
        logger.info("Attempting to reconnect...")
        await asyncio.sleep(5)

        if self.auth.needs_refresh():
            self.auth.authenticate()

        await self.connect()

    async def subscribe_to_orderbooks(self):
        for ticker in self.tickers:
            message = {
                "id": self.message_id,
                "cmd": "subscribe",
                "params": {
                    "channels": ["orderbook_delta"],
                    "market_ticker": ticker
                }
            }

            message_str = json.dumps(message)
            logger.info(f"Sending subscription: {message_str}")
            await self.websocket.send(message_str)
            logger.info(f"Sent subscription for {ticker}")
            self.message_id += 1
            await asyncio.sleep(0.1)

    async def listen(self):
        try:
            logger.info("Started listening for WebSocket messages")
            while self.running:
                try:
                    message = await asyncio.wait_for(self.websocket.recv(), timeout=5.0)
                    data = json.loads(message)

                    if data.get("type") == "subscribed":
                        self.handle_subscription_confirmation(data)
                    elif data.get("type") == "orderbook_delta":
                        self.handle_orderbook_update(data)
                    elif data.get("type") == "orderbook_snapshot":
                        self.handle_orderbook_snapshot(data)
                    elif data.get("type") == "error":
                        logger.error(f"WebSocket error: {data}")
                    elif data.get("type") == "ok":
                        logger.debug(f"Subscription confirmed: {data}")
                    else:
                        logger.debug(f"Unhandled message type: {data.get('type')}")

                except asyncio.TimeoutError:
                    continue
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse message: {e}")

        except websockets.ConnectionClosed:
            logger.warning("WebSocket connection closed")
            await self.reconnect()
        except Exception as e:
            logger.error(f"Error in WebSocket listener: {e}")
            await self.reconnect()

    def handle_subscription_confirmation(self, data: Dict):
        sid = data.get("msg", {}).get("sid")
        channel = data.get("msg", {}).get("channel")
        logger.info(f"Subscription confirmed: Channel={channel}, SID={sid}")

    def handle_orderbook_snapshot(self, data: Dict):
        try:
            msg = data.get("msg", {})
            ticker = msg.get("market_ticker")

            if not ticker or ticker not in self.ticker_map:
                return

            market_type = self.ticker_map[ticker]

            yes_array = msg.get("yes", [])
            no_array = msg.get("no", [])

            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'ticker': ticker,
                'market_type': market_type,
                'type': 'snapshot',
                'data': msg
            })

            with price_lock:
                # Best YES ask price = 100 - best NO bid
                # Best NO ask price = 100 - best YES bid

                if no_array and len(no_array) > 0:
                    # Highest NO bid gives us the YES ask price
                    best_no_bid_cents = no_array[-1][0]
                    yes_price = (100 - best_no_bid_cents) / 100.0
                    yes_size = no_array[-1][1]
                else:
                    yes_price = 0
                    yes_size = 0

                if yes_array and len(yes_array) > 0:
                    # Highest YES bid gives us the NO ask price
                    best_yes_bid_cents = yes_array[-1][0]
                    no_price = (100 - best_yes_bid_cents) / 100.0
                    no_size = yes_array[-1][1]
                else:
                    no_price = 0
                    no_size = 0

                if market_type == 'home_win':
                    prices['kalshi']['home_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['home_no'] = {'price': no_price, 'size': no_size}
                elif market_type == 'away_win':
                    prices['kalshi']['away_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['away_no'] = {'price': no_price, 'size': no_size}
                elif market_type == 'tie':
                    prices['kalshi']['tie_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['tie_no'] = {'price': no_price, 'size': no_size}

                last_update['kalshi'] = datetime.now()
                logger.debug(f"Updated {market_type} prices - YES: ${yes_price:.2f} ({yes_size}), NO: ${no_price:.2f} ({no_size})")

        except Exception as e:
            logger.error(f"Error handling orderbook snapshot: {e}")

    def handle_orderbook_update(self, data: Dict):
        try:
            ticker = data.get("market_ticker")
            if not ticker or ticker not in self.ticker_map:
                return

            market_type = self.ticker_map[ticker]

            yes_levels = data.get("yes", [])
            no_levels = data.get("no", [])

            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'ticker': ticker,
                'market_type': market_type,
                'data': data
            })

            with price_lock:
                if no_levels and len(no_levels) > 0:
                    yes_price = 1 - no_levels[-1][0] / 100.0
                    yes_size = no_levels[-1][1]
                else:
                    yes_price = 0
                    yes_size = 0

                if yes_levels and len(yes_levels) > 0:
                    no_price = 1 - yes_levels[-1][0] / 100.0
                    no_size = yes_levels[-1][1]
                else:
                    no_price = 0
                    no_size = 0

                if market_type == 'home_win':
                    prices['kalshi']['home_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['home_no'] = {'price': no_price, 'size': no_size}
                elif market_type == 'away_win':
                    prices['kalshi']['away_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['away_no'] = {'price': no_price, 'size': no_size}
                elif market_type == 'tie':
                    prices['kalshi']['tie_yes'] = {'price': yes_price, 'size': yes_size}
                    prices['kalshi']['tie_no'] = {'price': no_price, 'size': no_size}

                last_update['kalshi'] = datetime.now()

        except Exception as e:
            logger.error(f"Error handling orderbook update: {e}")

    async def close(self):
        self.running = False
        if self.websocket:
            await self.websocket.close()
        self.orderbook_writer.close()
        logger.info("WebSocket connection closed")


class UniversalMarketFinder:
    def __init__(self):
        self.league_mappings = {
            "nfl": {
                "kalshi_prefix": "kxnflgame",
                "kalshi_series": "KXNFLGAME",
                "polymarket_prefix": "nfl",
                "has_tie": False
            },
            "cfb": {
                "kalshi_prefix": "kxncaafgame",
                "kalshi_series": "KXNCAAFGAME",
                "polymarket_prefix": "cfb",
                "has_tie": False
            },
            "mlb": {
                "kalshi_prefix": "kxmlbgame",
                "kalshi_series": "KXMLBGAME",
                "polymarket_prefix": "mlb",
                "has_tie": False
            },
            "epl": {
                "kalshi_prefix": "kxeplgame",
                "kalshi_series": "KXEPLGAME",
                "polymarket_prefix": "epl",
                "has_tie": True
            },
            "serie a": {
                "kalshi_prefix": "kxserieagame",
                "kalshi_series": "KXSERIEAGAME",
                "polymarket_prefix": "sea",
                "has_tie": True
            },
            "bundesliga": {
                "kalshi_prefix": "kxbundesligagame",
                "kalshi_series": "KXBUNDESLIGAGAME",
                "polymarket_prefix": "bun",
                "has_tie": True
            },
            "la liga": {
                "kalshi_prefix": "kxlaligagame",
                "kalshi_series": "KXLALIGAGAME",
                "polymarket_prefix": "lal",
                "has_tie": True
            },
            "ligue 1": {
                "kalshi_prefix": "kxligue1game",
                "kalshi_series": "KXLIGUE1GAME",
                "polymarket_prefix": "fl1",
                "has_tie": True
            },
            "champions league": {
                "kalshi_prefix": "kxuclgame",
                "kalshi_series": "KXUCLGAME",
                "polymarket_prefix": "ucl",
                "has_tie": True
            }
        }

        self.team_abbreviations = {
            "osasuna": ["osa", "osasu", "pamplona", "osasuna"],
            "getafe": ["get", "geta", "gtfe", "azulones", "getafe"],
            "barcelona": ["bar", "barca", "fcb", "barcelona"],
            "real madrid": ["rma", "real", "madrid", "rmadrid"],
            "atletico": ["atl", "atleti", "atletico", "atm"],
            "bayern": ["bay", "fcb", "munich", "fcbayern"],
            "dortmund": ["bvb", "dor", "bor", "borussia"],
            "leipzig": ["rbl", "leipzig", "rbleipzig"],
            "hoffenheim": ["hof", "tsg", "1899"],
            "koln": ["koe", "col", "fckoln", "cologne"],
            "leeds": ["lee", "leed", "leedsutd", "lufc"],
            "tottenham": ["tot", "thfc", "spurs"],
            "manchester united": ["mun", "manutd", "united"],
            "manchester city": ["mci", "mancity", "city"],
            "liverpool": ["liv", "lfc", "pool"],
            "chelsea": ["che", "cfc", "blues"],
            "nottingham": ["not", "nfo", "nottingham", "forest"],
            "nottingham forest": ["not", "nfo", "nottingham", "forest"],
            "arsenal": ["ars", "afc", "gunners"],
            "juventus": ["juv", "juve"],
            "milan": ["mil", "acmilan"],
            "inter": ["int", "inter", "intermilan"],
            "napoli": ["nap", "napoli"],
            "roma": ["rom", "roma", "asroma"],
            "verona": ["ver", "vero", "hellas"],
            "sassuolo": ["sas", "sass"],
            "paris": ["par", "psg", "pfc", "parissg"],
            "lorient": ["lor", "fcl"],
            "marseille": ["mar", "mars", "om"],
            "lyon": ["lyo", "lyon", "ol"],
            "monaco": ["mon", "monaco", "asm"],
            "mariners": ["sea", "mariners"],
            "tigers": ["det", "tigers"],
            "blue jays": ["tor", "blue jays"],
            "yankees": ["nyy", "yankees"],
            "eagles": ["phi", "philadelphia", "eagles"],
            "giants": ["nyg", "ny giants", "giants"],
            "brewers": ["mil", "brewers"],
            "cubs": ["chc", "cubs"]
        }

        self.abbreviation_lookup = {}
        for full_name, abbrevs in self.team_abbreviations.items():
            for abbrev in abbrevs:
                self.abbreviation_lookup[abbrev.lower()] = abbrevs

    def normalize_team_name(self, team_name: str) -> List[str]:
        team_name_lower = team_name.lower().strip()
        if team_name_lower in self.abbreviation_lookup:
            return self.abbreviation_lookup[team_name_lower]
        for full_name, abbrevs in self.team_abbreviations.items():
            if full_name in team_name_lower or team_name_lower in full_name:
                return abbrevs
            for abbrev in abbrevs:
                if abbrev == team_name_lower:
                    return abbrevs
        if len(team_name_lower) <= 4:
            return [team_name_lower, team_name_lower[:3]]
        parts = team_name_lower.split()
        if len(parts) > 1:
            return [parts[0][:3], parts[-1][:3], ''.join([p[0] for p in parts])]
        else:
            return [team_name_lower[:3], team_name_lower[:4]]

    def find_kalshi_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]

        try:
            response = requests.get(
                f"{KALSHI_BASE}/events",
                params={
                    "series_ticker": league_info['kalshi_series'],
                    "status": "open",
                    "limit": 100
                },
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                events = data.get("events", [])

                team1_variants = self.normalize_team_name(team1)
                team2_variants = self.normalize_team_name(team2)

                for event in events:
                    event_ticker = event.get("event_ticker", "")
                    event_ticker_lower = event_ticker.lower()

                    team1_found = any(t in event_ticker_lower for t in team1_variants)
                    team2_found = any(t in event_ticker_lower for t in team2_variants)

                    if team1_found and team2_found:
                        print(f"Found Kalshi event: {event_ticker}")

                        markets_response = requests.get(
                            f"{KALSHI_BASE}/markets",
                            params={"event_ticker": event_ticker, "limit": 100},
                            timeout=10
                        )

                        if markets_response.status_code == 200:
                            markets = markets_response.json().get("markets", [])

                            result = {
                                'event_ticker': event_ticker,
                                'home_win': None,
                                'away_win': None,
                                'tie': None
                            }

                            for market in markets:
                                ticker = market.get("ticker", "")
                                ticker_upper = ticker.upper()

                                if league_info['has_tie']:
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        if suffix == "tie" or suffix == "draw":
                                            result['tie'] = ticker
                                        elif any(t.upper() in suffix.upper() for t in team1_variants):
                                            result['home_win'] = ticker
                                        elif any(t.upper() in suffix.upper() for t in team2_variants):
                                            result['away_win'] = ticker
                                else:
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        if any(t.lower() in suffix for t in team1_variants):
                                            result['home_win'] = ticker
                                        elif any(t.lower() in suffix for t in team2_variants):
                                            result['away_win'] = ticker

                            market_info = {
                                'exchange': 'kalshi',
                                'found': bool(result and result.get('event_ticker')),
                                'markets': {
                                    'home_win': {'ticker': result.get('home_win'), 'id': result.get('home_win')},
                                    'away_win': {'ticker': result.get('away_win'), 'id': result.get('away_win')},
                                    'tie': {'ticker': result.get('tie'), 'id': result.get('tie')} if result.get('tie') else None
                                },
                                'metadata': {
                                    'event_ticker': result.get('event_ticker')
                                }
                            }
                            return market_info
        except Exception as e:
            print(f"Error fetching Kalshi markets: {e}")

        return None

    def find_polymarket_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]
        team1_abbrev = self.normalize_team_name(team1)[0].lower()
        team2_abbrev = self.normalize_team_name(team2)[0].lower()

        result = {
            'tokens': {},
            'slugs': {}
        }

        if league_info['has_tie'] and game_date:
            date_str = game_date.strftime("%Y-%m-%d")

            # For soccer games, try both team orders since we don't know home/away
            base_slugs = [
                f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}",
                f"{league_info['polymarket_prefix']}-{team2_abbrev}-{team1_abbrev}-{date_str}"
            ]

            for base_slug in base_slugs:
                # Extract the team abbreviations from the base slug
                parts = base_slug.split('-')
                if len(parts) >= 5:
                    first_team = parts[1]
                    second_team = parts[2]

                    market_slugs = {
                        'home_win': f"{base_slug}-{first_team}",
                        'tie': f"{base_slug}-draw",
                        'away_win': f"{base_slug}-{second_team}"
                    }

                    found_any = False
                    temp_tokens = {}
                    temp_slugs = {}

                    for market_type, slug in market_slugs.items():
                        try:
                            resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                            if resp.status_code == 200:
                                markets = resp.json()
                                if isinstance(markets, list) and len(markets) > 0:
                                    market = markets[0]

                                    raw_ids = market.get('clobTokenIds')
                                    if raw_ids:
                                        try:
                                            if isinstance(raw_ids, str):
                                                clob_token_ids = ast.literal_eval(raw_ids)
                                            else:
                                                clob_token_ids = raw_ids

                                            if isinstance(clob_token_ids, list) and len(clob_token_ids) >= 1:
                                                yes_token = str(clob_token_ids[0])
                                                temp_tokens[market_type] = yes_token
                                                temp_slugs[market_type] = slug
                                                found_any = True
                                                print(f"Found Polymarket {market_type}: {slug}")
                                        except Exception as e:
                                            print(f"Error parsing tokens for {slug}: {e}")
                        except Exception as e:
                            pass  # Silently continue if market doesn't exist

                    # If we found any markets, use this configuration
                    if found_any:
                        result['tokens'] = temp_tokens
                        result['slugs'] = temp_slugs
                        break

        else:
            # For non-tie games (MLB, NFL, CFB)
            if game_date:
                date_str = game_date.strftime("%Y-%m-%d")

                # Try both team orders
                possible_slugs = [
                    f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}",
                    f"{league_info['polymarket_prefix']}-{team2_abbrev}-{team1_abbrev}-{date_str}"
                ]

                for slug in possible_slugs:
                    try:
                        resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                        if resp.status_code == 200:
                            markets = resp.json()
                            if isinstance(markets, list) and len(markets) > 0:
                                market = markets[0]
                                raw_ids = market.get('clobTokenIds')

                                if raw_ids:
                                    try:
                                        # Parse the token IDs
                                        if isinstance(raw_ids, str):
                                            # Try JSON first
                                            try:
                                                clob_token_ids = json.loads(raw_ids)
                                            except:
                                                # Fall back to ast.literal_eval
                                                clob_token_ids = ast.literal_eval(raw_ids)
                                        else:
                                            clob_token_ids = raw_ids

                                        # Parse outcomes
                                        outcomes = market.get('outcomes', [])
                                        if isinstance(outcomes, str):
                                            try:
                                                outcomes = json.loads(outcomes)
                                            except:
                                                outcomes = ast.literal_eval(outcomes)

                                        team1_variants = self.normalize_team_name(team1)
                                        team2_variants = self.normalize_team_name(team2)

                                        # Map outcomes to teams
                                        for i, outcome in enumerate(outcomes):
                                            if i >= len(clob_token_ids):
                                                continue
                                            outcome_lower = (outcome or "").lower()

                                            # Check which team this outcome represents
                                            if any(t.lower() in outcome_lower for t in team1_variants):
                                                result['tokens']['home_win'] = str(clob_token_ids[i])
                                                print(f"Found {team1} outcome: {outcome}")
                                            elif any(t.lower() in outcome_lower for t in team2_variants):
                                                result['tokens']['away_win'] = str(clob_token_ids[i])
                                                print(f"Found {team2} outcome: {outcome}")

                                        if result['tokens']:
                                            result['slugs']['market'] = slug
                                            print(f"Found Polymarket market: {slug}")
                                            break  # Found it, stop trying other slugs

                                    except Exception as e:
                                        print(f"Error parsing market data for {slug}: {e}")
                                        continue
                    except Exception as e:
                        print(f"Error fetching {slug}: {e}")
                        continue

        if result and result.get('tokens'):
            market_info = {
                'exchange': 'polymarket',
                'found': bool(result.get('tokens')),
                'markets': {
                    'home_win': {
                        'ticker': result['tokens'].get('home_win'),
                        'id': result['tokens'].get('home_win'),
                        'slug': result.get('slugs', {}).get('home_win')
                    } if 'home_win' in result.get('tokens', {}) else None,
                    'away_win': {
                        'ticker': result['tokens'].get('away_win'),
                        'id': result['tokens'].get('away_win'),
                        'slug': result.get('slugs', {}).get('away_win')
                    } if 'away_win' in result.get('tokens', {}) else None,
                    'tie': {
                        'ticker': result['tokens'].get('tie'),
                        'id': result['tokens'].get('tie'),
                        'slug': result.get('slugs', {}).get('tie')
                    } if 'tie' in result.get('tokens', {}) else None
                },
                'metadata': {
                    'slugs': result.get('slugs', {})
                }
            }
            return market_info

        return {
            'exchange': 'polymarket',
            'found': False,
            'markets': {},
            'metadata': {}
        }


class PolymarketMarket:
    def __init__(self, slug: str):
        self.gamma_url = POLYMARKET_GAMMA
        self.clob_url = POLYMARKET_CLOB
        self.orderbook_writer = JSONLWriter(f"poly_ob_{slug}.jsonl")

    def fetch_orderbook(self, token_ids: Dict[str, str]) -> Dict:
        combined_orderbooks = {}
        result = {}

        for market_type, token_id in token_ids.items():
            if not token_id:
                continue

            try:
                book_url = f"{self.clob_url}/book?token_id={token_id}"
                book_response = requests.get(book_url, timeout=5)

                if book_response.status_code == 200:
                    book_data = book_response.json()
                    combined_orderbooks[market_type] = book_data

                    bids = book_data.get('bids', [])
                    asks = book_data.get('asks', [])

                    yes_price = 0
                    yes_size = 0
                    if asks and len(asks) > 0:
                        yes_price = float(asks[-1]['price'])
                        yes_size = float(asks[-1]['size'])

                    no_price = 0
                    no_size = 0

                    result[market_type] = {
                        'yes_price': yes_price,
                        'yes_size': yes_size,
                        'no_price': no_price,
                        'no_size': no_size
                    }

            except Exception as e:
                print(f"Error fetching orderbook for {market_type}: {e}")
                result[market_type] = {
                    'yes_price': 0,
                    'yes_size': 0,
                    'no_price': 0,
                    'no_size': 0
                }

        if combined_orderbooks:
            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'orderbooks': combined_orderbooks
            })

        return result

    def close(self):
        self.orderbook_writer.close()


def display_best_prices(team1: str, team2: str, has_tie: bool):
    print("\n" + "="*100)
    print(f"REAL-TIME PRICES - {team1} vs {team2} - {datetime.now().strftime('%H:%M:%S')}")
    print("="*100)

    with price_lock:
        print(f"{'Market':<20} {'Kalshi Price':<15} {'Kalshi Size':<12} {'Poly Price':<15} {'Poly Size':<12} {'Delta':<10} {'Best':<10}")
        print("-"*100)

        if has_tie:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no'),
                ('Tie/Draw YES', 'tie_yes'),
                ('Tie/Draw NO', 'tie_no')
            ]
        else:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no')
            ]

        for market_name, key in markets:
            kalshi_data = prices['kalshi'][key]
            poly_data = prices['polymarket'][key]

            kalshi_price = kalshi_data['price']
            kalshi_size = kalshi_data['size']
            poly_price = poly_data['price']
            poly_size = poly_data['size']

            if kalshi_price == 0 and poly_price == 0:
                continue

            delta = kalshi_price - poly_price

            kalshi_price_str = f"${kalshi_price:.2f}" if kalshi_price > 0 else "N/A"
            kalshi_size_str = f"{kalshi_size:.0f}" if kalshi_size > 0 else "N/A"
            poly_price_str = f"${poly_price:.2f}" if poly_price > 0 else "N/A"
            poly_size_str = f"{poly_size:.0f}" if poly_size > 0 else "N/A"

            if delta > 0:
                delta_str = f"+${delta:.2f}"
                best = "Kalshi"
            elif delta < 0:
                delta_str = f"-${abs(delta):.2f}"
                best = "Poly"
            else:
                delta_str = "$0.00"
                best = "Equal"

            if kalshi_price == 0:
                best = "Poly only"
                delta_str = "N/A"
            elif poly_price == 0:
                best = "Kalshi only"
                delta_str = "N/A"

            print(f"{market_name:<20} {kalshi_price_str:<15} {kalshi_size_str:<12} {poly_price_str:<15} {poly_size_str:<12} {delta_str:<10} {best:<10}")

    print("-"*100)

    with price_lock:
        kalshi_update = (datetime.now() - last_update['kalshi']).total_seconds()
        poly_update = (datetime.now() - last_update['polymarket']).total_seconds()
        print(f"Last update: Kalshi {kalshi_update:.1f}s ago, Polymarket {poly_update:.1f}s ago")
    print("="*100)


def detect_cross_exchange_arbitrage(has_tie: bool, arbLog: JSONLWriter) -> Optional[Dict]:
    if has_tie:
        return None

    with price_lock:
        home_win_options = []

        if prices['kalshi']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_yes',
                'price': prices['kalshi']['home_yes']['price'],
                'size': prices['kalshi']['home_yes']['size']
            })

        if prices['polymarket']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_yes',
                'price': prices['polymarket']['home_yes']['price'],
                'size': prices['polymarket']['home_yes']['size']
            })

        if prices['kalshi']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_no',
                'price': prices['kalshi']['away_no']['price'],
                'size': prices['kalshi']['away_no']['size']
            })

        if prices['polymarket']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_no',
                'price': prices['polymarket']['away_no']['price'],
                'size': prices['polymarket']['away_no']['size']
            })

        away_win_options = []

        if prices['kalshi']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_yes',
                'price': prices['kalshi']['away_yes']['price'],
                'size': prices['kalshi']['away_yes']['size']
            })

        if prices['polymarket']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_yes',
                'price': prices['polymarket']['away_yes']['price'],
                'size': prices['polymarket']['away_yes']['size']
            })

        if prices['kalshi']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_no',
                'price': prices['kalshi']['home_no']['price'],
                'size': prices['kalshi']['home_no']['size']
            })

        if prices['polymarket']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_no',
                'price': prices['polymarket']['home_no']['price'],
                'size': prices['polymarket']['home_no']['size']
            })

        if not home_win_options or not away_win_options:
            return None

        best_home = min(home_win_options, key=lambda x: x['price'])
        best_away = min(away_win_options, key=lambda x: x['price'])

        total_cost = best_home['price'] + best_away['price']

        if total_cost < 1.0:
            max_shares = min(best_home['size'], best_away['size'])
            profit_per_share = 1.0 - total_cost
            total_profit = profit_per_share * max_shares
            total_investment = total_cost * max_shares
            roi_percent = (profit_per_share / total_cost) * 100

            arb = {
                'type': 'CROSS_EXCHANGE_2_OUTCOME',
                'home_win': best_home,
                'away_win': best_away,
                'total_cost': total_cost,
                'profit_per_share': profit_per_share,
                'max_shares': max_shares,
                'total_profit': total_profit,
                'total_investment': total_investment,
                'roi_percent': roi_percent
            }
            arbLog.write(arb)
            return arb

    return None


def display_cross_exchange_arbitrage(arb: Optional[Dict], team1: str, team2: str):
    if not arb:
        return

    print("\n" + "🚨 " * 20)
    print("💰 CROSS-EXCHANGE ARBITRAGE DETECTED!")
    print("🚨 " * 20)

    home_win = arb['home_win']
    away_win = arb['away_win']

    home_label = f"{team1} win"
    home_trade = f"{home_win['type'].replace('_', ' ').upper()}"
    print(f"\n1️⃣  Buy {home_label} via {home_trade}")
    print(f"    Exchange: {home_win['exchange'].upper()}")
    print(f"    Price: ${home_win['price']:.4f}")
    print(f"    Available: {home_win['size']:.0f} shares")

    away_label = f"{team2} win"
    away_trade = f"{away_win['type'].replace('_', ' ').upper()}"
    print(f"\n2️⃣  Buy {away_label} via {away_trade}")
    print(f"    Exchange: {away_win['exchange'].upper()}")
    print(f"    Price: ${away_win['price']:.4f}")
    print(f"    Available: {away_win['size']:.0f} shares")

    print(f"\n{'='*60}")
    print(f"Total Cost per Share: ${arb['total_cost']:.4f}")
    print(f"Guaranteed Return: $1.00")
    print(f"Profit per Share: ${arb['profit_per_share']:.4f}")
    print(f"ROI: {arb['roi_percent']:.2f}%")
    print(f"{'='*60}")
    print(f"Max Tradeable Shares: {arb['max_shares']:.0f}")
    print(f"Total Investment: ${arb['total_investment']:.2f}")
    print(f"Total Profit: ${arb['total_profit']:.2f}")
    print(f"{'='*60}")

    print("🚨 " * 20 + "\n")


async def poll_polymarket_prices(polymarket_client: PolymarketMarket,
                                 polymarket_markets: Dict,
                                 has_tie: bool):
    while True:
        if polymarket_client and polymarket_markets.get('found'):
            token_map = {}
            for market_type in ['home_win', 'away_win', 'tie']:
                market_info = polymarket_markets['markets'].get(market_type)
                if market_info and market_info.get('id'):
                    token_map[market_type] = market_info['id']

            poly_orderbooks = polymarket_client.fetch_orderbook(token_map)

            with price_lock:
                if 'home_win' in poly_orderbooks:
                    data = poly_orderbooks['home_win']
                    prices['polymarket']['home_yes'] = {'price': data['yes_price'], 'size': data['yes_size']}
                    prices['polymarket']['home_no'] = {'price': data['no_price'], 'size': data['no_size']}

                if 'away_win' in poly_orderbooks:
                    data = poly_orderbooks['away_win']
                    prices['polymarket']['away_yes'] = {'price': data['yes_price'], 'size': data['yes_size']}
                    prices['polymarket']['away_no'] = {'price': data['no_price'], 'size': data['no_size']}

                if has_tie and 'tie' in poly_orderbooks:
                    data = poly_orderbooks['tie']
                    prices['polymarket']['tie_yes'] = {'price': data['yes_price'], 'size': data['yes_size']}
                    prices['polymarket']['tie_no'] = {'price': data['no_price'], 'size': data['no_size']}

                last_update['polymarket'] = datetime.now()

        await asyncio.sleep(2)


async def main():
    print("SUPPORTED LEAGUES:")
    print("- NFL, CFB")
    print("- MLB")
    print("- EPL, Serie A, Bundesliga, La Liga, Ligue 1, Champions League")
    print("\nEnter match details:")
    print("You can use team abbreviations (e.g., SF, LAR, PSG, BAR, OSA, GET)")

    team1 = input("Team 1 (home/first team): ").strip()
    team2 = input("Team 2 (away/second team): ").strip()
    league = input("League (NFL/CFB/MLB/EPL/Serie A/Bundesliga/La Liga/Ligue 1/Champions League): ").strip()

    date_str = input("Date (YYYY-MM-DD) or press Enter to skip: ").strip()
    if date_str:
        try:
            game_date = datetime.strptime(date_str, "%Y-%m-%d")
            print(f"Looking for matches on {game_date.strftime('%B %d, %Y')}")
        except:
            print("Invalid date format, proceeding without date filter")
            game_date = None
    else:
        game_date = None

    print("\nSearching for markets...")
    finder = UniversalMarketFinder()

    league_lower = league.lower()
    if league_lower not in finder.league_mappings:
        print(f"League '{league}' not supported")
        return

    has_tie = finder.league_mappings[league_lower]['has_tie']

    print("\n--- Searching Kalshi ---")
    kalshi_markets = finder.find_kalshi_markets(team1, team2, league, game_date)

    if not kalshi_markets or not kalshi_markets.get('found'):
        print(f"❌ Could not find Kalshi markets for {team1} vs {team2}")
        kalshi_markets = {'found': False, 'markets': {}}
    else:
        print(f"✓ Found Kalshi event: {kalshi_markets['metadata']['event_ticker']}")
        for market_type in ['home_win', 'away_win', 'tie']:
            market = kalshi_markets['markets'].get(market_type)
            if market and market.get('ticker'):
                team_label = team1 if market_type == 'home_win' else (
                    team2 if market_type == 'away_win' else 'Tie')
                print(f"  {team_label} win: {market['ticker']}")

    print("\n--- Searching Polymarket ---")
    polymarket_markets = finder.find_polymarket_markets(team1, team2, league, game_date)

    if not polymarket_markets or not polymarket_markets.get('found'):
        print(f"❌ Could not find Polymarket markets for {team1} vs {team2}")
        polymarket_markets = {'found': False, 'markets': {}}
    else:
        print("✓ Found Polymarket markets")
        for market_type in ['home_win', 'away_win', 'tie']:
            market = polymarket_markets['markets'].get(market_type)
            if market and market.get('id'):
                team_label = team1 if market_type == 'home_win' else (
                    team2 if market_type == 'away_win' else 'Tie')
                print(f"  {team_label}: {market.get('ticker', market['id'][:30])}")

    if not kalshi_markets.get('found') and not polymarket_markets.get('found'):
        print("\n⚠️  No markets found on either exchange.")
        print("Tips:")
        print("- Make sure the date matches the actual game date")
        print("- Try using full team names instead of abbreviations")
        print("- Check if the game is actually scheduled")
        return

    print("\n" + "="*80)
    print("INITIALIZING PRICE MONITORING")
    print("="*80)

    kalshi_ws_client = None
    if kalshi_markets.get('found'):
        API_KEY_ID = "39bb4b72-782d-432e-84e6-f228d2e4703d"
        PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692B
gGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2lj
z4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1E
X8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u8
8DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eru
M1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUk
xxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5
F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPp
oLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb
778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3d
OygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobf
KQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1
uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJ
WvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jza
lm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5
qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI
1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6
c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4
eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCw
GsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8
R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa
98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoe
dYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxO
Fmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX
3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo
-----END RSA PRIVATE KEY-----"""

        kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)

        if kalshi_auth.authenticate():
            tickers = []
            ticker_to_market = {}

            for market_type in ['home_win', 'away_win', 'tie']:
                market_info = kalshi_markets['markets'].get(market_type)
                if market_info and market_info.get('id'):
                    ticker = market_info['id']
                    tickers.append(ticker)
                    ticker_to_market[ticker] = market_type

            kalshi_ws_client = KalshiWebSocketClient(
                kalshi_auth,
                tickers,
                kalshi_markets['metadata']['event_ticker']
            )

            for ticker, market_type in ticker_to_market.items():
                kalshi_ws_client.set_ticker_mapping(ticker, market_type)

            logger.info(f"Initialized Kalshi WebSocket client with {len(tickers)} tickers")
        else:
            logger.error("Failed to authenticate with Kalshi")
            kalshi_ws_client = None

    polymarket_client = None
    if polymarket_markets.get('found'):
        polymarket_client = PolymarketMarket(
            slug=polymarket_markets["metadata"]["slugs"]["market"]
        )

    print("Starting real-time monitoring...")
    print("Using WebSocket for Kalshi data (instant updates)")
    print("Polling for Polymarket data (every 2 seconds)")
    print("Press Ctrl+C to stop\n")

    try:
        tasks = []

        if kalshi_ws_client:
            tasks.append(kalshi_ws_client.connect())

        if polymarket_client:
            tasks.append(poll_polymarket_prices(
                polymarket_client,
                polymarket_markets,
                has_tie
            ))

        arbLog = JSONLWriter(f"arb_{team1}_{team2}.jsonl")

        async def display_loop():
            while True:
                display_best_prices(team1, team2, has_tie)
                arb = detect_cross_exchange_arbitrage(has_tie, arbLog)
                display_cross_exchange_arbitrage(arb, team1, team2)
                await asyncio.sleep(0.5)

        tasks.append(display_loop())

        await asyncio.gather(*tasks)

    except KeyboardInterrupt:
        print("\n\nStopping monitor...")
        if kalshi_ws_client:
            await kalshi_ws_client.close()
        if polymarket_client:
            polymarket_client.close()
        arbLog.close()
        print("Shutdown complete.")


if __name__ == "__main__":
    asyncio.run(main())
