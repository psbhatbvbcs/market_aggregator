api_key = "39bb4b72-782d-432e-84e6-f228d2e4703d"
private_key = "MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692BgGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2ljz4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1EX8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u88DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eruM1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUkxxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPpoLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3dOygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobfKQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJWvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jzalm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCwGsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoedYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxOFmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo"

PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAmU7fZ647vtqwBOtXUPYPYeE3IdMo9c5m9bLIN/uG3SFFkdwf
D0pj8M7AJfVYyvZZ8g/ujG1Hp95yeYJa52nRctRa4MqcIu7njWfPauQfyJQFJvbz
zAFvcTERGvVh3kRxvBlYm74F3r9C7We9vfz9wp132vKx1g8sgv1sDxutDh45qb2G
HA1AeweRR4A5oxGKv2ovOcUnS9BKF3HmcnnhJKzicP6HGTp7nL8SilgRZQme1v9O
g1nKYVuF/V6qJ5dMFw1OAh3pvvvTb2n4CJ78wAUStu7fjCmrrFgltB14HsI07+Q+
eu3XxONU4ag5GL1ONRjYf21H1K4s3SlPXOOBnwIDAQABAoIBAERvX+zBaywkJOTd
RUn/vRgdV+YCg8tOSsms+BF9d1No0cxtrXO+6mQJdt666dsYI0iZ8gu/kHgQJZu2
I+wfYX7X6oVkDFTPvo9x4rY9hS6dXLtrC6NqlJu7on4dQYXdmcO0sMg9CBPJ3w9o
+ts/fuuMLX+QTPBYL699fuozmYmuJYKSf4raiWP9pb9SXfVhvgvr1bqCDVgIpYpg
uSm/l/JeY9kwYSw1MUmlC/Kg+d7CBxrB5KGkU0+7ijNOpJ+T22oftqAQjqZgY3m/
oHlzZJknUgqBVQEnftgMT0ASdcIgTLOk/EFZrgFH6iCcQM058ey5ra9cMFJRKyet
QSjGoGkCgYEAxtNE8toPP43IwHy+EWacvZNKdTkWs7mphrwcTx8Hazny2qhBxWyD
3ZeE9rA1z5h2Kw1EaSSepq/9/5GYzFtwxG0veZrsxLoXgyruII6ooGwbry7JfZyA
/NIWztayBdodXYYXctHdF8Z/z2nTyMUPGNdf3VD44kndM6uAh125sz0CgYEAxWTP
EMhbi7vJUrIQKG5NcjHkQqHVzeunLrfaQT3le1D+EtBJgedSawgn0JT4K7t6ZoGk
bf90VGO/mlR9I/MNOSBvxC5syp3nvIDEGkB7BRr40r7IIZsfk/dA5jA2Saa6tfgE
pJyzizXOqR9SkSD7Q+mdIg9q0UaVUPAhg+hg5gsCgYAWioE4nyw3YlWuLPZHdsCy
ZW59l7lRKu1jTxROjBAFQg6cZ5L9VO4mQzVZ2mRfYsOS4fAtk29BKpa7UMBn+r3w
JwjI2p2ZOBfOUSGqI0JO3bLNy5ogWYvuHctkK8cHDtFhdwBVjiFovqJi23adPmoV
wOUnbDSrQwCHCRyLPD7/aQKBgElyPf2Pn0h54ensKUjx6c0gtT75unT5RuaCMCpw
Xm+o7jCP4Zn9OVRr32yj0UdsZZm4iTcIgv9XchZ5c2qp5/Smlg+X+pDVekFQZCck
cOGwbH71z795WaGTsUk1DS4QZI6KryeUytV0euXAqtcnP3bAeOAQfn1J1wsbnkzX
bR6LAoGBAJuhFcpx92h27ZlDh9NH/i/bIuJ/Yy4bTOIXc2V5Mt7QZlJWSSQSDdv1
W+rU2Z/RNCFyAi1bzm012Jn9w/VCTqE3AoG1JfpITiFSIiTAvoYzmJHCSLQZJE0E
uKv3ev64E5Os3nhNPp3+pEq7OmoYxd3EFXvHncBDFLxBAc2cXBjw
-----END RSA PRIVATE KEY-----"""

import requests, datetime, base64, sys, time
import asyncio
import websockets
import json
import threading
from collections import defaultdict
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding

API_KEY_ID = "YOUR_API_KEY_ID"
BASE_URL = "https://api.elections.kalshi.com"
PATH = "/trade-api/v2/markets"
WSS_URL = "wss://api.elections.kalshi.com"

orderbook_cache = defaultdict(lambda: {'yes': [], 'no': []})
orderbook_lock = threading.Lock()

def load_private_key_from_text(pem_text: str, password: str | None = None):
    if isinstance(pem_text, str):
        pem_bytes = pem_text.encode("utf-8")
    elif isinstance(pem_text, (bytes, bytearray)):
        pem_bytes = bytes(pem_text)
    else:
        raise TypeError("PEM must be str or bytes")

    pwd_bytes = password.encode() if isinstance(password, str) else None
    return serialization.load_pem_private_key(pem_bytes, password=pwd_bytes)

def sign_request(private_key, timestamp_ms: str, method: str, path: str) -> str:
    msg = f"{timestamp_ms}{method}{path}".encode("utf-8")
    sig = private_key.sign(
        msg,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.DIGEST_LENGTH),
        hashes.SHA256(),
    )
    return base64.b64encode(sig).decode("utf-8")

def get_open_markets():
    for retry in range(3):
        try:
            pk = load_private_key_from_text(PRIVATE_KEY_PEM)
            ts = str(int(datetime.datetime.now().timestamp() * 1000))
            sig = sign_request(pk, ts, "GET", PATH)

            headers = {
                "KALSHI-ACCESS-KEY": API_KEY_ID,
                "KALSHI-ACCESS-TIMESTAMP": ts,
                "KALSHI-ACCESS-SIGNATURE": sig,
            }
            params = {"status": "open", "limit": 1000}
            r = requests.get(BASE_URL + PATH, headers=headers, params=params, timeout=20)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            if retry < 2:
                time.sleep(0.01)
            else:
                print("Request failed after 3 retries:", e)
                return {"markets": []}

def get_orderbook(ticker):
    with orderbook_lock:
        if ticker in orderbook_cache and orderbook_cache[ticker]['yes'] and orderbook_cache[ticker]['no']:
            return {'orderbook': orderbook_cache[ticker]}

    for retry in range(3):
        try:
            orderbook_url = f"https://api.elections.kalshi.com/trade-api/v2/markets/{ticker}/orderbook"
            orderbook_response = requests.get(orderbook_url, timeout=5)
            orderbook_response.raise_for_status()
            orderbook_data = orderbook_response.json()
            with orderbook_lock:
                if 'orderbook' in orderbook_data:
                    orderbook_cache[ticker] = orderbook_data['orderbook']
            return orderbook_data
        except Exception as e:
            if retry < 2:
                time.sleep(0.01)
            else:
                return {'orderbook': {'yes': None, 'no': None}}

def get_market_data(ticker):
    for retry in range(3):
        try:
            markets_url = f"https://api.elections.kalshi.com/trade-api/v2/markets?series_ticker={ticker}&status=open"
            markets_response = requests.get(markets_url, timeout=5)
            markets_response.raise_for_status()
            markets_data = markets_response.json()
            return markets_data
        except Exception as e:
            if retry < 2:
                time.sleep(0.01)
            else:
                return {"markets": []}

async def connect_kalshi_websocket(market_tickers):
    headers = {
        "KALSHI-ACCESS-KEY": API_KEY_ID
    }

    retry_count = 0
    while retry_count < 3:
        try:
            async with websockets.connect(WSS_URL, extra_headers=headers) as websocket:
                retry_count = 0

                for ticker in market_tickers:
                    subscribe_msg = {
                        "id": market_tickers.index(ticker) + 1,
                        "cmd": "subscribe",
                        "params": {
                            "channels": ["orderbook_delta"],
                            "market_ticker": ticker
                        }
                    }
                    await websocket.send(json.dumps(subscribe_msg))

                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=30)
                        data = json.loads(message)

                        if 'type' in data and data['type'] == 'orderbook_delta':
                            market_ticker = data.get('market_ticker')
                            if market_ticker:
                                with orderbook_lock:
                                    if 'yes' in data:
                                        orderbook_cache[market_ticker]['yes'] = data['yes']
                                    if 'no' in data:
                                        orderbook_cache[market_ticker]['no'] = data['no']
                    except asyncio.TimeoutError:
                        ping_msg = {"type": "ping"}
                        await websocket.send(json.dumps(ping_msg))
                    except Exception as e:
                        break

        except Exception as e:
            retry_count += 1
            if retry_count < 3:
                await asyncio.sleep(0.01)
            else:
                await asyncio.sleep(1)
                retry_count = 0

def start_kalshi_websocket(market_tickers):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(connect_kalshi_websocket(market_tickers))

if __name__ == "__main__":
    try:
        data = get_open_markets()
    except Exception as e:
        print("Request failed:", e)
        sys.exit(1)

    markets = data.get("markets", [])
    print(len(markets))
    for i in range(0, len(markets)):
        print(markets[i]['title'])

    print(datetime.datetime.now())
    ticker = "kxncaafgame"
    ticker = ticker.upper()
    markets_url = f"https://api.elections.kalshi.com/trade-api/v2/markets?series_ticker={ticker}&status=open"
    markets_response = requests.get(markets_url)
    print(datetime.datetime.now())
    markets_data = markets_response.json()
