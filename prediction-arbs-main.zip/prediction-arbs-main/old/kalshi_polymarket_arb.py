import kalshi_api
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import BookParams
from py_clob_client.clob_types import ApiCreds, MarketOrderArgs, OrderType, OrderArgs
from py_clob_client.clob_types import ApiCreds, OrderArgs, PostOrdersArgs, OrderType, OpenOrderParams
import requests
import time
import json
import csv, os, datetime
import ast
import asyncio
import websockets
import threading
from collections import defaultdict

HOST = "https://clob.polymarket.com"
CHAIN_ID = 137
PRIVATE_KEY = "0xb0240ca09fd5169f06f95655788ef9f8e9f6b73dc4242721903b540c81635d7a"
FUNDER = "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
POLYMARKET_WSS_URL = "wss://ws-subscriptions-clob.polymarket.com/ws/"

client = ClobClient(
    HOST,
    key=PRIVATE_KEY,
    chain_id=CHAIN_ID,
    signature_type=1,
    funder=FUNDER
)
client.set_api_creds(client.create_or_derive_api_creds())
api_creds = client.derive_api_key()

url = "https://gamma-api.polymarket.com/markets?slug="
market_slug_1 = "cfb-sdsu-wsu-2025-09-06"

polymarket_slugs = [['nfl-lac-lv-2025-09-15', 'KXNFLGAME-25SEP15LACLV-LV']]

games = {}
polymarket_positions = defaultdict(lambda: {'yes': 0, 'no': 0})
polymarket_orderbook = defaultdict(lambda: {'yes': [], 'no': []})
position_lock = threading.Lock()
orderbook_lock = threading.Lock()

for slug in polymarket_slugs:
    games[slug[0]] = {}

for slug in polymarket_slugs:
    games[slug[0]]['kalshi_slug'] = slug[1]

for slug in polymarket_slugs:
    for retry in range(3):
        try:
            resp = requests.get(url+slug[0], timeout=5).json()
            clobTokenIds = ast.literal_eval(resp[0]['clobTokenIds'])
            yes_token, no_token = map(str, clobTokenIds)

            games[slug[0]]['yes_token'] = yes_token
            games[slug[0]]['no_token'] = no_token
            break
        except Exception as e:
            if retry < 2:
                time.sleep(0.01)
            else:
                print(f"Failed to get tokens for {slug[0]}")
                games[slug[0]]['yes_token'] = None
                games[slug[0]]['no_token'] = None

token_list = {}
if 'yes_token' in games.get(polymarket_slugs[0][0], {}) and games[polymarket_slugs[0][0]]['yes_token']:
    token_list['market_slug_1'] = [games[polymarket_slugs[0][0]]['yes_token'], games[polymarket_slugs[0][0]]['no_token']]

async def connect_polymarket_user_websocket():
    auth_data = {
        "auth": {
            "apiKey": api_creds.api_key,
            "secret": api_creds.secret,
            "passphrase": api_creds.api_passphrase
        }
    }

    retry_count = 0
    while retry_count < 3:
        try:
            async with websockets.connect(POLYMARKET_WSS_URL + "user") as websocket:
                retry_count = 0
                await websocket.send(json.dumps(auth_data))

                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=30)
                        data = json.loads(message)

                        if 'type' in data and data['type'] == 'position':
                            with position_lock:
                                for game in games:
                                    if data.get('asset') == games[game]['yes_token']:
                                        polymarket_positions[game]['yes'] = data.get('size', 0)
                                    elif data.get('asset') == games[game]['no_token']:
                                        polymarket_positions[game]['no'] = data.get('size', 0)
                    except asyncio.TimeoutError:
                        ping_msg = {"type": "ping"}
                        await websocket.send(json.dumps(ping_msg))
                    except Exception as e:
                        break

        except Exception as e:
            retry_count += 1
            if retry_count < 3:
                await asyncio.sleep(0.01)
            else:
                await asyncio.sleep(1)
                retry_count = 0

async def connect_polymarket_market_websocket(token_ids):
    auth_data = {
        "auth": {
            "apiKey": api_creds.api_key,
            "secret": api_creds.secret,
            "passphrase": api_creds.api_passphrase
        },
        "markets": token_ids
    }

    retry_count = 0
    while retry_count < 3:
        try:
            async with websockets.connect(POLYMARKET_WSS_URL + "market") as websocket:
                retry_count = 0
                await websocket.send(json.dumps(auth_data))

                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=30)
                        data = json.loads(message)

                        if 'type' in data and data['type'] == 'book':
                            token_id = data.get('asset_id')
                            if token_id:
                                with orderbook_lock:
                                    for game in games:
                                        if games[game]['yes_token'] == token_id:
                                            polymarket_orderbook[game]['yes'] = data.get('bids', [])
                                        elif games[game]['no_token'] == token_id:
                                            polymarket_orderbook[game]['no'] = data.get('asks', [])
                    except asyncio.TimeoutError:
                        ping_msg = {"type": "ping"}
                        await websocket.send(json.dumps(ping_msg))
                    except Exception as e:
                        break

        except Exception as e:
            retry_count += 1
            if retry_count < 3:
                await asyncio.sleep(0.01)
            else:
                await asyncio.sleep(1)
                retry_count = 0

def start_polymarket_websockets(token_ids):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    tasks = [
        connect_polymarket_user_websocket(),
        connect_polymarket_market_websocket(token_ids)
    ]

    loop.run_until_complete(asyncio.gather(*tasks))

def start_kalshi_websocket_thread(market_tickers):
    ws_thread = threading.Thread(target=kalshi_api.start_kalshi_websocket, args=(market_tickers,))
    ws_thread.daemon = True
    ws_thread.start()

def start_polymarket_websocket_thread(token_ids):
    ws_thread = threading.Thread(target=start_polymarket_websockets, args=(token_ids,))
    ws_thread.daemon = True
    ws_thread.start()

def calculate_live_odds(event_ticker):
    try:
        orderbook_data = kalshi_api.get_orderbook(event_ticker)

        if (orderbook_data['orderbook']['yes'] is None or
            orderbook_data['orderbook']['no']  is None):
            return {'bid_price': 0,
                    'bid_quantity': 0,
                    'ask_price': 0,
                    'ask_quantity': 0}

        bid_data = orderbook_data['orderbook']['yes'][-1]
        ask_data = orderbook_data['orderbook']['no'][-1]

        ask_data[0] = 100-ask_data[0]

        bid_data[0] = float(bid_data[0])/100
        ask_data[0] = float(ask_data[0])/100

        return {'bid_price': bid_data[0],
                'bid_quantity': bid_data[1],
                'ask_price': ask_data[0],
                'ask_quantity': ask_data[1]}
    except Exception as e:
        return {'bid_price': 0,
                'bid_quantity': 0,
                'ask_price': 0,
                'ask_quantity': 0}

def post_orders(order_info, token_list, yes_no_ratio):
    for retry in range(3):
        try:
            client.cancel_all()

            if (order_info['bid_price'] == 0 or order_info['ask_price'] == 0):
                return "Market Data Not Available"

            order_size = 500
            yes_order_size = order_size
            no_order_size = order_size

            yes_skew = 0
            no_skew = 0

            spread = 0.02

            max_inventory = 2000
            if (yes_no_ratio<-10):
                no_order_size = int(yes_order_size*(1-abs(yes_no_ratio)/max_inventory))
            if (yes_no_ratio<-max_inventory):
                no_order_size = 0.0

            if (yes_no_ratio>10):
                yes_order_size = int(no_order_size*(1-abs(yes_no_ratio)/max_inventory))
            if (yes_no_ratio>max_inventory):
                yes_order_size = 0.0

            yes_price = 1-order_info['ask_price']-spread+yes_skew
            no_price = order_info['bid_price']-spread+no_skew

            if (yes_price < 0.01):
                yes_price = 0.01
            if (no_price < 0.01):
                no_price = 0.01

            if (yes_price > 0.94):
                yes_price = yes_price+0.01
            if (no_price > 0.94):
                no_price = no_price+0.01

            resp = client.post_orders(
             [
                 PostOrdersArgs(
                     client.create_order(
                         OrderArgs(
                             price= no_price,
                             size=no_order_size,
                             side="BUY",
                             token_id=token_list[1],
                         )
                     ),
                     orderType=OrderType.GTC,
                 ),
                 PostOrdersArgs(
                     client.create_order(
                         OrderArgs(
                             price=yes_price,
                             size=yes_order_size,
                             side="BUY",
                             token_id=token_list[0],
                         )
                     ),
                     orderType=OrderType.GTC,
                 ),
             ]
            )
            return [yes_price, no_price]
        except Exception as e:
            if retry < 2:
                time.sleep(0.01)
            else:
                return "Order Failed"

def inventory_balancing(games, position):
    print ("Inventory Check", int(counter/100))
    for game in games:
        try:
            yes_token_cost = 0.0
            yes_token_current_value = 0.0
            no_token_cost = 0.0
            no_token_current_value = 0.0

            for pos in position:
                if (games[game]['yes_token'] == pos['asset']):
                    yes_token_cost = float(pos['avgPrice'])
                    yes_token_current_value = float(pos['currentValue']/pos['size'])
                if (games[game]['no_token'] == pos['asset']):
                    no_token_cost = float(pos['avgPrice'])
                    no_token_current_value = float(pos['currentValue']/pos['size'])

            if ((games[game]['yes_token_position'] < games[game]['no_token_position'] - 1000) and
                (yes_token_current_value+no_token_cost<0.90)):
                order_args = MarketOrderArgs(
                    token_id=games[game]['yes_token'],
                    amount=int(100*yes_token_current_value),
                    side="BUY")
                signed_order = client.create_market_order(order_args)
                resp = client.post_order(signed_order, orderType=OrderType.FOK)
                print (resp)
                print ('notoken>yestoken')

            if ((games[game]['yes_token_position'] > games[game]['no_token_position'] + 1000) and
                (no_token_current_value+yes_token_cost<0.90)):
                order_args = MarketOrderArgs(
                    token_id=games[game]['no_token'],
                    amount=int(100*no_token_current_value),
                    side="BUY")
                signed_order = client.create_market_order(order_args)
                resp = client.post_order(signed_order, orderType=OrderType.FOK)
                print (resp)
                print ('yestoken>notoken')

            print (yes_token_cost,
                   yes_token_current_value,
                   no_token_cost,
                   no_token_current_value)
        except Exception as e:
            continue

kalshi_tickers = [games[game]['kalshi_slug'] for game in games if games[game].get('kalshi_slug')]
if kalshi_tickers:
    start_kalshi_websocket_thread(kalshi_tickers)

all_tokens = []
for game in games:
    if games[game].get('yes_token') and games[game].get('no_token'):
        all_tokens.extend([games[game]['yes_token'], games[game]['no_token']])
if all_tokens:
    start_polymarket_websocket_thread(all_tokens)

time.sleep(3)

bid_price = {}
ask_price = {}
for game in games:
    try:
        order_info = calculate_live_odds(games[game]['kalshi_slug'])
        if ((order_info['bid_price'] > 0.02 and order_info['ask_price'] > 0.02) and
            (order_info['bid_price'] < 0.98 and order_info['ask_price'] < 0.98)):
            resp = post_orders(order_info, [games[game]['yes_token'], games[game]['no_token']], 1)
            bid_price[game] = order_info['bid_price']
            ask_price[game] = order_info['ask_price']
            print("MARKET INITIALIZED",
                  datetime.datetime.now(),
                  bid_price[game], round(resp[1], 2),
                  round(1.0-ask_price[game], 2), round(resp[0], 2),
                  game)
        else:
            bid_price[game] = 0.5
            ask_price[game] = 0.5
    except Exception as e:
        bid_price[game] = 0.5
        ask_price[game] = 0.5

print()

for game in games:
    games[game]['no_token_position']  = 0
    games[game]['yes_token_position'] = 0

positions = []
counter = 0
while (True):
    try:
        with position_lock:
            for game in games:
                games[game]['yes_token_position'] = polymarket_positions[game]['yes']
                games[game]['no_token_position'] = polymarket_positions[game]['no']

        if (counter % 100 == 0):
            for retry in range(3):
                try:
                    url = "https://data-api.polymarket.com/positions"
                    params = {
                        "user": "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
                    }
                    positions = requests.get(url, params=params, timeout=5).json()
                    inventory_balancing(games, positions)
                    break
                except Exception as e:
                    if retry < 2:
                        time.sleep(0.01)

        for game in games:
            try:
                order_info = calculate_live_odds(games[game]['kalshi_slug'])

                if ((order_info['bid_price'] != bid_price[game] or  order_info['ask_price'] != ask_price[game]) and
                    (order_info['bid_price'] > 0.02 and order_info['ask_price'] > 0.02) and
                    (order_info['bid_price'] < 0.98 and order_info['ask_price'] < 0.98)):

                    bid_price[game] = order_info['bid_price']
                    ask_price[game] = order_info['ask_price']

                    resp = post_orders(order_info,
                                       [games[game]['yes_token'], games[game]['no_token']],
                                       games[game]['yes_token_position']-games[game]['no_token_position'])
                    if resp != "Order Failed" and resp != "Market Data Not Available":
                        print("YES CHANGE",
                              datetime.datetime.now(),
                              bid_price[game], round(resp[1], 2),
                              round(1.0-ask_price[game], 2), round(resp[0], 2),
                              game)
                    else:
                        print("NO  CHANGE",
                              datetime.datetime.now(),
                              order_info['bid_price'],
                              order_info['ask_price'],
                              game)
                else:
                    print("NO  CHANGE",
                          datetime.datetime.now(),
                          order_info['bid_price'],
                          order_info['ask_price'],
                          game)
            except Exception as e:
                continue

        counter = counter+1
    except Exception as e:
        continue
