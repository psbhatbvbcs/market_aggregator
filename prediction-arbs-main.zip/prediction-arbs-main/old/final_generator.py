import json
import pandas as pd
from datetime import datetime, timezone

# === FILE PATHS ===
csv_path = "arbitrage_data.csv"
bot_jsonl_path = "arbitrage_executions.jsonl"
trades_json_path = "trades_kxnflgame-25oct12dalcar_20251014_051526.json"
output_csv_path = "arbitrage_data_with_actuals.csv"

# === LOAD CSV ===
df = pd.read_csv(csv_path)

# --- Helper: ISO → epoch seconds ---
def iso_to_epoch(ts_str):
    try:
        return datetime.fromisoformat(ts_str.replace("Z", "+00:00")).timestamp()
    except Exception:
        return None

# === Load bot arbitrage executions ===
arb_rows = []
with open(bot_jsonl_path, "r") as f:
    for i, line in enumerate(f):
        try:
            data = json.loads(line)
            arb_ts = iso_to_epoch(data.get("timestamp"))
            arb_inner_ts = iso_to_epoch(data.get("arbitrage", {}).get("timestamp"))
            arb_ts_final = arb_inner_ts or arb_ts
            orders = data.get("orders", [])
            for order in orders:
                exchange = order.get("exchange", "").lower()
                order_data = order.get("order", {})
                if exchange == "kalshi" and isinstance(order_data, dict):
                    oid = order_data.get("order_id")
                    if oid:
                        arb_rows.append({
                            "exchange": "kalshi",
                            "order_id": oid,
                            "timestamp": arb_ts_final,
                            "row_index": i
                        })
                elif exchange == "polymarket":
                    for inner in order_data.get("orders", []):
                        arb_rows.append({
                            "exchange": "polymarket",
                            "timestamp": arb_ts_final,
                            "row_index": i
                        })
        except Exception as e:
            print(f"⚠️ Line {i} skipped: {e}")

# === Load trades ===
with open(trades_json_path, "r") as f:
    trades = json.load(f)

kalshi_lookup = {
    t.get("order_id"): t
    for t in trades.get("kalshi_trades", [])
    if t.get("order_id")
}

# Normalize polymarket timestamps
poly_trades = []
for t in trades.get("polymarket_trades", []):
    try:
        ts = float(t.get("timestamp"))
        t["timestamp"] = ts
        poly_trades.append(t)
    except Exception:
        continue

# === Add columns ===
df["actual_kalshi_price"] = None
df["actual_polymarket_price"] = None
df["kalshi_filled_count"] = None
df["polymarket_filled_count"] = None

# === Apply +5.5 hour offset (for IST to UTC alignment) ===
OFFSET_SECONDS = 5.5 * 3600  # 19800 seconds

# === Match trades ===
for row in arb_rows:
    idx = row["row_index"]
    ex = row["exchange"]

    if ex == "kalshi":
        oid = row.get("order_id")
        trade = kalshi_lookup.get(oid)
        if trade:
            df.at[idx, "actual_kalshi_price"] = trade.get("execution_price")
            df.at[idx, "kalshi_filled_count"] = trade.get("filled_count")

    elif ex == "polymarket":
        arb_ts = row.get("timestamp")
        if not arb_ts:
            continue

        # Correct for local timezone (shift to UTC)
        arb_ts_corrected = arb_ts + OFFSET_SECONDS

        # Find closest polymarket trade within ±1 hour
        closest = None
        min_diff = float("inf")
        for t in poly_trades:
            diff = abs(t["timestamp"] - arb_ts_corrected)
            if diff < min_diff:
                min_diff = diff
                closest = t

        if closest and min_diff <= 3600:
            df.at[idx, "actual_polymarket_price"] = closest.get("execution_price")
            df.at[idx, "polymarket_filled_count"] = closest.get("size")

# === Save ===
df.to_csv(output_csv_path, index=False)
print(f"✅ Enriched CSV saved to {output_csv_path}")

# --- Debug summary ---
poly_prices = df["actual_polymarket_price"].dropna().unique()
print("\n--- MATCH SUMMARY ---")
print(f"Matched {len(poly_prices)} unique Polymarket prices: {poly_prices}")
kalshi_prices = df["actual_kalshi_price"].dropna().unique()
print(f"Matched {len(kalshi_prices)} unique Kalshi prices: {kalshi_prices}")
