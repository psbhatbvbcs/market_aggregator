import requests
import asyncio
import websockets
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import threading
from collections import defaultdict
import re
import ast
# from .matcher import SportsMarketSlugFinder

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
KALSHI_WSS = "wss://api.elections.kalshi.com/trade-api/ws/v2"
POLYMARKET_GAMMA = "https://gamma-api.polymarket.com"
POLYMARKET_CLOB = "https://clob.polymarket.com"

prices = {
    'kalshi': {'home_yes': 0, 'home_no': 0, 'away_yes': 0, 'away_no': 0, 'tie_yes': 0, 'tie_no': 0},
    'polymarket': {'home_yes': 0, 'home_no': 0, 'away_yes': 0, 'away_no': 0, 'tie_yes': 0, 'tie_no': 0}
}
price_lock = threading.Lock()
last_update = {'kalshi': datetime.now(), 'polymarket': datetime.now()}

class JSONLWriter:
    def __init__(self, filename: str):
        self.file = open(filename, 'a')
    
    def write(self, obj: dict) -> None:
        """Write a JSON object as a new line."""
        self.file.write(json.dumps(obj) + '\n')
        self.file.flush()  # Ensure data is written to disk
    
    def close(self):
        """Close the file."""
        self.file.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

poly_prices = JSONLWriter('poly_prices.jsonl')  
kalshi_prices = JSONLWriter('kalshi_prices.jsonl')  

class UniversalMarketFinder:
    def __init__(self):
        self.league_mappings = {
            "nfl": {
                "kalshi_prefix": "kxnflgame",
                "kalshi_series": "KXNFLGAME",
                "polymarket_prefix": "nfl",
                "has_tie": False
            },
            "cfb": {
                "kalshi_prefix": "kxncaafgame",
                "kalshi_series": "KXNCAAFGAME",
                "polymarket_prefix": "cfb",
                "has_tie": False
            },
            "mlb": {
                "kalshi_prefix": "kxmlbgame",
                "kalshi_series": "KXMLBGAME",
                "polymarket_prefix": "mlb",
                "has_tie": False
            },
            "epl": {
                "kalshi_prefix": "kxeplgame",
                "kalshi_series": "KXEPLGAME",
                "polymarket_prefix": "epl",
                "has_tie": True
            },
            "serie a": {
                "kalshi_prefix": "kxserieagame",
                "kalshi_series": "KXSERIEAGAME",
                "polymarket_prefix": "sea",
                "has_tie": True
            },
            "bundesliga": {
                "kalshi_prefix": "kxbundesligagame",
                "kalshi_series": "KXBUNDESLIGAGAME",
                "polymarket_prefix": "bun",
                "has_tie": True
            },
            "la liga": {
                "kalshi_prefix": "kxlaligagame",
                "kalshi_series": "KXLALIGAGAME",
                "polymarket_prefix": "lal",
                "has_tie": True
            },
            "ligue 1": {
                "kalshi_prefix": "kxligue1game",
                "kalshi_series": "KXLIGUE1GAME",
                "polymarket_prefix": "fl1",
                "has_tie": True
            },
            "champions league": {
                "kalshi_prefix": "kxuclgame",
                "kalshi_series": "KXUCLGAME",
                "polymarket_prefix": "ucl",
                "has_tie": True
            }
        }

        self.team_abbreviations = {
            "osasuna": ["osa", "osasu", "pamplona", "osasuna"],
            "getafe": ["get", "geta", "gtfe", "azulones", "getafe"],
            "barcelona": ["bar", "barca", "fcb", "barcelona"],
            "real madrid": ["rma", "real", "madrid", "rmadrid"],
            "atletico": ["atl", "atleti", "atletico", "atm"],
            "bayern": ["bay", "fcb", "munich", "fcbayern"],
            "dortmund": ["bvb", "dor", "bor", "borussia"],
            "leipzig": ["rbl", "leipzig", "rbleipzig"],
            "hoffenheim": ["hof", "tsg", "1899"],
            "koln": ["koe", "col", "fckoln", "cologne"],
            "leeds": ["lee", "leed", "leedsutd", "lufc"],
            "tottenham": ["tot", "thfc", "spurs"],
            "manchester united": ["mun", "manutd", "united"],
            "manchester city": ["mci", "mancity", "city"],
            "liverpool": ["liv", "lfc", "pool"],
            "chelsea": ["che", "cfc", "blues"],
            "arsenal": ["ars", "afc", "gunners"],
            "juventus": ["juv", "juve"],
            "milan": ["mil", "acmilan"],
            "inter": ["int", "inter", "intermilan"],
            "napoli": ["nap", "napoli"],
            "roma": ["rom", "roma", "asroma"],
            "verona": ["ver", "vero", "hellas"],
            "sassuolo": ["sas", "sass"],
            "paris": ["par", "psg", "pfc", "parissg"],
            "lorient": ["lor", "fcl"],
            "marseille": ["mar", "mars", "om"],
            "lyon": ["lyo", "lyon", "ol"],
            "monaco": ["mon", "monaco", "asm"],
            "mariners": ["sea", "mariners"],
            "tigers": ["det", "tigers"],
            "blue jays": ["tor", "blue jays"],
            "yankees": ["nyy", "yankees"],
            "brewers": ["mil", "brewers"],
            "cubs": ["chc", "cubs"]
        }

        self.abbreviation_lookup = {}
        for full_name, abbrevs in self.team_abbreviations.items():
            for abbrev in abbrevs:
                self.abbreviation_lookup[abbrev.lower()] = abbrevs

    def normalize_team_name(self, team_name: str) -> List[str]:
        team_name_lower = team_name.lower().strip()
        if team_name_lower in self.abbreviation_lookup:
            return self.abbreviation_lookup[team_name_lower]
        for full_name, abbrevs in self.team_abbreviations.items():
            if full_name in team_name_lower or team_name_lower in full_name:
                return abbrevs
            for abbrev in abbrevs:
                if abbrev == team_name_lower:
                    return abbrevs
        if len(team_name_lower) <= 4:
            return [team_name_lower, team_name_lower[:3]]
        parts = team_name_lower.split()
        if len(parts) > 1:
            return [parts[0][:3], parts[-1][:3], ''.join([p[0] for p in parts])]
        else:
            return [team_name_lower[:3], team_name_lower[:4]]

    def find_kalshi_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]

        try:
            response = requests.get(
                f"{KALSHI_BASE}/events",
                params={"series_ticker": league_info['kalshi_series'], "status": "open", "limit": 100},
                timeout=10
            )

            if response.status_code == 200:
                data = response.json()
                events = data.get("events", [])

                team1_variants = self.normalize_team_name(team1)
                team2_variants = self.normalize_team_name(team2)

                for event in events:
                    event_ticker = event.get("event_ticker", "")
                    event_ticker_lower = event_ticker.lower()

                    team1_found = any(t in event_ticker_lower for t in team1_variants)
                    team2_found = any(t in event_ticker_lower for t in team2_variants)

                    if team1_found and team2_found:
                        print(f"Found Kalshi event: {event_ticker}")

                        markets_response = requests.get(
                            f"{KALSHI_BASE}/markets",
                            params={"event_ticker": event_ticker, "limit": 100},
                            timeout=10
                        )

                        if markets_response.status_code == 200:
                            markets = markets_response.json().get("markets", [])

                            result = {
                                'event_ticker': event_ticker,
                                'home_win': None,
                                'away_win': None,
                                'tie': None
                            }

                            print(f"Found {len(markets)} markets for event {event_ticker}:")
                            for market in markets:
                                print(f"  - {market.get('ticker')}: {market.get('title')}")

                            for market in markets:
                                ticker = market.get("ticker", "")
                                ticker_upper = ticker.upper()

                                if league_info['has_tie']:
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        if suffix == "tie" or suffix == "draw":
                                            result['tie'] = ticker
                                            print(f"  Matched tie/draw: {ticker}")
                                        elif any(t.upper() in suffix.upper() for t in team1_variants):
                                            result['home_win'] = ticker
                                            print(f"  Matched home ({team1}) win: {ticker}")
                                        elif any(t.upper() in suffix.upper() for t in team2_variants):
                                            result['away_win'] = ticker
                                            print(f"  Matched away ({team2}) win: {ticker}")
                                else:
                                    # For non-tie markets (like MLB, NFL)
                                    # The ticker suffix tells us which team wins
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        # Check if suffix matches team1 (home team)
                                        if any(t.lower() in suffix for t in team1_variants):
                                            result['home_win'] = ticker
                                            print(f"  Matched home ({team1}) win: {ticker}")
                                        # Check if suffix matches team2 (away team)
                                        elif any(t.lower() in suffix for t in team2_variants):
                                            result['away_win'] = ticker
                                            print(f"  Matched away ({team2}) win: {ticker}")

                            print(f"Returning: {result}")
                            return result
        except Exception as e:
            print(f"Error fetching Kalshi markets: {e}")

        return None
    
    def find_polymarket_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]
        team1_abbrev = self.normalize_team_name(team1)[0].lower()
        team2_abbrev = self.normalize_team_name(team2)[0].lower()

        result = {
            'tokens': {},
            'slugs': {}
        }

        if league_info['has_tie'] and game_date:
            date_str = game_date.strftime("%Y-%m-%d")
            base_slug = f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}"

            market_slugs = {
                'home_win': f"{base_slug}-{team1_abbrev}",
                'tie': f"{base_slug}-draw",
                'away_win': f"{base_slug}-{team2_abbrev}"
            }

            for market_type, slug in market_slugs.items():
                try:
                    resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                    if resp.status_code == 200:
                        markets = resp.json()
                        if isinstance(markets, list) and len(markets) > 0:
                            market = markets[0]

                            raw_ids = market.get('clobTokenIds')
                            if raw_ids:
                                try:
                                    if isinstance(raw_ids, str):
                                        clob_token_ids = ast.literal_eval(raw_ids)
                                    else:
                                        clob_token_ids = raw_ids

                                    if isinstance(clob_token_ids, list) and len(clob_token_ids) >= 1:
                                        yes_token = str(clob_token_ids[0])
                                        result['tokens'][market_type] = yes_token
                                        result['slugs'][market_type] = slug
                                        print(f"Found Polymarket {market_type}: {slug}")
                                except Exception as e:
                                    print(f"Error parsing tokens for {slug}: {e}")
                except Exception as e:
                    print(f"Error fetching {slug}: {e}")

            return result

        else:
            try:
                if game_date:

                    date_str = game_date.strftime("%Y-%m-%d")
                    slug = f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}"
                    print("slug", slug)
                    resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                    print(f"{POLYMARKET_GAMMA}/markets?slug={slug}")
                    if resp.status_code == 200:
                        markets = resp.json()
                        # print(markets)
                        if isinstance(markets, list) and len(markets) > 0:
                            market = markets[0]
                            raw_ids = json.loads(market.get('clobTokenIds'))
                            if raw_ids:
                                try:
                                    if isinstance(raw_ids, str):
                                        clob_token_ids = json.loads(raw_ids)
                                        # print(clob_token_ids)
                                    else:
                                        clob_token_ids = raw_ids

                                    outcomes = market.get('outcomes', [])
                                    
                                    # Add this line to parse the JSON string:
                                    if isinstance(outcomes, str):
                                        outcomes = json.loads(outcomes)
                                        # print(outcomes)

                                    team1_variants = self.normalize_team_name(team1)
                                    team2_variants = self.normalize_team_name(team2)
                                    # print(team1_variants, team2_variants)

                                    for i, outcome in enumerate(outcomes):
                                        if i >= len(clob_token_ids):
                                            continue
                                        outcome_lower = (outcome or "").lower()

                                        if any(t in outcome_lower for t in team1_variants):
                                            result['tokens']['home_win'] = str(clob_token_ids[i])
                                        elif any(t in outcome_lower for t in team2_variants):
                                            result['tokens']['away_win'] = str(clob_token_ids[i])

                                    result['slugs']['market'] = slug
                                    return result
                                except Exception as e:
                                    print(f"Error parsing tokens: {e}")

            except Exception as e:
                print(f"Error searching Polymarket: {e}")
        print("poly return:", result)
        return result

async def fetch_polymarket_prices(polymarket_tokens, has_tie):
    for market_type, token_id in polymarket_tokens.items():
        if token_id:
            try:
                book_url = f"{POLYMARKET_CLOB}/book?token_id={token_id}"
                book_response = requests.get(book_url, timeout=5)
                poly_prices.write(book_response.json())
                if book_response.status_code == 200:
                    book_data = book_response.json()

                    bids = book_data.get('bids', [])
                    asks = book_data.get('asks', [])

                    best_bid_price = 0
                    best_ask_price = 0

                    if bids and len(bids) > 0:
                        best_bid_price = float(bids[-1]['price'])  # Use -1 like your reference

                    if asks and len(asks) > 0:
                        best_ask_price = float(asks[-1]['price'])  # Use -1 not 0!

                    # Use bid price as the YES price (matching your reference script)
                    yes_price = best_bid_price if best_bid_price > 0 else best_ask_price

                    if yes_price > 0:
                        with price_lock:
                            if market_type == 'home_win':
                                prices['polymarket']['home_yes'] = yes_price
                                prices['polymarket']['home_no'] = 1.0 - yes_price
                            elif market_type == 'away_win':
                                prices['polymarket']['away_yes'] = yes_price
                                prices['polymarket']['away_no'] = 1.0 - yes_price
                            elif has_tie and market_type == 'tie':
                                prices['polymarket']['tie_yes'] = yes_price
                                prices['polymarket']['tie_no'] = 1.0 - yes_price

            except Exception as e:
                pass

    last_update['polymarket'] = datetime.now()

async def fetch_initial_prices(kalshi_markets, polymarket_tokens, has_tie):
    if kalshi_markets:
        for market_type, ticker in kalshi_markets.items():
            if ticker and market_type != 'event_ticker':
                try:
                    market_url = f"{KALSHI_BASE}/markets/{ticker}"
                    market_response = requests.get(market_url, timeout=5)
                    
                    if market_response.status_code == 200:
                        market_data = market_response.json().get('market', {})

                        with price_lock:
                            yes_bid = market_data.get('yes_bid', 0) / 100.0 if market_data.get('yes_bid') else 0
                            yes_ask = market_data.get('yes_ask', 0) / 100.0 if market_data.get('yes_ask') else 0
                            no_bid = market_data.get('no_bid', 0) / 100.0 if market_data.get('no_bid') else 0
                            no_ask = market_data.get('no_ask', 0) / 100.0 if market_data.get('no_ask') else 0
                            last_price = market_data.get('last_price', 0) / 100.0 if market_data.get('last_price') else 0

                            if yes_ask == 0 and last_price > 0:
                                yes_ask = last_price

                            if market_type == 'home_win':
                                prices['kalshi']['home_yes'] = yes_ask
                                prices['kalshi']['home_no'] = no_ask
                            elif market_type == 'away_win':
                                prices['kalshi']['away_yes'] = yes_ask
                                prices['kalshi']['away_no'] = no_ask
                            elif has_tie and market_type == 'tie':
                                prices['kalshi']['tie_yes'] = yes_ask
                                prices['kalshi']['tie_no'] = no_ask

                        print(f"Fetched Kalshi {market_type}: YES={yes_ask:.2f}, NO={no_ask:.2f}")

                except Exception as e:
                    print(f"Error fetching initial Kalshi prices for {ticker}: {e}")

    if polymarket_tokens:
        await fetch_polymarket_prices(polymarket_tokens, has_tie)

async def kalshi_websocket(markets: Dict, has_tie: bool, polymarket_tokens: Dict):
    async def fetch_market_prices():
        for market_type, ticker in markets.items():
            if ticker and market_type != 'event_ticker':
                try:
                    print("lols", f"{KALSHI_BASE}/markets/{ticker}")
                    market_url = f"{KALSHI_BASE}/markets/{ticker}"
                    response = requests.get(market_url, timeout=5)

                    if response.status_code == 200:
                        market_data = response.json().get('market', {})
                        kalshi_prices.write(market_data)
                        # print("kalshi response: ", market_data)
                        with price_lock:
                            yes_bid = market_data.get('yes_bid', 0) / 100.0 if market_data.get('yes_bid') else 0
                            yes_ask = market_data.get('yes_ask', 0) / 100.0 if market_data.get('yes_ask') else 0
                            no_bid = market_data.get('no_bid', 0) / 100.0 if market_data.get('no_bid') else 0
                            no_ask = market_data.get('no_ask', 0) / 100.0 if market_data.get('no_ask') else 0
                            last_price = market_data.get('last_price', 0) / 100.0 if market_data.get('last_price') else 0

                            if yes_ask == 0 and last_price > 0:
                                yes_ask = last_price

                            if market_type == 'home_win':
                                prices['kalshi']['home_yes'] = yes_ask
                                prices['kalshi']['home_no'] = no_ask
                            elif market_type == 'away_win':
                                prices['kalshi']['away_yes'] = yes_ask
                                prices['kalshi']['away_no'] = no_ask
                            elif has_tie and market_type == 'tie':
                                prices['kalshi']['tie_yes'] = yes_ask
                                prices['kalshi']['tie_no'] = no_ask

                            last_update['kalshi'] = datetime.now()
                except Exception as e:
                    pass

    async def periodic_rest_update():
        while True:
            await fetch_market_prices()
            await asyncio.sleep(2)
            if polymarket_tokens:
                await fetch_polymarket_prices(polymarket_tokens, has_tie)

    rest_task = asyncio.create_task(periodic_rest_update())

    while True:
        try:
            headers = {
                "KALSHI-ACCESS-KEY": "39bb4b72-782d-432e-84e6-f228d2e4703d"
            }
            async with websockets.connect(KALSHI_WSS, extra_headers=headers) as websocket:
                print("markets", markets)
                for market_type, ticker in markets.items():
                    if ticker and market_type != 'event_ticker':
                        subscribe_msg = {
                            "id": 1,
                            "cmd": "subscribe",
                            "params": {
                                "channels": ["orderbook_delta"],
                                "market_ticker": ticker
                            }
                        }
                        await websocket.send(json.dumps(subscribe_msg))

                while True:
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=30)
                        # if polymarket_tokens:
                        #     fetch_polymarket_prices(polymarket_tokens, has_tie)
                        data = json.loads(message)
                        print("kalsi", data)
                        kalshi_prices.write(data)
                        if 'type' in data and data['type'] == 'orderbook_delta':
                            ticker = data.get('market_ticker')

                            with price_lock:
                                if ticker == markets.get('home_win'):
                                    if 'no' in data and data['no'] and len(data['no']) > 0:
                                        no_prices = [bid[0] for bid in data['no']]
                                        best_no_bid = max(no_prices) / 100.0
                                        yes_ask = 1.0 - best_no_bid
                                        prices['kalshi']['home_yes'] = yes_ask
                                    if 'yes' in data and data['yes'] and len(data['yes']) > 0:
                                        yes_prices = [bid[0] for bid in data['yes']]
                                        best_yes_bid = max(yes_prices) / 100.0
                                        no_ask = 1.0 - best_yes_bid
                                        prices['kalshi']['home_no'] = no_ask

                                elif ticker == markets.get('away_win'):
                                    if 'no' in data and data['no'] and len(data['no']) > 0:
                                        no_prices = [bid[0] for bid in data['no']]
                                        best_no_bid = max(no_prices) / 100.0
                                        yes_ask = 1.0 - best_no_bid
                                        prices['kalshi']['away_yes'] = yes_ask
                                    if 'yes' in data and data['yes'] and len(data['yes']) > 0:
                                        yes_prices = [bid[0] for bid in data['yes']]
                                        best_yes_bid = max(yes_prices) / 100.0
                                        no_ask = 1.0 - best_yes_bid
                                        prices['kalshi']['away_no'] = no_ask

                                elif has_tie and ticker == markets.get('tie'):
                                    if 'no' in data and data['no'] and len(data['no']) > 0:
                                        no_prices = [bid[0] for bid in data['no']]
                                        best_no_bid = max(no_prices) / 100.0
                                        yes_ask = 1.0 - best_no_bid
                                        prices['kalshi']['tie_yes'] = yes_ask
                                    if 'yes' in data and data['yes'] and len(data['yes']) > 0:
                                        yes_prices = [bid[0] for bid in data['yes']]
                                        best_yes_bid = max(yes_prices) / 100.0
                                        no_ask = 1.0 - best_yes_bid
                                        prices['kalshi']['tie_no'] = no_ask

                                last_update['kalshi'] = datetime.now()

                    except asyncio.TimeoutError:
                        print("timeout")
                        await websocket.send(json.dumps({"type": "ping"}))
                    except Exception as e:
                        print("lolesh", e)
                        break

        except Exception as e:
            print("exception here", e)
            await asyncio.sleep(5)

async def periodic_polymarket_update(polymarket_tokens, has_tie):
    while True:
        await asyncio.sleep(2)
        await fetch_polymarket_prices(polymarket_tokens, has_tie)

def display_best_prices(team1: str, team2: str, has_tie: bool):
    print("\n" + "="*80)
    print(f"REAL-TIME PRICES - {team1} vs {team2} - {datetime.now().strftime('%H:%M:%S')}")
    print("="*80)

    with price_lock:
        print(f"{'Market':<20} {'Kalshi':<15} {'Polymarket':<15} {'Delta (K-P)':<15} {'Best':<10}")
        print("-"*80)

        if has_tie:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no'),
                ('Tie/Draw YES', 'tie_yes'),
                ('Tie/Draw NO', 'tie_no')
            ]
        else:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no')
            ]

        for market_name, key in markets:
            kalshi_price = prices['kalshi'][key]
            poly_price = prices['polymarket'][key]

            if kalshi_price == 0 and poly_price == 0:
                continue

            delta = kalshi_price - poly_price

            kalshi_str = f"${kalshi_price:.2f}" if kalshi_price > 0 else "N/A"
            poly_str = f"${poly_price:.2f}" if poly_price > 0 else "N/A"

            if delta > 0:
                delta_str = f"+${delta:.2f}"
                best = "Kalshi"
            elif delta < 0:
                delta_str = f"-${abs(delta):.2f}"
                best = "Poly"
            else:
                delta_str = "$0.00"
                best = "Equal"

            if kalshi_price == 0:
                best = "Poly only"
                delta_str = "N/A"
            elif poly_price == 0:
                best = "Kalshi only"
                delta_str = "N/A"

            print(f"{market_name:<20} {kalshi_str:<15} {poly_str:<15} {delta_str:<15} {best:<10}")

    print("-"*80)

    with price_lock:
        kalshi_update = (datetime.now() - last_update['kalshi']).total_seconds()
        poly_update = (datetime.now() - last_update['polymarket']).total_seconds()
        print(f"Last update: Kalshi {kalshi_update:.1f}s ago, Polymarket {poly_update:.1f}s ago")
    print("="*80)

def detect_arbitrage_1(has_tie: bool, min_shares: int = 100):
    """Detect arbitrage opportunities across both exchanges"""
    with price_lock:
        # YES arbitrage: Buy all YES tokens for less than $1
        best_home_yes = min(
            prices['kalshi']['home_yes'] if prices['kalshi']['home_yes'] > 0 else float('inf'),
            prices['polymarket']['home_yes'] if prices['polymarket']['home_yes'] > 0 else float('inf')
        )
        best_away_yes = min(
            prices['kalshi']['away_yes'] if prices['kalshi']['away_yes'] > 0 else float('inf'),
            prices['polymarket']['away_yes'] if prices['polymarket']['away_yes'] > 0 else float('inf')
        )
        
        yes_arb = None
        if has_tie:
            best_tie_yes = min(
                prices['kalshi']['tie_yes'] if prices['kalshi']['tie_yes'] > 0 else float('inf'),
                prices['polymarket']['tie_yes'] if prices['polymarket']['tie_yes'] > 0 else float('inf')
            )
            total_yes_cost = best_home_yes + best_away_yes + best_tie_yes
            
            if total_yes_cost < float('inf') and total_yes_cost < 1.0:
                profit_per_share = 1.0 - total_yes_cost
                total_profit = profit_per_share * min_shares
                yes_arb = {
                    'type': 'YES',
                    'home_price': best_home_yes,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_yes'] > 0 and prices['kalshi']['home_yes'] <= prices['polymarket']['home_yes'] else 'Polymarket',
                    'away_price': best_away_yes,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_yes'] > 0 and prices['kalshi']['away_yes'] <= prices['polymarket']['away_yes'] else 'Polymarket',
                    'tie_price': best_tie_yes,
                    'tie_exchange': 'Kalshi' if prices['kalshi']['tie_yes'] > 0 and prices['kalshi']['tie_yes'] <= prices['polymarket']['tie_yes'] else 'Polymarket',
                    'total_cost': total_yes_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        else:
            total_yes_cost = best_home_yes + best_away_yes
            
            if total_yes_cost < float('inf') and total_yes_cost < 1.0:
                profit_per_share = 1.0 - total_yes_cost
                total_profit = profit_per_share * min_shares
                yes_arb = {
                    'type': 'YES',
                    'home_price': best_home_yes,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_yes'] > 0 and prices['kalshi']['home_yes'] <= prices['polymarket']['home_yes'] else 'Polymarket',
                    'away_price': best_away_yes,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_yes'] > 0 and prices['kalshi']['away_yes'] <= prices['polymarket']['away_yes'] else 'Polymarket',
                    'total_cost': total_yes_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        
        # NO arbitrage: Buy all NO tokens for less than $2 (or $3 with tie)
        best_home_no = min(
            prices['kalshi']['home_no'] if prices['kalshi']['home_no'] > 0 else float('inf'),
            prices['polymarket']['home_no'] if prices['polymarket']['home_no'] > 0 else float('inf')
        )
        best_away_no = min(
            prices['kalshi']['away_no'] if prices['kalshi']['away_no'] > 0 else float('inf'),
            prices['polymarket']['away_no'] if prices['polymarket']['away_no'] > 0 else float('inf')
        )
        
        no_arb = None
        if has_tie:
            best_tie_no = min(
                prices['kalshi']['tie_no'] if prices['kalshi']['tie_no'] > 0 else float('inf'),
                prices['polymarket']['tie_no'] if prices['polymarket']['tie_no'] > 0 else float('inf')
            )
            total_no_cost = best_home_no + best_away_no + best_tie_no
            max_no_cost = 3.0  # Three NO tokens should cost less than $3
            
            if total_no_cost < float('inf') and total_no_cost < max_no_cost:
                profit_per_share = max_no_cost - total_no_cost
                total_profit = profit_per_share * min_shares
                no_arb = {
                    'type': 'NO',
                    'home_price': best_home_no,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_no'] > 0 and prices['kalshi']['home_no'] <= prices['polymarket']['home_no'] else 'Polymarket',
                    'away_price': best_away_no,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_no'] > 0 and prices['kalshi']['away_no'] <= prices['polymarket']['away_no'] else 'Polymarket',
                    'tie_price': best_tie_no,
                    'tie_exchange': 'Kalshi' if prices['kalshi']['tie_no'] > 0 and prices['kalshi']['tie_no'] <= prices['polymarket']['tie_no'] else 'Polymarket',
                    'total_cost': total_no_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        else:
            total_no_cost = best_home_no + best_away_no
            max_no_cost = 2.0  # Two NO tokens should cost less than $2
            
            if total_no_cost < float('inf') and total_no_cost < max_no_cost:
                profit_per_share = max_no_cost - total_no_cost
                total_profit = profit_per_share * min_shares
                no_arb = {
                    'type': 'NO',
                    'home_price': best_home_no,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_no'] > 0 and prices['kalshi']['home_no'] <= prices['polymarket']['home_no'] else 'Polymarket',
                    'away_price': best_away_no,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_no'] > 0 and prices['kalshi']['away_no'] <= prices['polymarket']['away_no'] else 'Polymarket',
                    'total_cost': total_no_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        
        return yes_arb, no_arb

def detect_arbitrage(has_tie: bool, min_shares: int = 100):
    """Detect arbitrage opportunities across both exchanges"""
    with price_lock:
        # YES arbitrage: Buy all YES tokens for less than $1
        best_home_yes = min(
            prices['kalshi']['home_yes'] if prices['kalshi']['home_yes'] > 0 else float('inf'),
            prices['polymarket']['home_yes'] if prices['polymarket']['home_yes'] > 0 else float('inf')
        )
        best_away_yes = min(
            prices['kalshi']['away_yes'] if prices['kalshi']['away_yes'] > 0 else float('inf'),
            prices['polymarket']['away_yes'] if prices['polymarket']['away_yes'] > 0 else float('inf')
        )
        
        yes_arb = None
        if has_tie:
            best_tie_yes = min(
                prices['kalshi']['tie_yes'] if prices['kalshi']['tie_yes'] > 0 else float('inf'),
                prices['polymarket']['tie_yes'] if prices['polymarket']['tie_yes'] > 0 else float('inf')
            )
            total_yes_cost = best_home_yes + best_away_yes + best_tie_yes
            
            if total_yes_cost < float('inf') and total_yes_cost < 1.0:
                profit_per_share = 1.0 - total_yes_cost
                total_profit = profit_per_share * min_shares
                yes_arb = {
                    'type': 'YES',
                    'home_price': best_home_yes,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_yes'] > 0 and prices['kalshi']['home_yes'] <= prices['polymarket']['home_yes'] else 'Polymarket',
                    'away_price': best_away_yes,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_yes'] > 0 and prices['kalshi']['away_yes'] <= prices['polymarket']['away_yes'] else 'Polymarket',
                    'tie_price': best_tie_yes,
                    'tie_exchange': 'Kalshi' if prices['kalshi']['tie_yes'] > 0 and prices['kalshi']['tie_yes'] <= prices['polymarket']['tie_yes'] else 'Polymarket',
                    'total_cost': total_yes_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        else:
            # For 2-outcome markets, YES arbitrage doesn't make sense (both teams can't win)
            # But we check anyway in case of severe mispricing
            total_yes_cost = best_home_yes + best_away_yes
            
            if total_yes_cost < float('inf') and total_yes_cost < 1.0:
                profit_per_share = 1.0 - total_yes_cost
                total_profit = profit_per_share * min_shares
                yes_arb = {
                    'type': 'YES',
                    'home_price': best_home_yes,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_yes'] > 0 and prices['kalshi']['home_yes'] <= prices['polymarket']['home_yes'] else 'Polymarket',
                    'away_price': best_away_yes,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_yes'] > 0 and prices['kalshi']['away_yes'] <= prices['polymarket']['away_yes'] else 'Polymarket',
                    'total_cost': total_yes_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        
        # NO arbitrage only makes sense for markets WITH ties (3+ outcomes)
        no_arb = None
        if has_tie:
            best_home_no = min(
                prices['kalshi']['home_no'] if prices['kalshi']['home_no'] > 0 else float('inf'),
                prices['polymarket']['home_no'] if prices['polymarket']['home_no'] > 0 else float('inf')
            )
            best_away_no = min(
                prices['kalshi']['away_no'] if prices['kalshi']['away_no'] > 0 else float('inf'),
                prices['polymarket']['away_no'] if prices['polymarket']['away_no'] > 0 else float('inf')
            )
            best_tie_no = min(
                prices['kalshi']['tie_no'] if prices['kalshi']['tie_no'] > 0 else float('inf'),
                prices['polymarket']['tie_no'] if prices['polymarket']['tie_no'] > 0 else float('inf')
            )
            total_no_cost = best_home_no + best_away_no + best_tie_no
            max_no_cost = 3.0  # Three NO tokens should cost less than $3
            
            if total_no_cost < float('inf') and total_no_cost < max_no_cost:
                profit_per_share = max_no_cost - total_no_cost
                total_profit = profit_per_share * min_shares
                no_arb = {
                    'type': 'NO',
                    'home_price': best_home_no,
                    'home_exchange': 'Kalshi' if prices['kalshi']['home_no'] > 0 and prices['kalshi']['home_no'] <= prices['polymarket']['home_no'] else 'Polymarket',
                    'away_price': best_away_no,
                    'away_exchange': 'Kalshi' if prices['kalshi']['away_no'] > 0 and prices['kalshi']['away_no'] <= prices['polymarket']['away_no'] else 'Polymarket',
                    'tie_price': best_tie_no,
                    'tie_exchange': 'Kalshi' if prices['kalshi']['tie_no'] > 0 and prices['kalshi']['tie_no'] <= prices['polymarket']['tie_no'] else 'Polymarket',
                    'total_cost': total_no_cost,
                    'profit_per_share': profit_per_share,
                    'total_profit': total_profit
                }
        
        return yes_arb, no_arb

def detect_cross_market_arbitrage(has_tie: bool, min_shares: int = 100):
    """
    Detect cross-market arbitrage for 2-outcome markets.
    For markets without ties: Team A NO = Team B YES, so we can mix and match.
    """
    if has_tie:
        # Cross-market arbitrage doesn't apply to 3-outcome markets
        return None
    
    with price_lock:
        # Strategy 1: Buy Home NO (= Away YES) + Away NO (= Home YES)
        best_home_no = min(
            prices['kalshi']['home_no'] if prices['kalshi']['home_no'] > 0 else float('inf'),
            prices['polymarket']['home_no'] if prices['polymarket']['home_no'] > 0 else float('inf')
        )
        best_away_no = min(
            prices['kalshi']['away_no'] if prices['kalshi']['away_no'] > 0 else float('inf'),
            prices['polymarket']['away_no'] if prices['polymarket']['away_no'] > 0 else float('inf')
        )
        
        total_cost = best_home_no + best_away_no
        
        if total_cost < float('inf') and total_cost < 1.0:
            profit_per_share = 1.0 - total_cost
            total_profit = profit_per_share * min_shares
            
            return {
                'type': 'CROSS-MARKET NO',
                'home_no_price': best_home_no,
                'home_no_exchange': 'Kalshi' if prices['kalshi']['home_no'] > 0 and prices['kalshi']['home_no'] <= prices['polymarket']['home_no'] else 'Polymarket',
                'away_no_price': best_away_no,
                'away_no_exchange': 'Kalshi' if prices['kalshi']['away_no'] > 0 and prices['kalshi']['away_no'] <= prices['polymarket']['away_no'] else 'Polymarket',
                'total_cost': total_cost,
                'profit_per_share': profit_per_share,
                'total_profit': total_profit
            }
    
    return None
   
def display_arbitrage_1(yes_arb, no_arb, team1: str, team2: str, has_tie: bool):
    """Display arbitrage opportunities if found and log them to file"""
    
    # Create log entry timestamp
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    if yes_arb:
        print("\n" + "🚨 " * 20)
        print("💰 YES TOKEN ARBITRAGE OPPORTUNITY DETECTED!")
        print("🚨 " * 20)
        print(f"Buy {team1} YES on {yes_arb['home_exchange']}: ${yes_arb['home_price']:.4f}")
        print(f"Buy {team2} YES on {yes_arb['away_exchange']}: ${yes_arb['away_price']:.4f}")
        if has_tie:
            print(f"Buy TIE YES on {yes_arb['tie_exchange']}: ${yes_arb['tie_price']:.4f}")
        print(f"\nTotal Cost: ${yes_arb['total_cost']:.4f}")
        print(f"Guaranteed Return: $1.00")
        print(f"Profit per share: ${yes_arb['profit_per_share']:.4f}")
        print(f"Total Profit (100 shares): ${yes_arb['total_profit']:.2f}")
        print("🚨 " * 20 + "\n")
        
        # Log to file
        try:
            with open('arbitrage_log.txt', 'a') as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{timestamp}] YES TOKEN ARBITRAGE\n")
                f.write(f"Match: {team1} vs {team2}\n")
                f.write(f"Buy {team1} YES on {yes_arb['home_exchange']}: ${yes_arb['home_price']:.4f}\n")
                f.write(f"Buy {team2} YES on {yes_arb['away_exchange']}: ${yes_arb['away_price']:.4f}\n")
                if has_tie:
                    f.write(f"Buy TIE YES on {yes_arb['tie_exchange']}: ${yes_arb['tie_price']:.4f}\n")
                f.write(f"Total Cost: ${yes_arb['total_cost']:.4f}\n")
                f.write(f"Profit per share: ${yes_arb['profit_per_share']:.4f}\n")
                f.write(f"Total Profit (100 shares): ${yes_arb['total_profit']:.2f}\n")
                f.write(f"{'='*80}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")
    
    if no_arb:
        print("\n" + "🚨 " * 20)
        print("💰 NO TOKEN ARBITRAGE OPPORTUNITY DETECTED!")
        print("🚨 " * 20)
        print(f"Buy {team1} NO on {no_arb['home_exchange']}: ${no_arb['home_price']:.4f}")
        print(f"Buy {team2} NO on {no_arb['away_exchange']}: ${no_arb['away_price']:.4f}")
        if has_tie:
            print(f"Buy TIE NO on {no_arb['tie_exchange']}: ${no_arb['tie_price']:.4f}")
        print(f"\nTotal Cost: ${no_arb['total_cost']:.4f}")
        print(f"Guaranteed Return: ${3.0 if has_tie else 2.0:.2f}")
        print(f"Profit per share: ${no_arb['profit_per_share']:.4f}")
        print(f"Total Profit (100 shares): ${no_arb['total_profit']:.2f}")
        print("🚨 " * 20 + "\n")
        
        # Log to file
        try:
            with open('arbitrage_log.txt', 'a') as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{timestamp}] NO TOKEN ARBITRAGE\n")
                f.write(f"Match: {team1} vs {team2}\n")
                f.write(f"Buy {team1} NO on {no_arb['home_exchange']}: ${no_arb['home_price']:.4f}\n")
                f.write(f"Buy {team2} NO on {no_arb['away_exchange']}: ${no_arb['away_price']:.4f}\n")
                if has_tie:
                    f.write(f"Buy TIE NO on {no_arb['tie_exchange']}: ${no_arb['tie_price']:.4f}\n")
                f.write(f"Total Cost: ${no_arb['total_cost']:.4f}\n")
                f.write(f"Profit per share: ${no_arb['profit_per_share']:.4f}\n")
                f.write(f"Total Profit (100 shares): ${no_arb['total_profit']:.2f}\n")
                f.write(f"{'='*80}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")

def display_arbitrage(yes_arb, no_arb, cross_arb, team1: str, team2: str, has_tie: bool):
    """Display arbitrage opportunities if found and log them to file"""
    
    # Create log entry timestamp
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    if yes_arb:
        print("\n" + "🚨 " * 20)
        print("💰 YES TOKEN ARBITRAGE OPPORTUNITY DETECTED!")
        print("🚨 " * 20)
        print(f"Buy {team1} YES on {yes_arb['home_exchange']}: ${yes_arb['home_price']:.4f}")
        print(f"Buy {team2} YES on {yes_arb['away_exchange']}: ${yes_arb['away_price']:.4f}")
        if has_tie:
            print(f"Buy TIE YES on {yes_arb['tie_exchange']}: ${yes_arb['tie_price']:.4f}")
        print(f"\nTotal Cost: ${yes_arb['total_cost']:.4f}")
        print(f"Guaranteed Return: $1.00")
        print(f"Profit per share: ${yes_arb['profit_per_share']:.4f}")
        print(f"Total Profit (100 shares): ${yes_arb['total_profit']:.2f}")
        print("🚨 " * 20 + "\n")
        
        # Log to file
        try:
            with open('arbitrage_log.txt', 'a') as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{timestamp}] YES TOKEN ARBITRAGE\n")
                f.write(f"Match: {team1} vs {team2}\n")
                f.write(f"Buy {team1} YES on {yes_arb['home_exchange']}: ${yes_arb['home_price']:.4f}\n")
                f.write(f"Buy {team2} YES on {yes_arb['away_exchange']}: ${yes_arb['away_price']:.4f}\n")
                if has_tie:
                    f.write(f"Buy TIE YES on {yes_arb['tie_exchange']}: ${yes_arb['tie_price']:.4f}\n")
                f.write(f"Total Cost: ${yes_arb['total_cost']:.4f}\n")
                f.write(f"Profit per share: ${yes_arb['profit_per_share']:.4f}\n")
                f.write(f"Total Profit (100 shares): ${yes_arb['total_profit']:.2f}\n")
                f.write(f"{'='*80}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")
    
    if no_arb:
        print("\n" + "🚨 " * 20)
        print("💰 NO TOKEN ARBITRAGE OPPORTUNITY DETECTED!")
        print("🚨 " * 20)
        print(f"Buy {team1} NO on {no_arb['home_exchange']}: ${no_arb['home_price']:.4f}")
        print(f"Buy {team2} NO on {no_arb['away_exchange']}: ${no_arb['away_price']:.4f}")
        if has_tie:
            print(f"Buy TIE NO on {no_arb['tie_exchange']}: ${no_arb['tie_price']:.4f}")
        print(f"\nTotal Cost: ${no_arb['total_cost']:.4f}")
        print(f"Guaranteed Return: ${3.0 if has_tie else 2.0:.2f}")
        print(f"Profit per share: ${no_arb['profit_per_share']:.4f}")
        print(f"Total Profit (100 shares): ${no_arb['total_profit']:.2f}")
        print("🚨 " * 20 + "\n")
        
        # Log to file
        try:
            with open('arbitrage_log.txt', 'a') as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{timestamp}] NO TOKEN ARBITRAGE\n")
                f.write(f"Match: {team1} vs {team2}\n")
                f.write(f"Buy {team1} NO on {no_arb['home_exchange']}: ${no_arb['home_price']:.4f}\n")
                f.write(f"Buy {team2} NO on {no_arb['away_exchange']}: ${no_arb['away_price']:.4f}\n")
                if has_tie:
                    f.write(f"Buy TIE NO on {no_arb['tie_exchange']}: ${no_arb['tie_price']:.4f}\n")
                f.write(f"Total Cost: ${no_arb['total_cost']:.4f}\n")
                f.write(f"Profit per share: ${no_arb['profit_per_share']:.4f}\n")
                f.write(f"Total Profit (100 shares): ${no_arb['total_profit']:.2f}\n")
                f.write(f"{'='*80}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")
    
    if cross_arb:
        print("\n" + "🚨 " * 20)
        print("💰 CROSS-MARKET ARBITRAGE OPPORTUNITY DETECTED!")
        print("🚨 " * 20)
        print(f"Buy {team1} NO on {cross_arb['home_no_exchange']}: ${cross_arb['home_no_price']:.4f}")
        print(f"  (This wins if {team2} wins)")
        print(f"Buy {team2} NO on {cross_arb['away_no_exchange']}: ${cross_arb['away_no_price']:.4f}")
        print(f"  (This wins if {team1} wins)")
        print(f"\nTotal Cost: ${cross_arb['total_cost']:.4f}")
        print(f"Guaranteed Return: $1.00")
        print(f"Profit per share: ${cross_arb['profit_per_share']:.4f}")
        print(f"Total Profit (100 shares): ${cross_arb['total_profit']:.2f}")
        print("🚨 " * 20 + "\n")
        
        # Log to file
        try:
            with open('arbitrage_log.txt', 'a') as f:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{timestamp}] CROSS-MARKET ARBITRAGE\n")
                f.write(f"Match: {team1} vs {team2}\n")
                f.write(f"Buy {team1} NO on {cross_arb['home_no_exchange']}: ${cross_arb['home_no_price']:.4f}\n")
                f.write(f"  (This wins if {team2} wins)\n")
                f.write(f"Buy {team2} NO on {cross_arb['away_no_exchange']}: ${cross_arb['away_no_price']:.4f}\n")
                f.write(f"  (This wins if {team1} wins)\n")
                f.write(f"Total Cost: ${cross_arb['total_cost']:.4f}\n")
                f.write(f"Profit per share: ${cross_arb['profit_per_share']:.4f}\n")
                f.write(f"Total Profit (100 shares): ${cross_arb['total_profit']:.2f}\n")
                f.write(f"{'='*80}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")

async def main():
    print("SUPPORTED LEAGUES:")
    print("- NFL, CFB")
    print("- MLB")
    print("- EPL, Serie A, Bundesliga, La Liga, Ligue 1, Champions League")
    print("\nEnter match details:")
    print("You can use team abbreviations (e.g., SF, LAR, PSG, BAR, OSA, GET)")

    team1 = input("Team 1 (home/first team): ").strip()
    team2 = input("Team 2 (away/second team): ").strip()
    league = input("League (NFL/CFB/MLB/EPL/Serie A/Bundesliga/La Liga/Ligue 1/Champions League): ").strip()

    date_str = input("Date (YYYY-MM-DD) or press Enter to skip: ").strip()
    if date_str:
        try:
            game_date = datetime.strptime(date_str, "%Y-%m-%d")
            print(f"Looking for matches on {game_date.strftime('%B %d, %Y')}")
        except:
            print("Invalid date format, proceeding without date filter")
            game_date = None
    else:
        game_date = None

    print("\nSearching for markets...")
    finder = UniversalMarketFinder()

    league_lower = league.lower()
    if league_lower not in finder.league_mappings:
        print(f"League '{league}' not supported")
        return

    has_tie = finder.league_mappings[league_lower]['has_tie']

    print("\n--- Searching Kalshi ---")
    kalshi_markets = finder.find_kalshi_markets(team1, team2, league, game_date)

    if not kalshi_markets or not kalshi_markets.get('event_ticker'):
        print(f"❌ Could not find Kalshi markets for {team1} vs {team2}")
        kalshi_markets = None
    else:
        print(f"✓ Found Kalshi event: {kalshi_markets['event_ticker']}")
        if kalshi_markets.get('home_win'):
            print(f"  {team1} win: {kalshi_markets['home_win']}")
        if kalshi_markets.get('away_win'):
            print(f"  {team2} win: {kalshi_markets['away_win']}")
        if has_tie and kalshi_markets.get('tie'):
            print(f"  Tie/Draw: {kalshi_markets['tie']}")

        if has_tie:
            if not kalshi_markets.get('home_win') or not kalshi_markets.get('away_win') or not kalshi_markets.get('tie'):
                print("  ⚠️  Warning: Some markets missing. Kalshi may not have all outcomes listed yet.")
        else:
            if not kalshi_markets.get('home_win') or not kalshi_markets.get('away_win'):
                print("  ⚠️  Warning: Some markets missing. Kalshi may not have all outcomes listed yet.")

    print("\n--- Searching Polymarket ---")
    polymarket_data = finder.find_polymarket_markets(team1, team2, league, game_date)
    print(polymarket_data)
    if not polymarket_data or not polymarket_data.get('tokens'):
        print(f"❌ Could not find Polymarket markets for {team1} vs {team2}")
        print("  Note: Polymarket may require exact date for sports markets")
        polymarket_tokens = {}
    else:
        polymarket_tokens = polymarket_data.get('tokens', {})
        print(f"✓ Found Polymarket markets:")

        if 'slugs' in polymarket_data:
            for market_type, slug in polymarket_data['slugs'].items():
                if slug and market_type in polymarket_tokens:
                    print(f"  {market_type}: {slug}")

        print(f"\n  Token IDs found: {len(polymarket_tokens)}")
        for market_type, token_id in polymarket_tokens.items():
            if token_id:
                print(f"    {market_type}: {token_id[:30]}...")

    if not kalshi_markets and not polymarket_tokens:
        print("\n⚠️  No markets found on either exchange.")
        print("Tips:")
        print("- Make sure the date matches the actual game date")
        print("- Try using full team names instead of abbreviations")
        print("- Check if the game is actually scheduled")
        return

    print("\n" + "="*80)
    print("INITIALIZING PRICE MONITORING")
    print("="*80)

    print("Fetching initial prices...")
    await fetch_initial_prices(kalshi_markets, polymarket_tokens, has_tie)

    print("Starting real-time monitoring...")
    print("Press Ctrl+C to stop\n")

    tasks = []

    if kalshi_markets:
        kalshi_task = asyncio.create_task(kalshi_websocket(kalshi_markets, has_tie, polymarket_tokens))
        tasks.append(kalshi_task)

    if polymarket_tokens:
        poly_task = asyncio.create_task(periodic_polymarket_update(polymarket_tokens, has_tie))
        tasks.append(poly_task)

    try:
        while True:
            display_best_prices(team1, team2, has_tie)

            yes_arb, no_arb = detect_arbitrage(has_tie, min_shares=100)
            cross_arb = detect_cross_market_arbitrage(has_tie, min_shares=100)
            display_arbitrage(yes_arb, no_arb, cross_arb, team1, team2, has_tie)
            # display_arbitrage(yes_arb, no_arb, team1, team2, has_tie)

            await asyncio.sleep(0.5)
    except KeyboardInterrupt:
        print("\n\nStopping monitor...")
        for task in tasks:
            task.cancel()
        kalshi_prices.close()
        poly_prices.close()
        print("Shutdown complete.")

if __name__ == "__main__":
    asyncio.run(main())