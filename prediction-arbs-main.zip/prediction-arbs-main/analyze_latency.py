"""
Latency Analysis and Visualization

Analyzes the output from odds_latency_tracker.py and generates insights,
statistics, and visualizations (if matplotlib is available).
"""

import json
import csv
import sys
from collections import defaultdict
from datetime import datetime
from typing import List, Dict, Tuple
import statistics


class LatencyAnalyzer:
    """Analyze latency tracking results"""
    
    def __init__(self, latency_csv: str, updates_jsonl: str = None, summary_json: str = None):
        self.latency_csv = latency_csv
        self.updates_jsonl = updates_jsonl
        self.summary_json = summary_json
        
        self.latency_records = []
        self.updates = []
        self.summary = {}
        
        self._load_data()
    
    def _load_data(self):
        """Load all data files"""
        # Load latency records
        try:
            with open(self.latency_csv, 'r') as f:
                reader = csv.DictReader(f)
                self.latency_records = list(reader)
            print(f"✓ Loaded {len(self.latency_records)} latency records")
        except FileNotFoundError:
            print(f"❌ Latency file not found: {self.latency_csv}")
            sys.exit(1)
        
        # Load updates if available
        if self.updates_jsonl:
            try:
                with open(self.updates_jsonl, 'r') as f:
                    self.updates = [json.loads(line) for line in f]
                print(f"✓ Loaded {len(self.updates)} updates")
            except FileNotFoundError:
                print(f"⚠️  Updates file not found: {self.updates_jsonl}")
        
        # Load summary if available
        if self.summary_json:
            try:
                with open(self.summary_json, 'r') as f:
                    self.summary = json.load(f)
                print(f"✓ Loaded summary")
            except FileNotFoundError:
                print(f"⚠️  Summary file not found: {self.summary_json}")
    
    def analyze_platform_speed(self) -> Dict:
        """Analyze which platform updates first most often"""
        first_updates = defaultdict(int)
        
        for record in self.latency_records:
            first_platform = record['first_platform']
            first_updates[first_platform] += 1
        
        total = sum(first_updates.values())
        
        result = {
            'counts': dict(first_updates),
            'percentages': {
                platform: (count / total * 100) if total > 0 else 0
                for platform, count in first_updates.items()
            },
            'winner': max(first_updates.items(), key=lambda x: x[1])[0] if first_updates else None
        }
        
        return result
    
    def analyze_latency_by_pair(self) -> Dict:
        """Analyze latency statistics for each platform pair"""
        latencies_by_pair = defaultdict(list)
        price_diffs_by_pair = defaultdict(list)
        
        for record in self.latency_records:
            pair = f"{record['first_platform']}_to_{record['second_platform']}"
            latency = float(record['latency_seconds'])
            price_diff = float(record['price_difference'])
            
            latencies_by_pair[pair].append(latency)
            price_diffs_by_pair[pair].append(price_diff)
        
        result = {}
        for pair, latencies in latencies_by_pair.items():
            result[pair] = {
                'count': len(latencies),
                'mean': statistics.mean(latencies),
                'median': statistics.median(latencies),
                'min': min(latencies),
                'max': max(latencies),
                'std_dev': statistics.stdev(latencies) if len(latencies) > 1 else 0,
                'mean_price_diff': statistics.mean(price_diffs_by_pair[pair]),
                'max_price_diff': max(price_diffs_by_pair[pair])
            }
        
        return result
    
    def find_largest_latencies(self, top_n: int = 10) -> List[Dict]:
        """Find the largest latencies"""
        sorted_records = sorted(
            self.latency_records,
            key=lambda r: float(r['latency_seconds']),
            reverse=True
        )
        
        return sorted_records[:top_n]
    
    def find_largest_price_differences(self, top_n: int = 10) -> List[Dict]:
        """Find the largest price differences during latency windows"""
        sorted_records = sorted(
            self.latency_records,
            key=lambda r: float(r['price_difference']),
            reverse=True
        )
        
        return sorted_records[:top_n]
    
    def analyze_arbitrage_opportunities(self, min_price_diff: float = 0.02) -> List[Dict]:
        """Find potential arbitrage opportunities (significant price differences)"""
        opportunities = []
        
        for record in self.latency_records:
            price_diff = float(record['price_difference'])
            latency = float(record['latency_seconds'])
            
            # Significant price difference = potential arbitrage
            if price_diff >= min_price_diff:
                opportunities.append({
                    'team': record['team'],
                    'first_platform': record['first_platform'],
                    'second_platform': record['second_platform'],
                    'latency_seconds': latency,
                    'price_difference': price_diff,
                    'first_price': float(record['first_price']),
                    'second_price': float(record['second_price']),
                    'timestamp': record['first_update_datetime']
                })
        
        # Sort by price difference
        opportunities.sort(key=lambda x: x['price_difference'], reverse=True)
        
        return opportunities
    
    def print_analysis(self):
        """Print comprehensive analysis"""
        print("\n" + "="*80)
        print("LATENCY ANALYSIS REPORT")
        print("="*80)
        
        # Platform speed
        print("\n📊 PLATFORM SPEED RANKING")
        print("-" * 80)
        speed = self.analyze_platform_speed()
        for platform, count in sorted(speed['counts'].items(), key=lambda x: x[1], reverse=True):
            percentage = speed['percentages'][platform]
            print(f"  {platform:15} - {count:4} times first ({percentage:5.1f}%)")
        
        if speed['winner']:
            print(f"\n🏆 Fastest platform: {speed['winner']}")
        
        # Latency by pair
        print("\n⏱️  LATENCY STATISTICS BY PLATFORM PAIR")
        print("-" * 80)
        pair_stats = self.analyze_latency_by_pair()
        
        for pair, stats in sorted(pair_stats.items(), key=lambda x: x[1]['mean']):
            print(f"\n{pair}:")
            print(f"  Count:          {stats['count']}")
            print(f"  Mean latency:   {stats['mean']:.3f}s")
            print(f"  Median latency: {stats['median']:.3f}s")
            print(f"  Min latency:    {stats['min']:.3f}s")
            print(f"  Max latency:    {stats['max']:.3f}s")
            print(f"  Std deviation:  {stats['std_dev']:.3f}s")
            print(f"  Avg price Δ:    {stats['mean_price_diff']:.4f}")
            print(f"  Max price Δ:    {stats['max_price_diff']:.4f}")
        
        # Largest latencies
        print("\n🐌 TOP 10 LARGEST LATENCIES")
        print("-" * 80)
        largest = self.find_largest_latencies(10)
        for i, record in enumerate(largest, 1):
            print(f"{i:2}. {record['first_platform']:10} → {record['second_platform']:10} | "
                  f"{float(record['latency_seconds']):6.2f}s | "
                  f"Team: {record['team']:20} | "
                  f"Price Δ: {float(record['price_difference']):.4f}")
        
        # Largest price differences
        print("\n💰 TOP 10 LARGEST PRICE DIFFERENCES")
        print("-" * 80)
        price_diffs = self.find_largest_price_differences(10)
        for i, record in enumerate(price_diffs, 1):
            print(f"{i:2}. {record['first_platform']:10} → {record['second_platform']:10} | "
                  f"Price Δ: {float(record['price_difference']):.4f} | "
                  f"Latency: {float(record['latency_seconds']):6.2f}s | "
                  f"Team: {record['team']}")
        
        # Arbitrage opportunities
        print("\n🎯 POTENTIAL ARBITRAGE OPPORTUNITIES (Price diff > 0.02)")
        print("-" * 80)
        arbs = self.analyze_arbitrage_opportunities(min_price_diff=0.02)
        
        if arbs:
            print(f"Found {len(arbs)} potential arbitrage opportunities:\n")
            for i, opp in enumerate(arbs[:20], 1):  # Show top 20
                print(f"{i:2}. {opp['team']:20} | "
                      f"{opp['first_platform']:10} @ {opp['first_price']:.4f} → "
                      f"{opp['second_platform']:10} @ {opp['second_price']:.4f} | "
                      f"Δ: {opp['price_difference']:.4f} | "
                      f"Window: {opp['latency_seconds']:.2f}s")
        else:
            print("No significant arbitrage opportunities detected.")
        
        print("\n" + "="*80)
        print("ANALYSIS COMPLETE")
        print("="*80 + "\n")
    
    def export_summary(self, output_file: str):
        """Export analysis summary to JSON"""
        analysis = {
            'timestamp': datetime.now().isoformat(),
            'platform_speed': self.analyze_platform_speed(),
            'latency_by_pair': self.analyze_latency_by_pair(),
            'largest_latencies': self.find_largest_latencies(10),
            'largest_price_differences': self.find_largest_price_differences(10),
            'arbitrage_opportunities': self.analyze_arbitrage_opportunities()
        }
        
        with open(output_file, 'w') as f:
            json.dump(analysis, f, indent=2)
        
        print(f"✓ Analysis exported to {output_file}")


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python analyze_latency.py <latency_csv_file> [updates_jsonl] [summary_json]")
        print("\nExample:")
        print("  python analyze_latency.py latency_records_dal_car_20251024_120000.csv")
        print("  python analyze_latency.py latency_records_*.csv odds_updates_*.jsonl latency_summary_*.json")
        sys.exit(1)
    
    latency_csv = sys.argv[1]
    updates_jsonl = sys.argv[2] if len(sys.argv) > 2 else None
    summary_json = sys.argv[3] if len(sys.argv) > 3 else None
    
    print("="*80)
    print("LATENCY ANALYSIS TOOL")
    print("="*80)
    print(f"\nLoading data from:")
    print(f"  Latency CSV: {latency_csv}")
    if updates_jsonl:
        print(f"  Updates JSONL: {updates_jsonl}")
    if summary_json:
        print(f"  Summary JSON: {summary_json}")
    print()
    
    # Create analyzer
    analyzer = LatencyAnalyzer(latency_csv, updates_jsonl, summary_json)
    
    # Print analysis
    analyzer.print_analysis()
    
    # Export detailed analysis
    export_file = latency_csv.replace('.csv', '_analysis.json')
    analyzer.export_summary(export_file)


if __name__ == "__main__":
    main()

