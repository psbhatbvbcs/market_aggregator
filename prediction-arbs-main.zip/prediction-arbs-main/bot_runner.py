#!/usr/bin/env python3
"""
Bot Runner - Programmatic wrapper for bot.py
Runs bot.py with specified parameters and sends webhook notifications
"""

import argparse
import asyncio
import sys
import requests
from datetime import datetime
from pathlib import Path

# Import from bot.py
from bot import (
    UniversalMarketFinder, KalshiAuth, KalshiWebSocketClient, KalshiMarket, KalshiTrader,
    PolymarketMarket, PolymarketTrader, ArbitrageExecutor,
    poll_prices, detect_cross_exchange_arbitrage, display_best_prices, display_cross_exchange_arbitrage,
    JSONLWriter, prices, price_lock, last_update,
    API_KEY_ID, PRIVATE_KEY_PEM, POLYMARKET_PRIVATE_KEY, POLYMARKET_FUNDER,
    ORDER_TYPE, MAX_ORDER_WAIT_TIME, FALLBACK_CANCEL_PENDING,
    logger
)


class BotRunner:
    def __init__(self, team1, team2, league, date, tracking_id, webhook_url):
        self.team1 = team1
        self.team2 = team2
        self.league = league
        self.date = date
        self.tracking_id = tracking_id
        self.webhook_url = webhook_url
        self.api_server_url = "http://localhost:8000"
        
    def send_webhook(self, event_type, data):
        """Send webhook notification to API server"""
        try:
            payload = {
                "event_type": event_type,
                "tracking_id": self.tracking_id,
                "timestamp": datetime.now().isoformat(),
                **data
            }
            requests.post(self.webhook_url, json=payload, timeout=5)
        except Exception as e:
            logger.error(f"Failed to send webhook: {e}")
    
    def broadcast_prices(self, prices_data):
        """Broadcast prices to WebSocket clients via API server"""
        try:
            url = f"{self.api_server_url}/arbitrage/broadcast-prices/{self.tracking_id}"
            requests.post(url, json=prices_data, timeout=2)
        except Exception as e:
            logger.error(f"Failed to broadcast prices: {e}")
    
    async def run(self):
        """Run the bot for the specified game"""
        try:
            logger.info(f"🤖 Bot Runner started for {self.team1} vs {self.team2}")
            logger.info(f"📍 Tracking ID: {self.tracking_id}")
            
            # Send initialization webhook
            self.send_webhook("bot_started", {
                "team1": self.team1,
                "team2": self.team2,
                "league": self.league,
                "date": self.date
            })
            
            # Find markets
            finder = UniversalMarketFinder()
            
            game_date = None
            if self.date:
                try:
                    game_date = datetime.strptime(self.date, "%Y-%m-%d")
                except:
                    pass
            
            league_lower = self.league.lower()
            if league_lower not in finder.league_mappings:
                logger.error(f"League '{self.league}' not supported")
                self.send_webhook("error", {"message": f"League '{self.league}' not supported"})
                return
            
            has_tie = finder.league_mappings[league_lower]['has_tie']
            
            # Search Kalshi
            logger.info("Searching Kalshi markets...")
            kalshi_markets = finder.find_kalshi_markets(self.team1, self.team2, self.league, game_date)
            
            # Search Polymarket
            logger.info("Searching Polymarket markets...")
            polymarket_markets = finder.find_polymarket_markets(self.team1, self.team2, self.league, game_date)
            
            if not kalshi_markets or not kalshi_markets.get('found'):
                logger.error("Could not find Kalshi markets")
                self.send_webhook("error", {"message": "Kalshi markets not found"})
                return
            
            if not polymarket_markets or not polymarket_markets.get('found'):
                logger.error("Could not find Polymarket markets")
                self.send_webhook("error", {"message": "Polymarket markets not found"})
                return
            
            # Send markets found webhook
            self.send_webhook("markets_found", {
                "kalshi": kalshi_markets,
                "polymarket": polymarket_markets,
                "has_tie": has_tie
            })
            
            # Initialize clients
            kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)
            kalshi_client = KalshiMarket(
                api_key=API_KEY_ID,
                slug=kalshi_markets['metadata']['event_ticker']
            )
            
            if not kalshi_auth.authenticate():
                logger.error("Failed to authenticate with Kalshi")
                self.send_webhook("error", {"message": "Kalshi authentication failed"})
                return
            
            kalshi_trader = KalshiTrader(kalshi_auth)
            polymarket_trader = PolymarketTrader(POLYMARKET_PRIVATE_KEY, POLYMARKET_FUNDER)
            
            # Initialize Polymarket client
            if has_tie:
                poly_slug = polymarket_markets["metadata"]["slugs"].get("home_win", "poly_market")
            else:
                poly_slug = polymarket_markets["metadata"]["slugs"].get("market", "poly_market")
            
            polymarket_client = PolymarketMarket(slug=poly_slug)
            
            # Initialize arbitrage executor
            arbitrage_executor = ArbitrageExecutor(
                kalshi_trader,
                polymarket_trader,
                f"arbs_{self.team1}_{self.team2}_{self.tracking_id}.jsonl"
            )
            
            logger.info("✓ All clients initialized")
            self.send_webhook("initialized", {"message": "Bot fully initialized, monitoring started"})
            
            # Start monitoring
            tasks = []
            
            pricesLog = JSONLWriter(f"prices_{self.team1}_{self.team2}_{self.tracking_id}.jsonl")
            arbLog = JSONLWriter(f"arb_{self.team1}_{self.team2}_{self.tracking_id}.jsonl")
            
            # Poll prices
            tasks.append(poll_prices(
                kalshi_client,
                kalshi_markets,
                has_tie,
                "kalshi",
                pricesLog
            ))
            
            tasks.append(poll_prices(
                polymarket_client,
                polymarket_markets,
                has_tie,
                "polymarket",
                pricesLog
            ))
            
            # Arbitrage detection loop with webhook notifications
            async def arb_loop():
                price_broadcast_counter = 0
                while True:
                    # Broadcast prices every 5 iterations (every ~1 second)
                    price_broadcast_counter += 1
                    if price_broadcast_counter >= 5:
                        with price_lock:
                            self.broadcast_prices({
                                "prices": prices,
                                "last_update": {
                                    k: v.isoformat() if v else None
                                    for k, v in last_update.items()
                                }
                            })
                        price_broadcast_counter = 0
                    
                    # Detect arbitrage
                    arb = detect_cross_exchange_arbitrage(has_tie, arbLog)
                    if arb:
                        logger.info("🎯 Arbitrage detected!")
                        
                        # Send webhook notification of detected arbitrage
                        self.send_webhook("arbitrage_detected", {
                            "arbitrage": arb
                        })
                        
                        # Execute arbitrage
                        execution_result = arbitrage_executor.execute_arbitrage(
                            arb, kalshi_markets, polymarket_markets, max_size=10
                        )
                        
                        if 'error' in execution_result:
                            logger.error(f"Failed to execute: {execution_result['error']}")
                            self.send_webhook("execution_failed", {
                                "error": execution_result['error'],
                                "arbitrage": arb
                            })
                            await asyncio.sleep(0.5)
                            continue
                        
                        # Send webhook with execution details
                        self.send_webhook("arbitrage_executed", {
                            "arbitrage": arb,
                            "execution": execution_result
                        })
                        
                        # Wait for order fills (same logic as original bot)
                        kalshi_order_ids = []
                        poly_order_result = None
                        
                        for order_info in execution_result.get('orders', []):
                            if order_info['exchange'] == 'kalshi':
                                order = order_info.get('order', {})
                                order_id = order.get('order_id')
                                if order_id:
                                    kalshi_order_ids.append(order_id)
                            elif order_info['exchange'] == 'polymarket':
                                poly_order_result = order_info['order']
                        
                        logger.info(f"⏳ Waiting up to {MAX_ORDER_WAIT_TIME}s for orders to fill...")
                        
                        kalshi_status = {}
                        poly_status = {}
                        
                        if kalshi_order_ids:
                            kalshi_status = await arbitrage_executor.wait_for_kalshi_orders(
                                kalshi_order_ids, MAX_ORDER_WAIT_TIME
                            )
                        
                        if poly_order_result:
                            poly_status = await arbitrage_executor.wait_for_polymarket_orders(
                                poly_order_result, MAX_ORDER_WAIT_TIME
                            )
                        
                        all_kalshi_filled = all(kalshi_status.values()) if kalshi_status else True
                        all_poly_filled = all(poly_status.values()) if poly_status else True
                        
                        if all_kalshi_filled and all_poly_filled:
                            logger.info("✅ All orders filled successfully!")
                            self.send_webhook("orders_filled", {
                                "arbitrage": arb,
                                "profit": arb['total_profit'],
                                "kalshi_status": kalshi_status,
                                "poly_status": poly_status
                            })
                        else:
                            logger.warning("⚠️ Some orders not filled within timeout")
                            self.send_webhook("orders_partial", {
                                "arbitrage": arb,
                                "kalshi_status": kalshi_status,
                                "poly_status": poly_status
                            })
                            
                            if FALLBACK_CANCEL_PENDING:
                                try:
                                    poly_order_ids = {}
                                    if poly_order_result:
                                        if ORDER_TYPE == "MARKET":
                                            yes_order = poly_order_result.get('yes_order', {})
                                            no_order = poly_order_result.get('no_order', {})
                                            if isinstance(yes_order, dict) and yes_order.get('orderID'):
                                                poly_order_ids['yes'] = yes_order['orderID']
                                            if isinstance(no_order, dict) and no_order.get('orderID'):
                                                poly_order_ids['no'] = no_order['orderID']
                                        else:
                                            orders = poly_order_result.get('orders', [])
                                            for i, order in enumerate(orders):
                                                if isinstance(order, dict) and order.get('orderID'):
                                                    poly_order_ids[f'order_{i}'] = order['orderID']
                                    
                                    await arbitrage_executor.cancel_unfilled_orders(
                                        kalshi_order_ids,
                                        kalshi_status,
                                        poly_order_ids,
                                        poly_status
                                    )
                                except Exception as e:
                                    logger.error(f"Error cancelling orders: {e}")
                    
                    await asyncio.sleep(0.2)
            
            tasks.append(arb_loop())
            
            # Run all tasks
            await asyncio.gather(*tasks)
            
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")
            self.send_webhook("bot_stopped", {"reason": "user_interrupt"})
        except Exception as e:
            logger.error(f"Bot error: {e}")
            self.send_webhook("error", {"message": str(e)})
        finally:
            try:
                if 'kalshi_client' in locals():
                    kalshi_client.close()
                if 'polymarket_client' in locals():
                    polymarket_client.close()
                if 'kalshi_trader' in locals():
                    kalshi_trader.close()
                if 'polymarket_trader' in locals():
                    polymarket_trader.close()
                if 'arbitrage_executor' in locals():
                    arbitrage_executor.close()
                if 'pricesLog' in locals():
                    pricesLog.close()
                if 'arbLog' in locals():
                    arbLog.close()
            except:
                pass


def main():
    parser = argparse.ArgumentParser(description='Run arbitrage bot programmatically')
    parser.add_argument('--team1', required=True, help='Home team name')
    parser.add_argument('--team2', required=True, help='Away team name')
    parser.add_argument('--league', required=True, help='League (NFL, EPL, etc.)')
    parser.add_argument('--date', help='Game date (YYYY-MM-DD)')
    parser.add_argument('--tracking-id', required=True, help='Tracking ID')
    parser.add_argument('--webhook', required=True, help='Webhook URL')
    
    args = parser.parse_args()
    
    runner = BotRunner(
        team1=args.team1,
        team2=args.team2,
        league=args.league,
        date=args.date,
        tracking_id=args.tracking_id,
        webhook_url=args.webhook
    )
    
    asyncio.run(runner.run())


if __name__ == "__main__":
    main()

