"""
Odds Snapshot Tracker: Leeds United vs West Ham (EPL)
Date: October 24, 2025

This script takes synchronized snapshots of odds every 5 seconds across:
- Polymarket (3 markets: Leeds win, Draw, West Ham win)
- Kalshi (3 markets: Leeds win, Tie, West Ham win)
- Rundown (traditional sportsbooks - can be added later)

Output: CSV file with synchronized timestamps, perfect for time-series plotting
"""

import asyncio
import sys
import os

# Add parent directory to path to import our tracker
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from odds_snapshot_tracker import OddsSnapshotTracker
from datetime import datetime


async def track_leeds_westham():
    """
    Track Leeds United vs West Ham EPL match with synchronized snapshots
    """
    print("="*80)
    print("ODDS SNAPSHOT TRACKING: LEEDS UNITED vs WEST HAM")
    print("Competition: English Premier League (EPL)")
    print("Date: October 24, 2025, 19:00 UTC")
    print("="*80)
    print()
    
    # ==================== MARKET CONFIGURATION ====================
    outcomes = {
        'Leeds United': {
            'polymarket': '30413884270873456148709223082839466102170770506960488658235965928290123136035',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-LEE'
        },
        'Draw': {
            'polymarket': '46989922153535687834881452526579430325384463679270525339176825823619522825824',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-TIE'
        },
        'West Ham': {
            'polymarket': '110458542910229477860301044301936279464048264454202209636357323944697297186083',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-WHU'
        }
    }
    
    print("📊 Market Configuration:")
    print()
    for outcome_name, markets in outcomes.items():
        print(f"{outcome_name}:")
        print(f"  Polymarket: {markets['polymarket'][:30]}...")
        print(f"  Kalshi:     {markets['kalshi']}")
    print()
    print(f"Rundown: 2025-10-24 (fetches by date)")
    print()
    print("="*80)
    print()
    
    # ==================== CONFIGURATION ====================
    snapshot_interval_input = input("Snapshot interval in seconds (default: 5): ").strip()
    snapshot_interval = int(snapshot_interval_input) if snapshot_interval_input else 5
    
    duration_input = input("Tracking duration in minutes (default: 30): ").strip()
    duration_minutes = int(duration_input) if duration_input else 30
    duration_seconds = duration_minutes * 60
    
    expected_snapshots = duration_seconds // snapshot_interval
    
    print()
    print(f"⚙️  Configuration:")
    print(f"   Snapshot interval: Every {snapshot_interval} seconds")
    print(f"   Duration: {duration_minutes} minutes")
    print(f"   Expected snapshots: ~{expected_snapshots}")
    print()
    
    confirm = input("Start tracking? (y/n): ").strip().lower()
    
    if confirm != 'y':
        print("Cancelled.")
        return
    
    print()
    print("🚀 Starting synchronized snapshot tracker...")
    print()
    print("What happens:")
    print(f"  ⏰ Every {snapshot_interval} seconds:")
    print("     1. Fetch ALL prices from Polymarket")
    print("     2. Fetch ALL prices from Kalshi")
    print("     3. (Fetch from Rundown if configured)")
    print("     4. Save snapshot with SAME timestamp")
    print()
    print("  📁 Output:")
    print("     - CSV with columns: timestamp, outcome, polymarket_price, kalshi_price, rundown_price")
    print("     - JSONL with same data in JSON format")
    print("     - Summary JSON with statistics")
    print()
    print("  📊 You can then:")
    print("     - Plot time-series graphs")
    print("     - See price divergence/convergence")
    print("     - Analyze which platform leads")
    print()
    print("-"*80)
    print()
    
    # Create tracker
    tracker = OddsSnapshotTracker(
        game_id='leeds_westham_epl',
        outcomes=outcomes,
        snapshot_interval=snapshot_interval,
        event_date="2025-10-24"  # Date of the Leeds vs West Ham game
    )
    
    # Run tracker
    try:
        await tracker.run(duration_seconds=duration_seconds)
    except KeyboardInterrupt:
        print("\n\n⚠️  Tracking interrupted by user")
    
    print()
    print("="*80)
    print("TRACKING COMPLETE")
    print("="*80)
    print()
    print("📁 Output files:")
    print(f"   CSV:  {tracker.csv_file}")
    print(f"   JSON: {tracker.json_file}")
    print()
    print("📊 To visualize results:")
    print(f"   python plot_odds.py {tracker.csv_file}")
    print()
    print("   Or plot specific outcome:")
    print(f"   python plot_odds.py {tracker.csv_file} --outcome 'Leeds United'")
    print()
    print("   Or save to file:")
    print(f"   python plot_odds.py {tracker.csv_file} --save plot.png")
    print()
    print("   Or get statistics:")
    print(f"   python plot_odds.py {tracker.csv_file} --stats")
    print()


async def quick_test():
    """
    Quick 2-minute test with snapshots every 5 seconds
    """
    print("="*80)
    print("QUICK TEST - 2 MINUTES")
    print("="*80)
    print()
    
    outcomes = {
        'Leeds United': {
            'polymarket': '30413884270873456148709223082839466102170770506960488658235965928290123136035',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-LEE'
        },
        'Draw': {
            'polymarket': '46989922153535687834881452526579430325384463679270525339176825823619522825824',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-TIE'
        },
        'West Ham': {
            'polymarket': '110458542910229477860301044301936279464048264454202209636357323944697297186083',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-WHU'
        }
    }
    
    tracker = OddsSnapshotTracker(
        game_id='test_leeds_westham',
        outcomes=outcomes,
        snapshot_interval=5,
        event_date="2025-10-24"  # Date of the Leeds vs West Ham game
    )
    
    print("🚀 Starting 2-minute test (snapshots every 5 seconds)...")
    print("   Expected snapshots: ~24")
    print()
    
    try:
        await tracker.run(duration_seconds=120)
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted")
    
    print("\n✅ Test complete!")
    print(f"\nOutput: {tracker.csv_file}")
    print(f"\nView with: python plot_odds.py {tracker.csv_file}")


async def view_current_snapshot():
    """
    Take a single snapshot to view current odds
    """
    import requests
    from odds_snapshot_tracker import KALSHI_BASE, POLYMARKET_CLOB
    
    print("="*80)
    print("CURRENT ODDS SNAPSHOT")
    print("="*80)
    print()
    
    outcomes = {
        'Leeds United': {
            'polymarket': '30413884270873456148709223082839466102170770506960488658235965928290123136035',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-LEE'
        },
        'Draw': {
            'polymarket': '46989922153535687834881452526579430325384463679270525339176825823619522825824',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-TIE'
        },
        'West Ham': {
            'polymarket': '110458542910229477860301044301936279464048264454202209636357323944697297186083',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-WHU'
        }
    }
    
    print(f"{'Outcome':<15} | {'Polymarket':<15} | {'Kalshi':<15} | {'Spread':<10}")
    print("-"*65)
    
    for outcome_name, markets in outcomes.items():
        # Fetch Polymarket
        poly_price = None
        try:
            url = f"{POLYMARKET_CLOB}/book?token_id={markets['polymarket']}"
            response = await asyncio.to_thread(requests.get, url, timeout=3)
            if response.status_code == 200:
                book = response.json()
                asks = book.get('asks', [])
                if asks:
                    poly_price = float(asks[-1]['price'])
        except Exception as e:
            pass
        
        # Fetch Kalshi
        kalshi_price = None
        try:
            url = f"{KALSHI_BASE}/markets/{markets['kalshi']}/orderbook"
            response = await asyncio.to_thread(requests.get, url, timeout=3)
            if response.status_code == 200:
                orderbook = response.json().get('orderbook', {})
                no_levels = orderbook.get('no', [])
                if no_levels:
                    kalshi_price = 1 - no_levels[-1][0] / 100.0
        except Exception as e:
            pass
        
        # Calculate spread
        spread = abs(poly_price - kalshi_price) if (poly_price and kalshi_price) else None
        
        # Format output
        poly_str = f"${poly_price:.4f}" if poly_price else "N/A"
        kalshi_str = f"${kalshi_price:.4f}" if kalshi_price else "N/A"
        spread_str = f"{spread*100:.2f}%" if spread else "N/A"
        
        print(f"{outcome_name:<15} | {poly_str:<15} | {kalshi_str:<15} | {spread_str:<10}")
    
    print()
    print("="*80)


def main():
    """Main menu"""
    print("="*80)
    print("LEEDS UNITED vs WEST HAM - ODDS SNAPSHOT TRACKER")
    print("EPL Match | October 24, 2025")
    print("="*80)
    print()
    print("📊 Synchronized Snapshots Every 5 Seconds")
    print("   Perfect for time-series visualization!")
    print()
    print("Select an option:")
    print("  1. Track with snapshots (full tracking)")
    print("  2. Quick 2-minute test")
    print("  3. View current odds snapshot")
    print("  4. Exit")
    print()
    
    choice = input("Enter choice (1-4): ").strip()
    
    if choice == "1":
        asyncio.run(track_leeds_westham())
    elif choice == "2":
        asyncio.run(quick_test())
    elif choice == "3":
        asyncio.run(view_current_snapshot())
    elif choice == "4":
        print("Goodbye!")
    else:
        print("Invalid choice. Please run again and select 1-4.")


if __name__ == "__main__":
    main()
