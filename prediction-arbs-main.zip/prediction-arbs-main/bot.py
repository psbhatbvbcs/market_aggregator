import requests
import asyncio
import websockets
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Union
import threading
from collections import defaultdict
import re
import ast
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
import logging
import uuid
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import OrderArgs, PostOrdersArgs, OrderType, MarketOrderArgs, BookParams

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
KALSHI_WSS = "wss://api.elections.kalshi.com/trade-api/ws/v2"
POLYMARKET_GAMMA = "https://gamma-api.polymarket.com"
POLYMARKET_CLOB = "https://clob.polymarket.com"
POLYMARKET_WSS = "wss://ws-subscriptions-clob.polymarket.com/ws/"

ORDER_TYPE = "LIMIT"
POLYMARKET_PRIVATE_KEY = "0xb0240ca09fd5169f06f95655788ef9f8e9f6b73dc4242721903b540c81635d7a"
POLYMARKET_FUNDER = "0xa408e0f79131086fdc724f1fa7784259ceb9e305"
CHAIN_ID = 137
API_KEY_ID = "39bb4b72-782d-432e-84e6-f228d2e4703d"
PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692B
gGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2lj
z4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1E
X8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u8
8DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eru
M1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUk
xxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5
F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPp
oLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb
778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3d
OygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobf
KQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1
uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJ
WvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jza
lm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5
qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI
1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6
c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4
eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCw
GsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8
R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa
98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoe
dYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxO
Fmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX
3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo
-----END RSA PRIVATE KEY-----"""

prices = {
    'kalshi': {
        'home_yes': {'price': 0, 'size': 0},
        'home_no': {'price': 0, 'size': 0},
        'away_yes': {'price': 0, 'size': 0},
        'away_no': {'price': 0, 'size': 0},
        'tie_yes': {'price': 0, 'size': 0},
        'tie_no': {'price': 0, 'size': 0}
    },
    'polymarket': {
        'home_yes': {'price': 0, 'size': 0},
        'home_no': {'price': 0, 'size': 0},
        'away_yes': {'price': 0, 'size': 0},
        'away_no': {'price': 0, 'size': 0},
        'tie_yes': {'price': 0, 'size': 0},
        'tie_no': {'price': 0, 'size': 0}
    }
}
price_lock = threading.Lock()
last_update = {'kalshi': datetime.now(), 'polymarket': datetime.now()}
polymarket_positions = defaultdict(lambda: {'yes': 0, 'no': 0})
polymarket_orderbook = defaultdict(lambda: {'yes': [], 'no': []})
position_lock = threading.Lock()
orderbook_lock = threading.Lock()


MAX_ORDER_WAIT_TIME = 2.0
FALLBACK_CANCEL_PENDING = True


class JSONLWriter:
    def __init__(self, filename: str):
        self.file = open(filename, 'a')

    def write(self, obj: dict) -> None:
        """Write a JSON object as a new line."""
        self.file.write(json.dumps(obj) + '\n')
        self.file.flush()  # Ensure data is written to disk

    def close(self):
        """Close the file."""
        self.file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class UniversalMarketFinder:
    def __init__(self):
        self.league_mappings = {
            "nfl": {
                "kalshi_prefix": "kxnflgame",
                "kalshi_series": "KXNFLGAME",
                "polymarket_prefix": "nfl",
                "has_tie": False
            },
            "cfb": {
                "kalshi_prefix": "kxncaafgame",
                "kalshi_series": "KXNCAAFGAME",
                "polymarket_prefix": "cfb",
                "has_tie": False
            },
            "mlb": {
                "kalshi_prefix": "kxmlbgame",
                "kalshi_series": "KXMLBGAME",
                "polymarket_prefix": "mlb",
                "has_tie": False
            },
            "nhl": {
                "kalshi_prefix": "kxnhlgame",
                "kalshi_series": "KXNHLGAME",
                "polymarket_prefix": "nhl",
                "has_tie": False
            },
            "nba": {
                "kalshi_prefix": "kxnbagame",
                "kalshi_series": "KXNBAGAME",
                "polymarket_prefix": "nba",
                "has_tie": False
            },
            "epl": {
                "kalshi_prefix": "kxeplgame",
                "kalshi_series": "KXEPLGAME",
                "polymarket_prefix": "epl",
                "has_tie": True
            },
            "serie a": {
                "kalshi_prefix": "kxserieagame",
                "kalshi_series": "KXSERIEAGAME",
                "polymarket_prefix": "sea",
                "has_tie": True
            },
            "bundesliga": {
                "kalshi_prefix": "kxbundesligagame",
                "kalshi_series": "KXBUNDESLIGAGAME",
                "polymarket_prefix": "bun",
                "has_tie": True
            },
            "la liga": {
                "kalshi_prefix": "kxlaligagame",
                "kalshi_series": "KXLALIGAGAME",
                "polymarket_prefix": "lal",
                "has_tie": True
            },
            "ligue 1": {
                "kalshi_prefix": "kxligue1game",
                "kalshi_series": "KXLIGUE1GAME",
                "polymarket_prefix": "fl1",
                "has_tie": True
            },
            "champions league": {
                "kalshi_prefix": "kxuclgame",
                "kalshi_series": "KXUCLGAME",
                "polymarket_prefix": "ucl",
                "has_tie": True
            }
        }

        self.team_abbreviations = {
            "arizona cardinals": ["ari", "arizona", "cardinals", "cards"],
            "atlanta falcons": ["atl", "atlanta", "falcons"],
            "baltimore ravens": ["bal", "baltimore", "ravens"],
            "buffalo bills": ["buf", "buffalo", "bills"],
            "carolina panthers": ["car", "carolina", "panthers"],
            "chicago bears": ["chi", "chicago", "bears"],
            "cincinnati bengals": ["cin", "cincinnati", "bengals", "cincy"],
            "cleveland browns": ["cle", "cleveland", "browns"],
            "dallas cowboys": ["dal", "dallas", "cowboys"],
            "denver broncos": ["den", "denver", "broncos"],
            "detroit lions": ["det", "detroit", "lions"],
            "green bay packers": ["gb", "green bay", "packers", "greenbay"],
            "houston texans": ["hou", "houston", "texans"],
            "indianapolis colts": ["ind", "indianapolis", "colts", "indy"],
            "jacksonville jaguars": ["jax", "jacksonville", "jaguars", "jac"],
            "kansas city chiefs": ["kc", "kansas city", "chiefs", "kan"],
            "las vegas raiders": ["lv", "las vegas", "raiders", "vegas", "oak"],
            "los angeles chargers": ["lac", "la chargers", "chargers"],
            "los angeles rams": ["lar", "la rams", "rams"],
            "miami dolphins": ["mia", "miami", "dolphins"],
            "minnesota vikings": ["min", "minnesota", "vikings"],
            "new england patriots": ["ne", "new england", "patriots", "nep"],
            "new orleans saints": ["no", "new orleans", "saints"],
            "new york giants": ["nyg", "ny giants", "giants"],
            "new york jets": ["nyj", "ny jets", "jets"],
            "philadelphia eagles": ["phi", "philadelphia", "eagles", "philly"],
            "pittsburgh steelers": ["pit", "pittsburgh", "steelers"],
            "san francisco 49ers": ["sf", "san francisco", "49ers", "niners"],
            "seattle seahawks": ["sea", "seattle", "seahawks"],
            "tampa bay buccaneers": ["tb", "tampa bay", "buccaneers", "bucs", "tampa"],
            "tennessee titans": ["ten", "tennessee", "titans"],
            "washington commanders": ["was", "washington", "commanders", "wsh"],
            "arizona diamondbacks": ["ari", "arizona", "diamondbacks", "dbacks"],
            "atlanta braves": ["atl", "atlanta", "braves"],
            "baltimore orioles": ["bal", "baltimore", "orioles"],
            "boston red sox": ["bos", "boston", "red sox", "redsox"],
            "chicago cubs": ["chc", "cubs", "chicago cubs"],
            "chicago white sox": ["cws", "white sox", "chicago white sox", "chisox"],
            "cincinnati reds": ["cin", "cincinnati", "reds", "cincy"],
            "cleveland guardians": ["cle", "cleveland", "guardians"],
            "colorado rockies": ["col", "colorado", "rockies"],
            "detroit tigers": ["det", "detroit", "tigers"],
            "houston astros": ["hou", "houston", "astros"],
            "kansas city royals": ["kc", "kansas city", "royals", "kan"],
            "los angeles angels": ["laa", "la angels", "angels", "anaheim"],
            "los angeles dodgers": ["lad", "la dodgers", "dodgers"],
            "miami marlins": ["mia", "miami", "marlins"],
            "milwaukee brewers": ["mil", "milwaukee", "brewers"],
            "minnesota twins": ["min", "minnesota", "twins"],
            "new york mets": ["nym", "ny mets", "mets"],
            "new york yankees": ["nyy", "ny yankees", "yankees", "yanks"],
            "oakland athletics": ["oak", "oakland", "athletics", "as"],
            "philadelphia phillies": ["phi", "philadelphia", "phillies", "philly"],
            "pittsburgh pirates": ["pit", "pittsburgh", "pirates"],
            "san diego padres": ["sd", "san diego", "padres"],
            "san francisco giants": ["sf", "san francisco", "giants"],
            "seattle mariners": ["sea", "seattle", "mariners"],
            "st louis cardinals": ["stl", "st louis", "cardinals", "cards"],
            "tampa bay rays": ["tb", "tampa bay", "rays", "tampa"],
            "texas rangers": ["tex", "texas", "rangers"],
            "toronto blue jays": ["tor", "toronto", "blue jays", "jays"],
            "washington nationals": ["was", "washington", "nationals", "nats", "wsh"],
            "anaheim ducks": ["ana", "anaheim", "ducks"],
            "arizona coyotes": ["ari", "arizona", "coyotes", "phx"],
            "boston bruins": ["bos", "boston", "bruins"],
            "buffalo sabres": ["buf", "buffalo", "sabres"],
            "calgary flames": ["cgy", "calgary", "flames", "cal"],
            "carolina hurricanes": ["car", "carolina", "hurricanes", "canes"],
            "chicago blackhawks": ["chi", "chicago", "blackhawks", "hawks"],
            "colorado avalanche": ["col", "colorado", "avalanche", "avs"],
            "columbus blue jackets": ["cbj", "columbus", "blue jackets", "jackets"],
            "dallas stars": ["dal", "dallas", "stars"],
            "detroit red wings": ["det", "detroit", "red wings", "wings"],
            "edmonton oilers": ["edm", "edmonton", "oilers"],
            "florida panthers": ["fla", "florida", "panthers", "cats"],
            "los angeles kings": ["la", "los angeles", "kings", "lak"],
            "minnesota wild": ["min", "minnesota", "wild"],
            "montreal canadiens": ["mtl", "montreal", "canadiens", "habs"],
            "nashville predators": ["nsh", "nashville", "predators", "preds"],
            "new jersey devils": ["nj", "new jersey", "devils", "njd"],
            "new york islanders": ["nyi", "ny islanders", "islanders", "isles"],
            "new york rangers": ["nyr", "ny rangers", "rangers"],
            "ottawa senators": ["ott", "ottawa", "senators", "sens"],
            "philadelphia flyers": ["phi", "philadelphia", "flyers"],
            "pittsburgh penguins": ["pit", "pittsburgh", "penguins", "pens"],
            "st louis blues": ["stl", "st louis", "blues"],
            "san jose sharks": ["sj", "san jose", "sharks", "sjs"],
            "seattle kraken": ["sea", "seattle", "kraken"],
            "tampa bay lightning": ["tb", "tampa bay", "lightning", "tbl", "bolts"],
            "toronto maple leafs": ["tor", "toronto", "maple leafs", "leafs"],
            "utah hockey club": ["uta", "utah", "hockey club", "uhc"],
            "vancouver canucks": ["van", "vancouver", "canucks", "nucks"],
            "vegas golden knights": ["vgk", "vegas", "golden knights", "knights"],
            "washington capitals": ["was", "washington", "capitals", "caps", "wsh"],
            "winnipeg jets": ["wpg", "winnipeg", "jets", "win"],
            "atlanta hawks": ["atl", "atlanta", "hawks"],
            "boston celtics": ["bos", "boston", "celtics", "celts"],
            "brooklyn nets": ["bkn", "brooklyn", "nets", "brk"],
            "charlotte hornets": ["cha", "charlotte", "hornets", "clt"],
            "chicago bulls": ["chi", "chicago", "bulls"],
            "cleveland cavaliers": ["cle", "cleveland", "cavaliers", "cavs"],
            "dallas mavericks": ["dal", "dallas", "mavericks", "mavs"],
            "denver nuggets": ["den", "denver", "nuggets", "nugs"],
            "detroit pistons": ["det", "detroit", "pistons"],
            "golden state warriors": ["gsw", "golden state", "warriors", "gs", "dubs"],
            "houston rockets": ["hou", "houston", "rockets"],
            "indiana pacers": ["ind", "indiana", "pacers"],
            "los angeles clippers": ["lac", "la clippers", "clippers", "clips"],
            "los angeles lakers": ["lal", "la lakers", "lakers"],
            "memphis grizzlies": ["mem", "memphis", "grizzlies", "grizz"],
            "miami heat": ["mia", "miami", "heat"],
            "milwaukee bucks": ["mil", "milwaukee", "bucks"],
            "minnesota timberwolves": ["min", "minnesota", "timberwolves", "wolves", "twolves"],
            "new orleans pelicans": ["no", "new orleans", "pelicans", "nop", "pels"],
            "new york knicks": ["ny", "new york", "knicks", "nyk"],
            "oklahoma city thunder": ["okc", "oklahoma city", "thunder"],
            "orlando magic": ["orl", "orlando", "magic"],
            "philadelphia 76ers": ["phi", "philadelphia", "76ers", "sixers"],
            "phoenix suns": ["phx", "phoenix", "suns", "pho"],
            "portland trail blazers": ["por", "portland", "trail blazers", "blazers"],
            "sacramento kings": ["sac", "sacramento", "kings"],
            "san antonio spurs": ["sa", "san antonio", "spurs", "sas"],
            "toronto raptors": ["tor", "toronto", "raptors", "raps"],
            "utah jazz": ["uta", "utah", "jazz"],
            "washington wizards": ["was", "washington", "wizards", "wsh"],
            "alabama": ["ala", "alabama", "crimson tide", "bama"],
            "georgia": ["uga", "georgia", "bulldogs", "dawgs"],
            "michigan": ["mich", "michigan", "wolverines"],
            "ohio state": ["osu", "ohio state", "buckeyes", "ohiost"],
            "texas": ["tex", "texas", "longhorns"],
            "oklahoma": ["ou", "oklahoma", "sooners"],
            "lsu": ["lsu", "louisiana state", "tigers"],
            "florida": ["fla", "florida", "gators"],
            "auburn": ["aub", "auburn", "tigers", "war eagle"],
            "tennessee": ["ten", "tennessee", "volunteers", "vols"],
            "missouri": ["miz", "missouri", "tigers", "mizzou", "mizz", "missr"],
            "texas a&m": ["tamu", "texas a&m", "aggies", "texam"],
            "clemson": ["clem", "clemson", "tigers"],
            "florida state": ["fsu", "florida state", "seminoles", "flast"],
            "miami": ["mia", "miami", "hurricanes", "canes"],
            "notre dame": ["nd", "notre dame", "fighting irish"],
            "usc": ["usc", "southern california", "trojans"],
            "ucla": ["ucla", "ucla", "bruins"],
            "oregon": ["ore", "oregon", "ducks"],
            "washington": ["wash", "washington", "huskies", "uw"],
            "penn state": ["psu", "penn state", "nittany lions", "pennst"],
            "wisconsin": ["wis", "wisconsin", "badgers", "wisc"],
            "iowa": ["iowa", "iowa", "hawkeyes"],
            "michigan state": ["msu", "michigan state", "spartans", "michst"],
            "nebraska": ["neb", "nebraska", "cornhuskers"],
            "arkansas": ["ark", "arkansas", "razorbacks"],
            "south carolina": ["sc", "south carolina", "gamecocks", "scar"],
            "mississippi": ["miss", "ole miss", "rebels"],
            "mississippi state": ["msst", "mississippi state", "bulldogs", "misst"],
            "kentucky": ["uk", "kentucky", "wildcats", "kent"],
            "vanderbilt": ["vand","van", "vanderbilt", "commodores", "vandy"],
            "virginia tech": ["vt", "virginia tech", "hokies"],
            "north carolina": ["unc", "north carolina", "tar heels"],
            "duke": ["duke", "duke", "blue devils"],
            "georgia tech": ["gt", "georgia tech", "yellow jackets", "gtech"],
            "arsenal": ["ars", "arsenal", "gunners", "afc"],
            "aston villa": ["avl", "aston villa", "villa"],
            "brentford": ["bre", "brentford", "bees"],
            "brighton": ["bri", "brighton", "seagulls", "bha"],
            "burnley": ["bur", "burnley", "clarets"],
            "chelsea": ["che", "chelsea", "blues", "cfc"],
            "crystal palace": ["cry", "crystal palace", "palace", "cpl"],
            "everton": ["eve", "everton", "toffees"],
            "fulham": ["ful", "fulham", "cottagers"],
            "leeds united": ["lee", "leeds", "united", "lufc", "leedsutd", "leed"],
            "leicester city": ["lei", "leicester", "foxes"],
            "liverpool": ["liv", "liverpool", "reds", "lfc", "pool"],
            "manchester city": ["mci", "man city", "city", "mcfc", "mancity"],
            "manchester united": ["mun", "man united", "united", "mufc", "manutd"],
            "newcastle united": ["new", "newcastle", "magpies", "nufc"],
            "nottingham forest": ["not", "nottingham", "forest", "nfo"],
            "sheffield united": ["shu", "sheffield united", "blades"],
            "tottenham": ["tot", "tottenham", "spurs", "thfc"],
            "west ham": ["whu", "west ham", "hammers"],
            "wolverhampton": ["wol", "wolves", "wolverhampton"],
            "bournemouth": ["bou", "bournemouth", "cherries"],
            "luton town": ["lut", "luton", "hatters"],
            "osasuna": ["osa", "osasu", "pamplona", "osasuna"],
            "getafe": ["get", "geta", "gtfe", "azulones", "getafe"],
            "barcelona": ["bar", "barca", "fcb", "barcelona"],
            "real madrid": ["rma", "real", "madrid", "rmadrid"],
            "atletico madrid": ["atm", "atletico", "atleti", "atl"],
            "athletic bilbao": ["ath", "athletic", "bilbao"],
            "cadiz": ["cad", "cadiz"],
            "celta vigo": ["cel", "celta", "vigo"],
            "deportivo alaves": ["ala", "alaves"],
            "espanyol": ["esp", "espanyol"],
            "girona": ["gir", "girona"],
            "granada": ["gra", "granada"],
            "las palmas": ["lpa", "las palmas", "palmas"],
            "mallorca": ["mal", "mallorca"],
            "rayo vallecano": ["ray", "rayo", "vallecano"],
            "real betis": ["bet", "betis", "real betis"],
            "real sociedad": ["rso", "real sociedad", "sociedad"],
            "sevilla": ["sev", "sevilla"],
            "valencia": ["val", "valencia", "che"],
            "villarreal": ["vil", "villarreal", "yellow submarine"],
            "augsburg": ["aug", "augsburg", "fca"],
            "bayer leverkusen": ["b04", "leverkusen", "bayer"],
            "bayern munich": ["bay", "fcb", "munich", "fcbayern", "bayern", "bmu"],
            "club brugge kv": ["bru"],
            "bochum": ["boc", "bochum", "vfl"],
            "borussia dortmund": ["bvb", "dor", "bor", "borussia", "dortmund"],
            "borussia monchengladbach": ["bmg", "gladbach", "monchengladbach"],
            "darmstadt": ["dar", "darmstadt", "d98"],
            "eintracht frankfurt": ["fra", "frankfurt", "eintracht", "sge"],
            "freiburg": ["fre", "freiburg", "scf"],
            "heidenheim": ["hei", "heidenheim", "fch"],
            "hoffenheim": ["hof", "tsg", "1899", "hoffenheim"],
            "koln": ["koe", "col", "fckoln", "cologne", "koln"],
            "leipzig": ["rbl", "leipzig", "rbleipzig"],
            "mainz": ["mai", "mainz", "m05"],
            "stuttgart": ["stu", "stuttgart", "vfb"],
            "union berlin": ["uni", "union", "berlin"],
            "werder bremen": ["wer", "werder", "bremen"],
            "wolfsburg": ["wol", "wolfsburg", "vfl"],
            "ac milan": ["mil", "milan", "ac milan", "acmilan", "rossoneri"],
            "atalanta": ["ata", "atalanta"],
            "bologna": ["bol", "bologna"],
            "cagliari": ["cag", "cagliari"],
            "empoli": ["emp", "empoli"],
            "fiorentina": ["fio", "fiorentina", "viola"],
            "frosinone": ["fro", "frosinone"],
            "genoa": ["gen", "genoa"],
            "inter milan": ["int", "inter", "intermilan", "internazionale"],
            "juventus": ["juv", "juve", "juventus"],
            "lazio": ["laz", "lazio"],
            "lecce": ["lec", "lecce"],
            "monza": ["mon", "monza"],
            "napoli": ["nap", "napoli", "partenopei"],
            "roma": ["rom", "roma", "asroma"],
            "salernitana": ["sal", "salernitana"],
            "sassuolo": ["sas", "sass", "sassuolo"],
            "torino": ["tor", "torino", "toro"],
            "udinese": ["udi", "udinese"],
            "verona": ["ver", "vero", "hellas", "verona"],
            "ajaccio": ["aja", "ajaccio"],
            "auxerre": ["aux", "auxerre"],
            "brest": ["bre", "brest", "sb29"],
            "clermont": ["cle", "clermont"],
            "lens": ["len", "lens", "rcl"],
            "lille": ["lil", "lille", "losc"],
            "lorient": ["lor", "fcl", "lorient"],
            "lyon": ["lyo", "lyon", "ol"],
            "marseille": ["mar", "mars", "om", "marseille"],
            "metz": ["met", "metz", "fcm"],
            "monaco": ["mon", "monaco", "asm"],
            "montpellier": ["mtp", "montpellier", "mhsc"],
            "nantes": ["nan", "nantes", "fcn"],
            "nice": ["nic", "nice", "ogcn"],
            "paris saint-germain": ["par", "psg", "pfc", "parissg", "paris"],
            "reims": ["rei", "reims", "sdr"],
            "rennes": ["ren", "rennes", "srfc"],
            "strasbourg": ["str", "strasbourg", "rcsa"],
            "toulouse": ["tou", "toulouse", "tfc"]
        }

        self.abbreviation_lookup = {}
        for full_name, abbrevs in self.team_abbreviations.items():
            for abbrev in abbrevs:
                self.abbreviation_lookup[abbrev.lower()] = abbrevs

    def normalize_team_name(self, team_name: str) -> List[str]:
        team_name_lower = team_name.lower().strip()
        if team_name_lower in self.abbreviation_lookup:
            return self.abbreviation_lookup[team_name_lower]
        for full_name, abbrevs in self.team_abbreviations.items():
            if full_name in team_name_lower or team_name_lower in full_name:
                return abbrevs
            for abbrev in abbrevs:
                if abbrev == team_name_lower:
                    return abbrevs
        if len(team_name_lower) <= 4:
            return [team_name_lower, team_name_lower[:3]]
        parts = team_name_lower.split()
        if len(parts) > 1:
            return [parts[0][:3], parts[-1][:3], ''.join([p[0] for p in parts])]
        else:
            return [team_name_lower[:3], team_name_lower[:4]]

    def find_kalshi_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]

        try:
            cursor = None
            attempts = 0
            max_attempts = 5 if game_date is None else None

            team1_variants = self.normalize_team_name(team1)
            team2_variants = self.normalize_team_name(team2)
            print(team1_variants)
            print(team2_variants)

            while True:
                if max_attempts and attempts >= max_attempts:
                    break
                
                attempts += 1

                params = {
                    "series_ticker": league_info['kalshi_series'],
                    "status": "open",
                    # "with_nested_markets": True,
                    "limit": 3
                }
                if cursor:
                    params["cursor"] = cursor

                response = requests.get(
                    f"{KALSHI_BASE}/events",
                    params=params,
                    timeout=10
                )

                if response.status_code != 200:
                    break

                data = response.json()
                events = data.get("events", [])
                if not events:
                    break

                for event in events:
                    event_ticker = event.get("event_ticker", "")
                    event_ticker_lower = event_ticker.lower()
                    print(event_ticker_lower)
                    team1_found = any(
                        t in event_ticker_lower for t in team1_variants)
                    team2_found = any(
                        t in event_ticker_lower for t in team2_variants)

                    if team1_found and team2_found:
                        print(f"Found Kalshi event: {event_ticker}")

                        markets_response = requests.get(
                            f"{KALSHI_BASE}/markets",
                            params={"event_ticker": event_ticker, "limit": 100},
                            timeout=10
                        )

                        if markets_response.status_code == 200:
                            markets = markets_response.json().get("markets", [])

                            result = {
                                'event_ticker': event_ticker,
                                'home_win': None,
                                'away_win': None,
                                'tie': None
                            }

                            print(
                                f"Found {len(markets)} markets for event {event_ticker}:")
                            for market in markets:
                                print(
                                    f"  - {market.get('ticker')}: {market.get('title')}")

                            for market in markets:
                                ticker = market.get("ticker", "")
                                ticker_upper = ticker.upper()

                                if league_info['has_tie']:
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        if suffix == "tie" or suffix == "draw":
                                            result['tie'] = ticker
                                            print(
                                                f"  Matched tie/draw: {ticker}")
                                        elif any(t.upper() in suffix.upper() for t in team1_variants):
                                            result['home_win'] = ticker
                                            print(
                                                f"  Matched home ({team1}) win: {ticker}")
                                        elif any(t.upper() in suffix.upper() for t in team2_variants):
                                            result['away_win'] = ticker
                                            print(
                                                f"  Matched away ({team2}) win: {ticker}")
                                else:
                                    parts = ticker_upper.split('-')
                                    if len(parts) >= 2:
                                        suffix = parts[-1].lower()

                                        if any(t.lower() in suffix for t in team1_variants):
                                            result['home_win'] = ticker
                                            print(
                                                f"  Matched home ({team1}) win: {ticker}")
                                        elif any(t.lower() in suffix for t in team2_variants):
                                            result['away_win'] = ticker
                                            print(
                                                f"  Matched away ({team2}) win: {ticker}")

                            market_info = {
                                'exchange': 'kalshi',
                                'found': bool(result and result.get('event_ticker')),
                                'markets': {
                                    'home_win': {'ticker': result.get('home_win'), 'id': result.get('home_win')},
                                    'away_win': {'ticker': result.get('away_win'), 'id': result.get('away_win')},
                                    'tie': {'ticker': result.get('tie'), 'id': result.get('tie')} if result.get('tie') else None
                                },
                                'metadata': {
                                    'event_ticker': result.get('event_ticker')
                                }
                            }
                            return market_info

                # Get next page cursor
                cursor = data.get("cursor", "")
                if not cursor:  # No more pages
                    break

        except Exception as e:
            print(f"Error fetching Kalshi markets: {e}")

        return None

    def find_polymarket_markets(self, team1: str, team2: str, league: str, game_date: Optional[datetime] = None) -> Dict:
        league_lower = league.lower()
        if league_lower not in self.league_mappings:
            return None

        league_info = self.league_mappings[league_lower]
        team1_abbrev = self.normalize_team_name(team1)[0].lower()
        team2_abbrev = self.normalize_team_name(team2)[0].lower()

        result = {
            'tokens': {},
            'slugs': {}
        }

        if league_info['has_tie'] and game_date:
            date_str = game_date.strftime("%Y-%m-%d")
            base_slug = f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}"

            market_slugs = {
                'home_win': f"{base_slug}-{team1_abbrev}",
                'tie': f"{base_slug}-draw",
                'away_win': f"{base_slug}-{team2_abbrev}"
            }

            for market_type, slug in market_slugs.items():
                try:
                    resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                    if resp.status_code == 200:
                        markets = resp.json()
                        if isinstance(markets, list) and len(markets) > 0:
                            market = markets[0]
                            raw_ids = market.get('clobTokenIds')
                            if raw_ids:
                                try:
                                    if isinstance(raw_ids, str):
                                        clob_token_ids = ast.literal_eval(raw_ids)
                                    else:
                                        clob_token_ids = raw_ids

                                    if isinstance(clob_token_ids, list) and len(clob_token_ids) >= 1:
                                        yes_token = str(clob_token_ids[0])
                                        result['tokens'][market_type] = yes_token
                                        result['slugs'][market_type] = slug
                                        print(f"Found Polymarket {market_type}: {slug}")
                                except Exception as e:
                                    print(f"Error parsing tokens for {slug}: {e}")
                except Exception as e:
                    print(f"Error fetching {slug}: {e}")

        else:
            try:
                if game_date:
                    date_str = game_date.strftime("%Y-%m-%d")
                    slug = f"{league_info['polymarket_prefix']}-{team1_abbrev}-{team2_abbrev}-{date_str}"
                    print("slug", slug)
                    resp = requests.get(f"{POLYMARKET_GAMMA}/markets?slug={slug}", timeout=10)
                    print(f"{POLYMARKET_GAMMA}/markets?slug={slug}")
                    if resp.status_code == 200:
                        markets = resp.json()
                        if isinstance(markets, list) and len(markets) > 0:
                            market = markets[0]
                            raw_ids = market.get('clobTokenIds')
                            if raw_ids:
                                try:
                                    if isinstance(raw_ids, str):
                                        try:
                                            clob_token_ids = json.loads(raw_ids)
                                        except json.JSONDecodeError:
                                            clob_token_ids = ast.literal_eval(raw_ids)
                                    else:
                                        clob_token_ids = raw_ids

                                    outcomes = market.get('outcomes', [])
                                    if isinstance(outcomes, str):
                                        try:
                                            outcomes = json.loads(outcomes)
                                        except json.JSONDecodeError:
                                            outcomes = ast.literal_eval(outcomes)

                                    team1_variants = self.normalize_team_name(team1)
                                    team2_variants = self.normalize_team_name(team2)

                                    for i, outcome in enumerate(outcomes):
                                        if i >= len(clob_token_ids):
                                            continue
                                        outcome_lower = (outcome or "").lower()

                                        if any(t in outcome_lower for t in team1_variants):
                                            result['tokens']['home_win'] = str(clob_token_ids[i])
                                        elif any(t in outcome_lower for t in team2_variants):
                                            result['tokens']['away_win'] = str(clob_token_ids[i])

                                    result['slugs']['market'] = slug
                                except Exception as e:
                                    print(f"Error parsing tokens: {e}")

            except Exception as e:
                print(f"Error searching Polymarket: {e}")

        if result and result.get('tokens'):
            market_info = {
                'exchange': 'polymarket',
                'found': bool(result.get('tokens')),
                'markets': {
                    'home_win': {
                        'ticker': result['tokens'].get('home_win'),
                        'id': result['tokens'].get('home_win'),
                        'slug': result.get('slugs', {}).get('home_win')
                    } if 'home_win' in result.get('tokens', {}) else None,
                    'away_win': {
                        'ticker': result['tokens'].get('away_win'),
                        'id': result['tokens'].get('away_win'),
                        'slug': result.get('slugs', {}).get('away_win')
                    } if 'away_win' in result.get('tokens', {}) else None,
                    'tie': {
                        'ticker': result['tokens'].get('tie'),
                        'id': result['tokens'].get('tie'),
                        'slug': result.get('slugs', {}).get('tie')
                    } if 'tie' in result.get('tokens', {}) else None
                },
                'metadata': {
                    'slugs': result.get('slugs', {})
                }
            }
            return market_info

        return {
            'exchange': 'polymarket',
            'found': False,
            'markets': {},
            'metadata': {}
        }


class KalshiAuth:
    def __init__(self, api_key_id: str, private_key_pem: str):
        self.api_key_id = api_key_id
        self.private_key = self._load_private_key(private_key_pem)
        self.token = None
        self.token_expires = None

    def _load_private_key(self, key_pem: str):
        return serialization.load_pem_private_key(
            key_pem.encode('utf-8'),
            password=None,
            backend=default_backend()
        )

    def create_signature(self, timestamp: str, method: str, path: str) -> str:
        message = f"{timestamp}{method}{path}".encode('utf-8')
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH
            ),
            hashes.SHA256()
        )
        return base64.b64encode(signature).decode('utf-8')

    def get_auth_headers(self, method: str, path: str) -> Dict[str, str]:
        timestamp = str(int(datetime.now().timestamp() * 1000))
        signature = self.create_signature(timestamp, method, path)

        return {
            'KALSHI-ACCESS-KEY': self.api_key_id,
            'KALSHI-ACCESS-SIGNATURE': signature,
            'KALSHI-ACCESS-TIMESTAMP': timestamp
        }

    def authenticate(self) -> bool:
        try:
            headers = self.get_auth_headers(
                "GET", "/trade-api/v2/portfolio/balance")
            response = requests.get(
                f"{KALSHI_BASE}/portfolio/balance",
                headers=headers,
                timeout=10
            )

            if response.status_code == 200:
                logger.info("Successfully authenticated with Kalshi")
                self.token_expires = datetime.now() + timedelta(minutes=29)
                return True
            else:
                logger.error(
                    f"Authentication failed: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return False

    def needs_refresh(self) -> bool:
        if not self.token_expires:
            return True
        return datetime.now() >= self.token_expires


class KalshiWebSocketClient:
    def __init__(self, auth: KalshiAuth, tickers: List[str], slug: str):
        self.auth = auth
        self.tickers = tickers
        self.ticker_map = {}
        self.websocket = None
        self.subscription_ids = {}
        self.orderbook_writer = JSONLWriter(f"kalshi_ws_ob_{slug}.jsonl")
        self.running = False
        self.message_id = 1

    def set_ticker_mapping(self, ticker: str, market_type: str):
        self.ticker_map[ticker] = market_type

    async def connect(self):
        try:
            headers = self.auth.get_auth_headers("GET", "/trade-api/ws/v2")

            logger.info(f"Connecting to {KALSHI_WSS}")

            self.websocket = await websockets.connect(
                KALSHI_WSS,
                additional_headers=headers
            )

            logger.info("Connected to Kalshi WebSocket")
            self.running = True

            await self.subscribe_to_orderbooks()
            await self.listen()

        except Exception as e:
            logger.error(f"WebSocket connection error: {e}")
            await self.reconnect()

    async def reconnect(self):
        logger.info("Attempting to reconnect...")
        await asyncio.sleep(5)

        if self.auth.needs_refresh():
            self.auth.authenticate()

        await self.connect()

    async def subscribe_to_orderbooks(self):
        for ticker in self.tickers:
            message = {
                "id": self.message_id,
                "cmd": "subscribe",
                "params": {
                    "channels": ["orderbook_delta"],
                    "market_ticker": ticker
                }
            }

            message_str = json.dumps(message)
            await self.websocket.send(message_str)
            logger.info(f"Sent subscription for {ticker}")
            self.message_id += 1
            await asyncio.sleep(0.1)

    async def listen(self):
        try:
            logger.info("Started listening for WebSocket messages")
            while self.running:
                try:
                    message = await asyncio.wait_for(self.websocket.recv(), timeout=5.0)
                    data = json.loads(message)

                    if data.get("type") == "subscribed":
                        self.handle_subscription_confirmation(data)
                    elif data.get("type") == "orderbook_delta":
                        self.handle_orderbook_update(data)
                    elif data.get("type") == "orderbook_snapshot":
                        self.handle_orderbook_snapshot(data)
                    elif data.get("type") == "error":
                        logger.error(f"WebSocket error: {data}")
                    elif data.get("type") == "ok":
                        logger.debug(f"Subscription confirmed: {data}")

                except asyncio.TimeoutError:
                    continue
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse message: {e}")

        except websockets.ConnectionClosed:
            logger.warning("WebSocket connection closed")
            await self.reconnect()
        except Exception as e:
            logger.error(f"Error in WebSocket listener: {e}")
            await self.reconnect()

    def handle_subscription_confirmation(self, data: Dict):
        sid = data.get("msg", {}).get("sid")
        channel = data.get("msg", {}).get("channel")
        logger.info(f"Subscription confirmed: Channel={channel}, SID={sid}")

    def handle_orderbook_snapshot(self, data: Dict):
        try:
            msg = data.get("msg", {})
            ticker = msg.get("market_ticker")

            if not ticker or ticker not in self.ticker_map:
                return

            market_type = self.ticker_map[ticker]

            yes_array = msg.get("yes", [])
            no_array = msg.get("no", [])

            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'ticker': ticker,
                'market_type': market_type,
                'type': 'snapshot',
                'data': msg
            })

            with price_lock:
                if no_array and len(no_array) > 0:
                    best_no_bid_cents = no_array[-1][0]
                    yes_price = (100 - best_no_bid_cents) / 100.0
                    yes_size = no_array[-1][1]
                else:
                    yes_price = 0
                    yes_size = 0

                if yes_array and len(yes_array) > 0:
                    best_yes_bid_cents = yes_array[-1][0]
                    no_price = (100 - best_yes_bid_cents) / 100.0
                    no_size = yes_array[-1][1]
                else:
                    no_price = 0
                    no_size = 0

                if market_type == 'home_win':
                    prices['kalshi']['home_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['home_no'] = {
                        'price': no_price, 'size': no_size}
                elif market_type == 'away_win':
                    prices['kalshi']['away_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['away_no'] = {
                        'price': no_price, 'size': no_size}
                elif market_type == 'tie':
                    prices['kalshi']['tie_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['tie_no'] = {
                        'price': no_price, 'size': no_size}

                last_update['kalshi'] = datetime.now()

        except Exception as e:
            logger.error(f"Error handling orderbook snapshot: {e}")

    def handle_orderbook_update(self, data: Dict):
        try:
            ticker = data.get("market_ticker")
            if not ticker or ticker not in self.ticker_map:
                return

            market_type = self.ticker_map[ticker]

            yes_levels = data.get("yes", [])
            no_levels = data.get("no", [])

            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'ticker': ticker,
                'market_type': market_type,
                'data': data
            })

            with price_lock:
                if no_levels and len(no_levels) > 0:
                    yes_price = 1 - no_levels[-1][0] / 100.0
                    yes_size = no_levels[-1][1]
                else:
                    yes_price = 0
                    yes_size = 0

                if yes_levels and len(yes_levels) > 0:
                    no_price = 1 - yes_levels[-1][0] / 100.0
                    no_size = yes_levels[-1][1]
                else:
                    no_price = 0
                    no_size = 0

                if market_type == 'home_win':
                    prices['kalshi']['home_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['home_no'] = {
                        'price': no_price, 'size': no_size}
                elif market_type == 'away_win':
                    prices['kalshi']['away_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['away_no'] = {
                        'price': no_price, 'size': no_size}
                elif market_type == 'tie':
                    prices['kalshi']['tie_yes'] = {
                        'price': yes_price, 'size': yes_size}
                    prices['kalshi']['tie_no'] = {
                        'price': no_price, 'size': no_size}

                last_update['kalshi'] = datetime.now()

        except Exception as e:
            logger.error(f"Error handling orderbook update: {e}")

    async def close(self):
        self.running = False
        if self.websocket:
            await self.websocket.close()
        self.orderbook_writer.close()
        logger.info("WebSocket connection closed")


class KalshiMarket:
    def __init__(self, api_key: str, slug: str):
        self.base_url = KALSHI_BASE
        self.api_key = api_key
        self.orderbook_writer = JSONLWriter(f"kalshi_ob_{slug}.jsonl")

    def get_market(self, ticker: str) -> Optional[Dict]:
        """Fetch market info for a single ticker"""
        try:
            market_url = f"{self.base_url}/markets/{ticker}"
            response = requests.get(market_url, timeout=5)

            if response.status_code == 200:
                market_data = response.json().get('market', {})
                return market_data
        except Exception as e:
            print(f"Error fetching Kalshi market {ticker}: {e}")
        return None

    def fetch_orderbook(self, tickers: List[str]) -> Dict:
        """
        Fetch orderbook for multiple tickers (e.g., SEA and DET for same game)
        Returns: {
            'ticker1': {
                'yes_price': float,  # Best price to BUY YES (ask)
                'yes_size': float,
                'no_price': float,   # Best price to BUY NO (ask)
                'no_size': float
            }
        }
        """
        combined_orderbooks = {}
        result = {}

        for ticker in tickers:
            try:
                orderbook_url = f"{self.base_url}/markets/{ticker}/orderbook"
                response = requests.get(orderbook_url, timeout=5)

                if response.status_code == 200:
                    orderbook_data = response.json().get('orderbook', {})
                    combined_orderbooks[ticker] = orderbook_data

                    yes_levels = orderbook_data.get('yes', [])
                    no_levels = orderbook_data.get('no', [])

                    yes_price = 0
                    yes_size = 0
                    if no_levels and len(no_levels) > 0:
                        yes_price = 1 - no_levels[-1][0] / 100.0
                        yes_size = no_levels[-1][1]

                    no_price = 0
                    no_size = 0
                    if yes_levels and len(yes_levels) > 0:
                        no_price = 1 - yes_levels[-1][0] / 100.0
                        no_size = yes_levels[-1][1]

                    result[ticker] = {
                        'yes_price': yes_price,
                        'yes_size': yes_size,
                        'no_price': no_price,
                        'no_size': no_size
                    }

            except Exception as e:
                print(f"Error fetching orderbook for {ticker}: {e}")
                result[ticker] = {
                    'yes_price': 0,
                    'yes_size': 0,
                    'no_price': 0,
                    'no_size': 0
                }

        if combined_orderbooks:
            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'orderbooks': combined_orderbooks
            })

        return result

    def close(self):
        self.orderbook_writer.close()


class KalshiTrader:
    def __init__(self, auth: KalshiAuth):
        self.auth = auth
        self.order_log = JSONLWriter("kalshi_orders.jsonl")

    def place_order(self, ticker: str, side: str, action: str, count: int,
                    price_cents: Optional[int] = None, max_cost_cents: Optional[int] = None) -> Dict:
        ORDER_TYPE = "LIMIT"

        order_data = {
            "ticker": ticker,
            "action": action,
            "side": side,
            "count": count,
            "client_order_id": str(uuid.uuid4())
        }

        if ORDER_TYPE == "MARKET":
            order_data["type"] = "market"
            if action == "buy":
                order_data["buy_max_cost"] = max_cost_cents or (count * 100)
            if side == "yes":
                order_data["yes_price"] = price_cents
            else:
                order_data["no_price"] = price_cents
        else:
            order_data["type"] = "limit"
            if side == "yes":
                order_data["yes_price"] = 99
            else:
                order_data["no_price"] = 99

        try:
            headers = self.auth.get_auth_headers(
                "POST", "/trade-api/v2/portfolio/orders")
            headers['Content-Type'] = 'application/json'

            response = requests.post(
                f"{KALSHI_BASE}/portfolio/orders",
                headers=headers,
                json=order_data,
                timeout=10
            )

            if response.status_code == 201:
                order = response.json().get('order', {})
                self.order_log.write({
                    'timestamp': datetime.now().isoformat(),
                    'exchange': 'kalshi',
                    'status': 'success',
                    'order': order,
                    'request': order_data
                })
                logger.info(f"Kalshi order placed: {order.get('order_id')}")
                return order
            else:
                error_data = {
                    'timestamp': datetime.now().isoformat(),
                    'exchange': 'kalshi',
                    'status': 'failed',
                    'error': response.text,
                    'request': order_data
                }
                self.order_log.write(error_data)
                logger.error(
                    f"Kalshi order failed: {response.status_code} - {response.text}")
                return {'error': response.text}

        except Exception as e:
            logger.error(f"Error placing Kalshi order: {e}")
            return {'error': str(e)}

    def cancel_order(self, order_id: str) -> bool:
        try:
            headers = self.auth.get_auth_headers(
                "DELETE", f"/trade-api/v2/portfolio/orders/{order_id}")
            response = requests.delete(
                f"{KALSHI_BASE}/portfolio/orders/{order_id}",
                headers=headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            logger.error(f"Error cancelling Kalshi order: {e}")
            return False

    def get_order_status(self, order_id: str) -> Dict:
        try:
            headers = self.auth.get_auth_headers(
                "GET", f"/trade-api/v2/portfolio/orders/{order_id}")
            response = requests.get(
                f"{KALSHI_BASE}/portfolio/orders/{order_id}",
                headers=headers,
                timeout=10
            )
            if response.status_code == 200:
                return response.json().get('order', {})
            return {}
        except Exception as e:
            logger.error(f"Error getting Kalshi order status: {e}")
            return {}

    def get_balance(self) -> float:
        try:
            headers = self.auth.get_auth_headers(
                "GET", "/trade-api/v2/portfolio/balance")
            response = requests.get(
                f"{KALSHI_BASE}/portfolio/balance",
                headers=headers,
                timeout=10
            )
            if response.status_code == 200:
                return response.json().get('balance', 0) / 100.0
            return 0.0
        except Exception as e:
            logger.error(f"Error getting Kalshi balance: {e}")
            return 0.0

    def close(self):
        self.order_log.close()


class PolymarketMarket:
    def __init__(self, slug: str):
        self.gamma_url = POLYMARKET_GAMMA
        self.clob_url = POLYMARKET_CLOB
        self.orderbook_writer = JSONLWriter(f"poly_ob_{slug}.jsonl")

    def get_market(self, slug: str) -> Optional[Dict]:
        try:
            resp = requests.get(
                f"{self.gamma_url}/markets?slug={slug}", timeout=10)
            if resp.status_code == 200:
                markets = resp.json()
                if isinstance(markets, list) and len(markets) > 0:
                    market_data = markets[0]
                    return market_data
        except Exception as e:
            print(f"Error fetching Polymarket market {slug}: {e}")
        return None

    def fetch_orderbook(self, token_ids: Dict[str, str]) -> Dict:
        combined_orderbooks = {}
        result = {}

        for market_type, token_id in token_ids.items():
            if not token_id:
                continue

            try:
                book_url = f"{self.clob_url}/book?token_id={token_id}"
                book_response = requests.get(book_url, timeout=5)

                if book_response.status_code == 200:
                    book_data = book_response.json()
                    combined_orderbooks[market_type] = book_data

                    bids = book_data.get('bids', [])
                    asks = book_data.get('asks', [])

                    yes_price = 0
                    yes_size = 0
                    if asks and len(asks) > 0:
                        yes_price = float(asks[-1]['price'])
                        yes_size = float(asks[-1]['size'])

                    no_price = 0
                    no_size = 0

                    result[market_type] = {
                        'yes_price': yes_price,
                        'yes_size': yes_size,
                        'no_price': no_price,
                        'no_size': no_size
                    }

            except Exception as e:
                print(f"Error fetching orderbook for {market_type}: {e}")
                result[market_type] = {
                    'yes_price': 0,
                    'yes_size': 0,
                    'no_price': 0,
                    'no_size': 0
                }

        if combined_orderbooks:
            self.orderbook_writer.write({
                'timestamp': datetime.now().isoformat(),
                'orderbooks': combined_orderbooks
            })

        return result

    def close(self):
        self.orderbook_writer.close()


class PolymarketTrader:
    def __init__(self, private_key: str = None, funder: str = None):
        self.private_key = private_key or POLYMARKET_PRIVATE_KEY
        self.funder = funder or POLYMARKET_FUNDER
        self.order_log = JSONLWriter("polymarket_orders.jsonl")

        self.client = ClobClient(
            POLYMARKET_CLOB,
            key=self.private_key,
            chain_id=CHAIN_ID,
            signature_type=1,
            funder=self.funder
        )

        self.client.set_api_creds(self.client.create_or_derive_api_creds())
        self.api_creds = self.client.derive_api_key()
        logger.info("Polymarket client initialized with API credentials")

    def place_orders(self, token: str, price: float,
                     size: int = 1) -> Dict:
        ORDER_TYPE = "LIMIT"

        try:
            if ORDER_TYPE == "MARKET":
                yes_order = MarketOrderArgs(
                    token_id=token,
                    amount=size * price,
                    side="BUY"
                )

                signed = self.client.create_market_order(yes_order)

                resp = self.client.post_order(signed, OrderType.FOK)

                result = {
                    'order': resp
                }
            else:
                resp = self.client.post_orders([
                    PostOrdersArgs(
                        self.client.create_order(
                            OrderArgs(
                                price=0.99,
                                size=size,
                                side="BUY",
                                token_id=token,
                            )
                        ),
                        orderType=OrderType.GTC,
                    ),
                ])
                result = {'orders': resp}

            self.order_log.write({
                'timestamp': datetime.now().isoformat(),
                'exchange': 'polymarket',
                'status': 'success',
                'result': result,
                'request': {
                    'token': token,
                    'price': price,
                    'size': size,
                    'type': ORDER_TYPE
                }
            })
            logger.info(f"Polymarket orders placed successfully")
            return result

        except Exception as e:
            error_result = {
                'timestamp': datetime.now().isoformat(),
                'exchange': 'polymarket',
                'status': 'failed',
                'error': str(e)
            }
            self.order_log.write(error_result)
            logger.error(f"Error placing Polymarket orders: {e}")
            return {'error': str(e)}

    def cancel_all_orders(self):
        try:
            self.client.cancel_all()
            logger.info("All Polymarket orders cancelled")
            return True
        except Exception as e:
            logger.error(f"Error cancelling all orders: {e}")
            return False

    def get_orderbook(self, token_id: str) -> Dict:
        try:
            book = self.client.get_order_book(token_id)
            return book
        except Exception as e:
            logger.error(f"Error getting orderbook: {e}")
            return {}

    def get_order(self, order_id: str) -> Dict:
        """Get order status from Polymarket"""
        try:
            order = self.client.get_order(order_id)
            return order
        except Exception as e:
            logger.error(f"Error getting Polymarket order {order_id}: {e}")
            return {}

    def get_positions(self) -> List:
        try:
            url = f"https://data-api.polymarket.com/positions"
            params = {"user": self.funder}
            response = requests.get(url, params=params, timeout=5)
            if response.status_code == 200:
                return response.json()
            return []
        except Exception as e:
            logger.error(f"Error getting positions: {e}")
            return []

    async def connect_user_websocket(self):
        auth_data = {
            "auth": {
                "apiKey": self.api_creds.api_key,
                "secret": self.api_creds.secret,
                "passphrase": self.api_creds.api_passphrase
            }
        }

        retry_count = 0
        while retry_count < 3:
            try:
                async with websockets.connect(POLYMARKET_WSS + "user") as websocket:
                    retry_count = 0
                    await websocket.send(json.dumps(auth_data))

                    while True:
                        try:
                            message = await asyncio.wait_for(websocket.recv(), timeout=30)
                            data = json.loads(message)

                            if 'type' in data and data['type'] == 'position':
                                with position_lock:
                                    for game, tokens in self.game_tokens.items():
                                        if data.get('asset') == tokens['yes_token']:
                                            polymarket_positions[game]['yes'] = data.get(
                                                'size', 0)
                                        elif data.get('asset') == tokens['no_token']:
                                            polymarket_positions[game]['no'] = data.get(
                                                'size', 0)
                        except asyncio.TimeoutError:
                            await websocket.send(json.dumps({"type": "ping"}))
                        except Exception:
                            break
            except Exception:
                retry_count += 1
                if retry_count < 3:
                    await asyncio.sleep(0.1)
                else:
                    await asyncio.sleep(1)
                    retry_count = 0

    async def connect_market_websocket(self, token_ids: List[str]):
        auth_data = {
            "auth": {
                "apiKey": self.api_creds.api_key,
                "secret": self.api_creds.secret,
                "passphrase": self.api_creds.api_passphrase
            },
            "markets": token_ids
        }

        retry_count = 0
        while retry_count < 3:
            try:
                async with websockets.connect(POLYMARKET_WSS + "market") as websocket:
                    retry_count = 0
                    await websocket.send(json.dumps(auth_data))

                    while True:
                        try:
                            message = await asyncio.wait_for(websocket.recv(), timeout=30)
                            data = json.loads(message)

                            if 'type' in data and data['type'] == 'book':
                                token_id = data.get('asset_id')
                                if token_id:
                                    with orderbook_lock:
                                        for game, tokens in self.game_tokens.items():
                                            if tokens['yes_token'] == token_id:
                                                polymarket_orderbook[game]['yes'] = data.get(
                                                    'bids', [])
                                            elif tokens['no_token'] == token_id:
                                                polymarket_orderbook[game]['no'] = data.get(
                                                    'asks', [])
                        except asyncio.TimeoutError:
                            await websocket.send(json.dumps({"type": "ping"}))
                        except Exception:
                            break
            except Exception:
                retry_count += 1
                if retry_count < 3:
                    await asyncio.sleep(0.1)
                else:
                    await asyncio.sleep(1)
                    retry_count = 0

    def set_game_tokens(self, game_tokens: Dict):
        self.game_tokens = game_tokens

    def close(self):
        self.order_log.close()


class ArbitrageExecutor:
    def __init__(self, kalshi_trader: KalshiTrader, polymarket_trader: PolymarketTrader, fileName: str):
        self.kalshi = kalshi_trader
        self.polymarket = polymarket_trader
        self.execution_log = JSONLWriter(fileName)

    def execute_arbitrage(self, arb_opportunity: Dict, kalshi_markets: Dict,
                          polymarket_markets: Dict, max_size: int = 2) -> Dict:
        try:
            execution_size = min(max_size, int(arb_opportunity['max_shares']))

            if execution_size < 10:
                logger.info("Min of 10 shares not available. Skipping arb.")
                return {'message': "Min of 10 shares not available. Skipping arb."}

            # Handle both 2-outcome and 3-outcome arbitrage
            if arb_opportunity['type'] == 'CROSS_EXCHANGE_3_OUTCOME':
                return self._execute_3_outcome_arbitrage(
                    arb_opportunity, kalshi_markets, polymarket_markets, execution_size
                )
            else:
                return self._execute_2_outcome_arbitrage(
                    arb_opportunity, kalshi_markets, polymarket_markets, execution_size
                )

        except Exception as e:
            logger.error(f"Error executing arbitrage: {e}")
            return {'error': str(e)}

    def _execute_2_outcome_arbitrage(self, arb_opportunity: Dict, kalshi_markets: Dict,
                                    polymarket_markets: Dict, execution_size: int) -> Dict:
        home_win = arb_opportunity['home_win']
        away_win = arb_opportunity['away_win']
        print(arb_opportunity, execution_size, home_win, away_win)
        orders = []

        if home_win['exchange'] == 'kalshi':
            market_info = self._get_kalshi_market_info(
                home_win['type'], kalshi_markets)
            if market_info:
                order = self.kalshi.place_order(
                    ticker=market_info['ticker'],
                    side=market_info['side'],
                    action="buy",
                    count=execution_size,
                    price_cents=int(home_win['price'] * 100)
                )
                orders.append({
                    'exchange': 'kalshi',
                    'type': home_win['type'],
                    'order': order
                })

        if away_win['exchange'] == 'kalshi':
            market_info = self._get_kalshi_market_info(
                away_win['type'], kalshi_markets)
            if market_info:
                order = self.kalshi.place_order(
                    ticker=market_info['ticker'],
                    side=market_info['side'],
                    action="buy",
                    count=execution_size,
                    price_cents=int(away_win['price'] * 100)
                )
                orders.append({
                    'exchange': 'kalshi',
                    'type': away_win['type'],
                    'order': order
                })

        if home_win['exchange'] == 'polymarket' or away_win['exchange'] == 'polymarket':
            home_token = polymarket_markets['markets']['home_win']['id'] if polymarket_markets['markets'].get(
                'home_win') else None
            away_token = polymarket_markets['markets']['away_win']['id'] if polymarket_markets['markets'].get(
                'away_win') else None

            if home_token and away_token:
                poly_order = self.polymarket.place_orders(
                    token=home_token if home_win['exchange'] == 'polymarket' else away_token,
                    price=home_win['price'] if home_win['exchange'] == 'polymarket' else away_win['price'],
                    size=execution_size
                )
                orders.append({
                    'exchange': 'polymarket',
                    'order': poly_order
                })

        execution_result = {
            'timestamp': datetime.now().isoformat(),
            'arbitrage': arb_opportunity,
            'orders': orders,
            'execution_size': execution_size,
            'status': 'completed' if len(orders) >= 2 else 'partial'
        }

        self.execution_log.write(execution_result)
        return execution_result

    def _execute_3_outcome_arbitrage(self, arb_opportunity: Dict, kalshi_markets: Dict,
                                    polymarket_markets: Dict, execution_size: int) -> Dict:
        home_win = arb_opportunity['home_win']
        away_win = arb_opportunity['away_win']
        tie = arb_opportunity['tie']
        orders = []

        # Execute home win order
        if home_win['exchange'] == 'kalshi':
            market_info = self._get_kalshi_market_info(home_win['type'], kalshi_markets)
            if market_info:
                order = self.kalshi.place_order(
                    ticker=market_info['ticker'],
                    side=market_info['side'],
                    action="buy",
                    count=execution_size,
                    price_cents=int(home_win['price'] * 100)
                )
                orders.append({'exchange': 'kalshi', 'type': home_win['type'], 'order': order})
        else:  # polymarket
            token = polymarket_markets['markets']['home_win']['id']
            if token:
                order = self.polymarket.place_orders(
                    token=token,
                    price=home_win['price'],
                    size=execution_size
                )
                orders.append({'exchange': 'polymarket', 'type': 'home_win', 'order': order})

        # Execute away win order
        if away_win['exchange'] == 'kalshi':
            market_info = self._get_kalshi_market_info(away_win['type'], kalshi_markets)
            if market_info:
                order = self.kalshi.place_order(
                    ticker=market_info['ticker'],
                    side=market_info['side'],
                    action="buy",
                    count=execution_size,
                    price_cents=int(away_win['price'] * 100)
                )
                orders.append({'exchange': 'kalshi', 'type': away_win['type'], 'order': order})
        else:  # polymarket
            token = polymarket_markets['markets']['away_win']['id']
            if token:
                order = self.polymarket.place_orders(
                    token=token,
                    price=away_win['price'],
                    size=execution_size
                )
                orders.append({'exchange': 'polymarket', 'type': 'away_win', 'order': order})

        # Execute tie order
        if tie['exchange'] == 'kalshi':
            market_info = self._get_kalshi_market_info(tie['type'], kalshi_markets)
            if market_info:
                order = self.kalshi.place_order(
                    ticker=market_info['ticker'],
                    side=market_info['side'],
                    action="buy",
                    count=execution_size,
                    price_cents=int(tie['price'] * 100)
                )
                orders.append({'exchange': 'kalshi', 'type': tie['type'], 'order': order})
        else:  # polymarket
            token = polymarket_markets['markets']['tie']['id']
            if token:
                order = self.polymarket.place_orders(
                    token=token,
                    price=tie['price'],
                    size=execution_size
                )
                orders.append({'exchange': 'polymarket', 'type': 'tie', 'order': order})

        execution_result = {
            'timestamp': datetime.now().isoformat(),
            'arbitrage': arb_opportunity,
            'orders': orders,
            'execution_size': execution_size,
            'status': 'completed' if len(orders) >= 3 else 'partial'
        }

        self.execution_log.write(execution_result)
        return execution_result

    def _get_kalshi_market_info(self, order_type: str, markets: Dict) -> Optional[Dict]:
        if 'home_yes' in order_type:
            return {
                'ticker': markets['markets']['home_win']['id'],
                'side': 'yes'
            }
        elif 'home_no' in order_type:
            return {
                'ticker': markets['markets']['home_win']['id'],
                'side': 'no'
            }
        elif 'away_yes' in order_type:
            return {
                'ticker': markets['markets']['away_win']['id'],
                'side': 'yes'
            }
        elif 'away_no' in order_type:
            return {
                'ticker': markets['markets']['away_win']['id'],
                'side': 'no'
            }
        elif 'tie_yes' in order_type:
            return {
                'ticker': markets['markets']['tie']['id'],
                'side': 'yes'
            }
        elif 'tie_no' in order_type:
            return {
                'ticker': markets['markets']['tie']['id'],
                'side': 'no'
            }
        return None

    def _get_polymarket_market_info(self, order_type: str, markets: Dict) -> Optional[Dict]:
        if 'home' in order_type:
            market = markets['markets'].get('home_win')
            if market:
                return {'token_id': market['id']}
        elif 'away' in order_type:
            market = markets['markets'].get('away_win')
            if market:
                return {'token_id': market['id']}
        elif 'tie' in order_type:
            market = markets['markets'].get('tie')
            if market:
                return {'token_id': market['id']}
        return None

    async def wait_for_kalshi_orders(self, order_ids: List[str], timeout: float) -> Dict[str, bool]:
        """
        Poll Kalshi orders until filled or timeout
        Returns: {order_id: is_filled}
        """
        start_time = time.time()
        order_status = {oid: False for oid in order_ids}

        while time.time() - start_time < timeout:
            all_filled = True
            for order_id in order_ids:
                if order_status[order_id]:
                    continue

                status = self.kalshi.get_order_status(order_id)
                order_state = status.get('status', '').lower()

                if order_state == 'executed':
                    order_status[order_id] = True
                    remaining = status.get('remaining_count', 0)
                    logger.info(f"Kalshi order {order_id} filled (remaining: {remaining})")
                elif order_state in ['canceled', 'expired']:
                    logger.warning(f"Kalshi order {order_id} is {order_state}")
                    order_status[order_id] = False
                else:
                    all_filled = False

            if all_filled:
                return order_status

            await asyncio.sleep(0.1)

        logger.warning(f"Kalshi orders timed out after {timeout}s")
        return order_status

    async def wait_for_polymarket_orders(self, order_result: Dict, timeout: float) -> Dict[str, bool]:
        """
        Check Polymarket order status until filled or timeout
        Returns: {order_id: is_filled}
        """
        start_time = time.time()
        order_status = {}
        order_ids = {}

        if ORDER_TYPE == "MARKET":
            yes_order = order_result.get('yes_order', {})
            no_order = order_result.get('no_order', {})

            if isinstance(yes_order, dict) and yes_order.get('orderID'):
                order_ids['yes'] = yes_order['orderID']
            if isinstance(no_order, dict) and no_order.get('orderID'):
                order_ids['no'] = no_order['orderID']
        else:
            orders = order_result.get('orders', [])
            for i, order in enumerate(orders):
                if isinstance(order, dict) and order.get('orderID'):
                    order_ids[f'order_{i}'] = order['orderID']

        for key in order_ids:
            order_status[key] = False

        if not order_ids:
            logger.warning("No Polymarket order IDs found to track")
            return order_status

        while time.time() - start_time < timeout:
            all_filled = True

            for key, order_id in order_ids.items():
                if order_status[key]:
                    continue

                order_info = self.polymarket.get_order(order_id)

                if not order_info:
                    all_filled = False
                    continue

                status = order_info.get('status', '').upper()
                size_matched = float(order_info.get('size_matched', 0))
                original_size = float(order_info.get('original_size', 0))

                if status == 'MATCHED' or size_matched >= original_size:
                    order_status[key] = True
                    logger.info(f"Polymarket order {order_id} filled ({size_matched}/{original_size})")
                elif status == 'CANCELED':
                    logger.warning(f"Polymarket order {order_id} was canceled")
                    order_status[key] = False
                else:
                    all_filled = False

            if all_filled:
                return order_status

            await asyncio.sleep(0.1)

        logger.warning(f"Polymarket orders timed out after {timeout}s")
        return order_status

    async def cancel_unfilled_orders(self, kalshi_orders: List[str], kalshi_status: Dict[str, bool], poly_order_ids: Dict[str, str], poly_status: Dict[str, bool]):
        """Cancel unfilled orders on both exchanges"""
        logger.info("Cancelling unfilled orders...")

        cancelled_count = 0

        for order_id, filled in kalshi_status.items():
            if not filled:
                success = self.kalshi.cancel_order(order_id)
                if success:
                    logger.info(f"✓ Cancelled Kalshi order {order_id}")
                    cancelled_count += 1
                else:
                    logger.error(f"✗ Failed to cancel Kalshi order {order_id}")

        for key, order_id in poly_order_ids.items():
            if not poly_status.get(key, False):
                try:

                    self.polymarket.client.cancel(order_id)
                    logger.info(f"✓ Cancelled Polymarket order {order_id}")
                    cancelled_count += 1
                except Exception as e:
                    logger.error(
                        f"✗ Failed to cancel Polymarket order {order_id}: {e}")

        logger.info(f"Cancelled {cancelled_count} unfilled orders")

    def close(self):
        self.execution_log.close()


async def poll_prices(client: Union[KalshiMarket, PolymarketMarket],
                      markets: Dict,
                      has_tie: bool,
                      exchange: str, pricesJSON: JSONLWriter):
    """Poll prices from a single exchange"""
    if not client or not markets.get('found'):
        return

    while True:
        if exchange == 'kalshi':
            tickers = []
            ticker_map = {}

            for market_type in ['home_win', 'away_win', 'tie']:
                market_info = markets['markets'].get(market_type)
                if market_info and market_info.get('id'):
                    ticker = market_info['id']
                    tickers.append(ticker)
                    ticker_map[ticker] = market_type

            orderbooks = client.fetch_orderbook(tickers)

            with price_lock:
                for ticker, market_type in ticker_map.items():
                    if ticker not in orderbooks:
                        continue

                    data = orderbooks[ticker]

                    if market_type == 'home_win':
                        prices[exchange]['home_yes'] = {
                            'price': data['yes_price'], 'size': data['yes_size']}
                        prices[exchange]['home_no'] = {
                            'price': data['no_price'], 'size': data['no_size']}
                    elif market_type == 'away_win':
                        prices[exchange]['away_yes'] = {
                            'price': data['yes_price'], 'size': data['yes_size']}
                        prices[exchange]['away_no'] = {
                            'price': data['no_price'], 'size': data['no_size']}
                    elif market_type == 'tie':
                        prices[exchange]['tie_yes'] = {
                            'price': data['yes_price'], 'size': data['yes_size']}
                        prices[exchange]['tie_no'] = {
                            'price': data['no_price'], 'size': data['no_size']}

                last_update[exchange] = datetime.now()

        elif exchange == 'polymarket':
            token_map = {}
            for market_type in ['home_win', 'away_win', 'tie']:
                market_info = markets['markets'].get(market_type)
                if market_info and market_info.get('id'):
                    token_map[market_type] = market_info['id']

            orderbooks = client.fetch_orderbook(token_map)

            with price_lock:
                if 'home_win' in orderbooks:
                    data = orderbooks['home_win']
                    prices[exchange]['home_yes'] = {
                        'price': data['yes_price'], 'size': data['yes_size']}
                    prices[exchange]['home_no'] = {
                        'price': data['no_price'], 'size': data['no_size']}

                if 'away_win' in orderbooks:
                    data = orderbooks['away_win']
                    prices[exchange]['away_yes'] = {
                        'price': data['yes_price'], 'size': data['yes_size']}
                    prices[exchange]['away_no'] = {
                        'price': data['no_price'], 'size': data['no_size']}

                if has_tie and 'tie' in orderbooks:
                    data = orderbooks['tie']
                    prices[exchange]['tie_yes'] = {
                        'price': data['yes_price'], 'size': data['yes_size']}
                    prices[exchange]['tie_no'] = {
                        'price': data['no_price'], 'size': data['no_size']}

                last_update[exchange] = datetime.now()

        pricesJSON.write(
            {'timestamp': datetime.now().isoformat(), 'prices': prices})
        await asyncio.sleep(0.2)


def display_best_prices(team1: str, team2: str, has_tie: bool):
    print("\n" + "="*100)
    print(
        f"REAL-TIME PRICES - {team1} vs {team2} - {datetime.now().strftime('%H:%M:%S')}")
    print("="*100)

    with price_lock:
        print(f"{'Market':<20} {'Kalshi Price':<15} {'Kalshi Size':<12} {'Poly Price':<15} {'Poly Size':<12} {'Delta':<10} {'Best':<10}")
        print("-"*100)

        if has_tie:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no'),
                ('Tie/Draw YES', 'tie_yes'),
                ('Tie/Draw NO', 'tie_no')
            ]
        else:
            markets = [
                (f'{team1} YES', 'home_yes'),
                (f'{team1} NO', 'home_no'),
                (f'{team2} YES', 'away_yes'),
                (f'{team2} NO', 'away_no')
            ]

        for market_name, key in markets:
            kalshi_data = prices['kalshi'][key]
            poly_data = prices['polymarket'][key]

            kalshi_price = kalshi_data['price']
            kalshi_size = kalshi_data['size']
            poly_price = poly_data['price']
            poly_size = poly_data['size']

            if kalshi_price == 0 and poly_price == 0:
                continue

            delta = kalshi_price - poly_price

            kalshi_price_str = f"${kalshi_price:.2f}" if kalshi_price > 0 else "N/A"
            kalshi_size_str = f"{kalshi_size:.0f}" if kalshi_size > 0 else "N/A"
            poly_price_str = f"${poly_price:.2f}" if poly_price > 0 else "N/A"
            poly_size_str = f"{poly_size:.0f}" if poly_size > 0 else "N/A"

            if delta > 0:
                delta_str = f"+${delta:.2f}"
                best = "Kalshi"
            elif delta < 0:
                delta_str = f"-${abs(delta):.2f}"
                best = "Poly"
            else:
                delta_str = "$0.00"
                best = "Equal"

            if kalshi_price == 0:
                best = "Poly only"
                delta_str = "N/A"
            elif poly_price == 0:
                best = "Kalshi only"
                delta_str = "N/A"

            print(f"{market_name:<20} {kalshi_price_str:<15} {kalshi_size_str:<12} {poly_price_str:<15} {poly_size_str:<12} {delta_str:<10} {best:<10}")

    print("-"*100)

    with price_lock:
        kalshi_update = (datetime.now() -
                         last_update['kalshi']).total_seconds()
        poly_update = (datetime.now() -
                       last_update['polymarket']).total_seconds()
        print(
            f"Last update: Kalshi {kalshi_update:.1f}s ago, Polymarket {poly_update:.1f}s ago")
    print("="*100)


def detect_cross_exchange_arbitrage(has_tie: bool, arbLog: JSONLWriter) -> Optional[Dict]:
    """
    Detect arbitrage opportunities across exchanges for both 2-outcome and 3-outcome markets.
    """
    if has_tie:
        return detect_3_outcome_arbitrage(arbLog)
    else:
        return detect_2_outcome_arbitrage(arbLog)


def detect_2_outcome_arbitrage(arbLog: JSONLWriter) -> Optional[Dict]:
    """
    Detect arbitrage for 2-outcome markets (no tie).
    """
    with price_lock:
        home_win_options = []

        if prices['kalshi']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_yes',
                'price': prices['kalshi']['home_yes']['price'],
                'size': prices['kalshi']['home_yes']['size']
            })

        if prices['polymarket']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_yes',
                'price': prices['polymarket']['home_yes']['price'],
                'size': prices['polymarket']['home_yes']['size']
            })

        if prices['kalshi']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_no',
                'price': prices['kalshi']['away_no']['price'],
                'size': prices['kalshi']['away_no']['size']
            })

        if prices['polymarket']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_no',
                'price': prices['polymarket']['away_no']['price'],
                'size': prices['polymarket']['away_no']['size']
            })

        away_win_options = []

        if prices['kalshi']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_yes',
                'price': prices['kalshi']['away_yes']['price'],
                'size': prices['kalshi']['away_yes']['size']
            })

        if prices['polymarket']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_yes',
                'price': prices['polymarket']['away_yes']['price'],
                'size': prices['polymarket']['away_yes']['size']
            })

        if prices['kalshi']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_no',
                'price': prices['kalshi']['home_no']['price'],
                'size': prices['kalshi']['home_no']['size']
            })

        if prices['polymarket']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_no',
                'price': prices['polymarket']['home_no']['price'],
                'size': prices['polymarket']['home_no']['size']
            })

        if not home_win_options or not away_win_options:
            return None

        best_home = min(home_win_options, key=lambda x: x['price'])
        best_away = min(away_win_options, key=lambda x: x['price'])

        total_cost = best_home['price'] + best_away['price']

        if total_cost <= 0.98:
            max_shares = min(best_home['size'], best_away['size'])

            profit_per_share = 1.0 - total_cost
            total_profit = profit_per_share * max_shares
            total_investment = total_cost * max_shares
            roi_percent = (profit_per_share / total_cost) * 100

            arb = {
                'timestamp': datetime.now().isoformat(),
                'type': 'CROSS_EXCHANGE_2_OUTCOME',
                'home_win': best_home,
                'away_win': best_away,
                'total_cost': total_cost,
                'profit_per_share': profit_per_share,
                'max_shares': max_shares,
                'total_profit': total_profit,
                'total_investment': total_investment,
                'roi_percent': roi_percent
            }
            arbLog.write(arb)
            return arb

    return None


def detect_3_outcome_arbitrage(arbLog: JSONLWriter) -> Optional[Dict]:
    """
    Detect arbitrage for 3-outcome markets (with tie/draw).
    """
    with price_lock:
        # Collect all options for home win
        home_win_options = []
        if prices['kalshi']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_yes',
                'price': prices['kalshi']['home_yes']['price'],
                'size': prices['kalshi']['home_yes']['size']
            })
        if prices['polymarket']['home_yes']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_yes',
                'price': prices['polymarket']['home_yes']['price'],
                'size': prices['polymarket']['home_yes']['size']
            })

        if prices['kalshi']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_no',
                'price': prices['kalshi']['away_no']['price'],
                'size': prices['kalshi']['away_no']['size']
            })

        if prices['polymarket']['away_no']['price'] > 0:
            home_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_no',
                'price': prices['polymarket']['away_no']['price'],
                'size': prices['polymarket']['away_no']['size']
            })

        # Collect all options for away win
        away_win_options = []
        if prices['kalshi']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'away_yes',
                'price': prices['kalshi']['away_yes']['price'],
                'size': prices['kalshi']['away_yes']['size']
            })
        if prices['polymarket']['away_yes']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'away_yes',
                'price': prices['polymarket']['away_yes']['price'],
                'size': prices['polymarket']['away_yes']['size']
            })

        # Collect all options for tie
        tie_options = []
        if prices['kalshi']['tie_yes']['price'] > 0:
            tie_options.append({
                'exchange': 'kalshi',
                'type': 'tie_yes',
                'price': prices['kalshi']['tie_yes']['price'],
                'size': prices['kalshi']['tie_yes']['size']
            })
        if prices['polymarket']['tie_yes']['price'] > 0:
            tie_options.append({
                'exchange': 'polymarket',
                'type': 'tie_yes',
                'price': prices['polymarket']['tie_yes']['price'],
                'size': prices['polymarket']['tie_yes']['size']
            })

        if prices['kalshi']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'kalshi',
                'type': 'home_no',
                'price': prices['kalshi']['home_no']['price'],
                'size': prices['kalshi']['home_no']['size']
            })

        if prices['polymarket']['home_no']['price'] > 0:
            away_win_options.append({
                'exchange': 'polymarket',
                'type': 'home_no',
                'price': prices['polymarket']['home_no']['price'],
                'size': prices['polymarket']['home_no']['size']
            })

        # Need at least one option for each outcome
        if not home_win_options or not away_win_options or not tie_options:
            return None

        # Find the cheapest option for each outcome
        best_home = min(home_win_options, key=lambda x: x['price'])
        best_away = min(away_win_options, key=lambda x: x['price'])
        best_tie = min(tie_options, key=lambda x: x['price'])

        # Calculate total cost
        total_cost = best_home['price'] + best_away['price'] + best_tie['price']

        # Check if there's an arbitrage opportunity
        if total_cost <= 0.98:  # Using 0.98 threshold for fees/slippage
            max_shares = min(best_home['size'], best_away['size'], best_tie['size'])

            profit_per_share = 1.0 - total_cost
            total_profit = profit_per_share * max_shares
            total_investment = total_cost * max_shares
            roi_percent = (profit_per_share / total_cost) * 100

            arb = {
                'timestamp': datetime.now().isoformat(),
                'type': 'CROSS_EXCHANGE_3_OUTCOME',
                'home_win': best_home,
                'away_win': best_away,
                'tie': best_tie,
                'total_cost': total_cost,
                'profit_per_share': profit_per_share,
                'max_shares': max_shares,
                'total_profit': total_profit,
                'total_investment': total_investment,
                'roi_percent': roi_percent
            }
            arbLog.write(arb)
            return arb

    return None


def display_cross_exchange_arbitrage(arb: Optional[Dict], team1: str, team2: str):
    if not arb:
        return

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    print("\n" + "🚨 " * 20)
    print("💰 CROSS-EXCHANGE ARBITRAGE DETECTED!")
    print("🚨 " * 20)

    if arb['type'] == 'CROSS_EXCHANGE_3_OUTCOME':
        # Display 3-outcome arbitrage
        home_win = arb['home_win']
        away_win = arb['away_win']
        tie = arb['tie']

        print(f"\n1️⃣  Buy {team1} win")
        print(f"    Exchange: {home_win['exchange'].upper()}")
        print(f"    Type: {home_win['type'].replace('_', ' ').upper()}")
        print(f"    Price: ${home_win['price']:.4f}")
        print(f"    Available: {home_win['size']:.0f} shares")

        print(f"\n2️⃣  Buy {team2} win")
        print(f"    Exchange: {away_win['exchange'].upper()}")
        print(f"    Type: {away_win['type'].replace('_', ' ').upper()}")
        print(f"    Price: ${away_win['price']:.4f}")
        print(f"    Available: {away_win['size']:.0f} shares")

        print(f"\n3️⃣  Buy Tie/Draw")
        print(f"    Exchange: {tie['exchange'].upper()}")
        print(f"    Type: {tie['type'].replace('_', ' ').upper()}")
        print(f"    Price: ${tie['price']:.4f}")
        print(f"    Available: {tie['size']:.0f} shares")
    else:
        # Display 2-outcome arbitrage (existing code)
        home_win = arb['home_win']
        away_win = arb['away_win']

        home_label = f"{team1} win"
        home_trade = f"{home_win['type'].replace('_', ' ').upper()}"
        print(f"\n1️⃣  Buy {home_label} via {home_trade}")
        print(f"    Exchange: {home_win['exchange'].upper()}")
        print(f"    Price: ${home_win['price']:.4f}")
        print(f"    Available: {home_win['size']:.0f} shares")

        away_label = f"{team2} win"
        away_trade = f"{away_win['type'].replace('_', ' ').upper()}"
        print(f"\n2️⃣  Buy {away_label} via {away_trade}")
        print(f"    Exchange: {away_win['exchange'].upper()}")
        print(f"    Price: ${away_win['price']:.4f}")
        print(f"    Available: {away_win['size']:.0f} shares")

    print(f"\n{'='*60}")
    print(f"Total Cost per Share: ${arb['total_cost']:.4f}")
    print(f"Guaranteed Return: $1.00")
    print(f"Profit per Share: ${arb['profit_per_share']:.4f}")
    print(f"ROI: {arb['roi_percent']:.2f}%")
    print(f"{'='*60}")
    print(f"Max Tradeable Shares: {arb['max_shares']:.0f}")
    print(f"Total Investment: ${arb['total_investment']:.2f}")
    print(f"Total Profit: ${arb['total_profit']:.2f}")
    print(f"{'='*60}")

    print("🚨 " * 20 + "\n")


async def main():
    print("SUPPORTED LEAGUES:")
    print("- NFL, CFB, MLB, NHL, NBA")
    print("- EPL, Serie A, Bundesliga, La Liga, Ligue 1, Champions League")
    print("\nEnter match details:")
    print("You can use team abbreviations (e.g., SF, LAR, PSG, BAR, OSA, GET)")

    team1 = input("Team 1 (home/first team): ").strip()
    team2 = input("Team 2 (away/second team): ").strip()
    league = input(
        "League (NFL/CFB/MLB/NHL/NBA/EPL/Serie A/Bundesliga/La Liga/Ligue 1/Champions League): ").strip()

    date_str = input("Date (YYYY-MM-DD) or press Enter to skip: ").strip()
    if date_str:
        try:
            game_date = datetime.strptime(date_str, "%Y-%m-%d")
            print(f"Looking for matches on {game_date.strftime('%B %d, %Y')}")
        except:
            print("Invalid date format, proceeding without date filter")
            game_date = None
    else:
        game_date = None

    print("\nSearching for markets...")
    finder = UniversalMarketFinder()

    league_lower = league.lower()
    if league_lower not in finder.league_mappings:
        print(f"League '{league}' not supported")
        return

    has_tie = finder.league_mappings[league_lower]['has_tie']

    print("\n--- Searching Kalshi ---")
    kalshi_markets = finder.find_kalshi_markets(
        team1, team2, league, game_date)

    if not kalshi_markets or not kalshi_markets.get('found'):
        print(f"❌ Could not find Kalshi markets for {team1} vs {team2}")
        kalshi_markets = {'found': False, 'markets': {}}
    else:
        print(
            f"✓ Found Kalshi event: {kalshi_markets['metadata']['event_ticker']}")
        for market_type in ['home_win', 'away_win', 'tie']:
            market = kalshi_markets['markets'].get(market_type)
            if market and market.get('ticker'):
                team_label = team1 if market_type == 'home_win' else (
                    team2 if market_type == 'away_win' else 'Tie')
                print(f"  {team_label} win: {market['ticker']}")

    print("\n--- Searching Polymarket ---")
    polymarket_markets = finder.find_polymarket_markets(
        team1, team2, league, game_date)
    print(polymarket_markets)
    if not polymarket_markets or not polymarket_markets.get('found'):
        print(f"❌ Could not find Polymarket markets for {team1} vs {team2}")
        polymarket_markets = {'found': False, 'markets': {}}
    else:
        print("✓ Found Polymarket markets")
        for market_type in ['home_win', 'away_win', 'tie']:
            market = polymarket_markets['markets'].get(market_type)
            if market and market.get('id'):
                team_label = team1 if market_type == 'home_win' else (
                    team2 if market_type == 'away_win' else 'Tie')
                print(
                    f"  {team_label}: {market.get('ticker', market['id'][:30])}")

    if not kalshi_markets.get('found') and not polymarket_markets.get('found'):
        print("\n⚠️  No markets found on either exchange.")
        print("Tips:")
        print("- Make sure the date matches the actual game date")
        print("- Try using full team names instead of abbreviations")
        print("- Check if the game is actually scheduled")
        return

    print("\n" + "="*80)
    print("INITIALIZING PRICE MONITORING")
    print("="*80)

    kalshi_trader = None
    kalshi_ws_client = None
    kalshi_client = None

    polymarket_trader = None
    polymarket_client = None

    if kalshi_markets.get('found'):
        kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)

        kalshi_client = KalshiMarket(
            api_key=API_KEY_ID, slug=kalshi_markets['metadata']['event_ticker'])

        if kalshi_auth.authenticate():
            kalshi_trader = KalshiTrader(kalshi_auth)

            tickers = []
            ticker_to_market = {}

            for market_type in ['home_win', 'away_win', 'tie']:
                market_info = kalshi_markets['markets'].get(market_type)
                if market_info and market_info.get('id'):
                    ticker = market_info['id']
                    tickers.append(ticker)
                    ticker_to_market[ticker] = market_type

            kalshi_ws_client = KalshiWebSocketClient(
                kalshi_auth,
                tickers,
                kalshi_markets['metadata']['event_ticker']
            )

            for ticker, market_type in ticker_to_market.items():
                kalshi_ws_client.set_ticker_mapping(ticker, market_type)

            logger.info(
                f"Initialized Kalshi WebSocket client with {len(tickers)} tickers")
        else:
            logger.error("Failed to authenticate with Kalshi")
            kalshi_ws_client = None
            kalshi_trader = None
            raise Exception("Failed to authenticate with Kalshi")

    if polymarket_markets.get('found'):
        polymarket_trader = PolymarketTrader()

        game_tokens = {}
        for market_type in ['home_win', 'away_win', 'tie']:
            market = polymarket_markets['markets'].get(market_type)
            if market and market.get('id'):
                game_slug = polymarket_markets["metadata"]["slugs"].get(
                    "market", "game")
                if game_slug not in game_tokens:
                    game_tokens[game_slug] = {}
                if market_type == 'home_win':
                    game_tokens[game_slug]['yes_token'] = market['id']
                elif market_type == 'away_win':
                    game_tokens[game_slug]['no_token'] = market['id']

        polymarket_trader.set_game_tokens(game_tokens)


        if has_tie:
            poly_slug = polymarket_markets["metadata"]["slugs"].get("home_win", "poly_market")
        else:
            poly_slug = polymarket_markets["metadata"]["slugs"].get("market", "poly_market")

        polymarket_client = PolymarketMarket(slug=poly_slug)

    arbitrage_executor = None
    if kalshi_trader and polymarket_trader:
        arbitrage_executor = ArbitrageExecutor(
            kalshi_trader, polymarket_trader, f"arbs_{team1}_{team2}.jsonl")
        print("\n✓ Arbitrage executor initialized")
    else:
        raise Exception("Failed to init traders and arb executor.")

    print("Starting real-time monitoring...")
    print("Press Ctrl+C to stop\n")

    try:
        tasks = []

        pricesLog = JSONLWriter(f"prices_{team1}_{team2}.jsonl")
        arbLog = JSONLWriter(f"arb_{team1}_{team2}.jsonl")

        print(kalshi_markets, polymarket_markets)
        tasks.append(poll_prices(
            kalshi_client,
            kalshi_markets,
            has_tie,
            "kalshi",
            pricesLog
        ))

        tasks.append(poll_prices(
            polymarket_client,
            polymarket_markets,
            has_tie,
            "polymarket",
            pricesLog
        ))

        async def arb__loop():
            while True:
                arb = detect_cross_exchange_arbitrage(has_tie, arbLog)
                if arb:
                    logger.info("🎯 Arbitrage detected! Executing...")

                    execution_result = arbitrage_executor.execute_arbitrage(
                        arb, kalshi_markets, polymarket_markets, max_size=10
                    )

                    if 'error' in execution_result:
                        logger.error(f"Failed to execute arbitrage: {execution_result['error']}")
                        await asyncio.sleep(0.5)
                        continue

                    kalshi_order_ids = []
                    poly_order_result = None
                    poly_order_ids = {}

                    for order_info in execution_result.get('orders', []):
                        if order_info['exchange'] == 'kalshi':
                            order = order_info.get('order', {})
                            order_id = order.get('order_id')
                            if order_id:
                                kalshi_order_ids.append(order_id)
                                logger.info(f"Kalshi order placed: {order_id}")
                        elif order_info['exchange'] == 'polymarket':
                            poly_order_result = order_info['order']

                    if poly_order_result:
                        if ORDER_TYPE == "MARKET":
                            yes_order = poly_order_result.get('yes_order', {})
                            no_order = poly_order_result.get('no_order', {})

                            if isinstance(yes_order, dict) and yes_order.get('orderID'):
                                poly_order_ids['yes'] = yes_order['orderID']
                                logger.info(f"Polymarket YES order placed: {yes_order['orderID']}")
                            if isinstance(no_order, dict) and no_order.get('orderID'):
                                poly_order_ids['no'] = no_order['orderID']
                                logger.info(f"Polymarket NO order placed: {no_order['orderID']}")
                        else:
                            orders = poly_order_result.get('orders', [])
                            for i, order in enumerate(orders):
                                if isinstance(order, dict) and order.get('orderID'):
                                    poly_order_ids[f'order_{i}'] = order['orderID']
                                    logger.info(f"Polymarket order {i} placed: {order['orderID']}")

                    logger.info(f"⏳ Waiting up to {MAX_ORDER_WAIT_TIME}s for orders to fill...")

                    kalshi_status = {}
                    poly_status = {}

                    if kalshi_order_ids:
                        kalshi_status = await arbitrage_executor.wait_for_kalshi_orders(
                            kalshi_order_ids, MAX_ORDER_WAIT_TIME
                        )

                    if poly_order_ids:
                        poly_status = await arbitrage_executor.wait_for_polymarket_orders(
                            poly_order_result, MAX_ORDER_WAIT_TIME
                        )

                    all_kalshi_filled = all(kalshi_status.values()) if kalshi_status else True
                    all_poly_filled = all(poly_status.values()) if poly_status else True

                    if all_kalshi_filled and all_poly_filled:
                        logger.info("✅ All orders filled successfully!")
                        logger.info(f"💰 Profit realized: ${arb['total_profit']:.2f}")
                    else:
                        unfilled_kalshi = [oid for oid, filled in kalshi_status.items() if not filled]
                        unfilled_poly = [oid for oid, filled in poly_status.items() if not filled]

                        logger.warning("⚠️ Some orders not filled within timeout")
                        if unfilled_kalshi:
                            logger.warning(f"Unfilled Kalshi orders: {unfilled_kalshi}")
                        if unfilled_poly:
                            logger.warning(f"Unfilled Polymarket orders: {unfilled_poly}")

                        if FALLBACK_CANCEL_PENDING:
                            try:
                                await arbitrage_executor.cancel_unfilled_orders(
                                    kalshi_order_ids,
                                    kalshi_status,
                                    poly_order_ids,
                                    poly_status
                                )
                            except Exception as e:
                                print("Error cancelling orders: ", e)
                        else:
                            logger.info("⏸️ Leaving unfilled orders open (FALLBACK_CANCEL_PENDING=False)")

                display_best_prices(team1, team2, has_tie)
                display_cross_exchange_arbitrage(arb, team1, team2)
                await asyncio.sleep(0.5)

        tasks.append(arb__loop())

        await asyncio.gather(*tasks)

    except KeyboardInterrupt:
        print("\n\nStopping monitor...")
        if kalshi_ws_client:
            await kalshi_ws_client.close()
        if kalshi_trader:
            kalshi_trader.close()
        if polymarket_client:
            polymarket_client.close()
        if polymarket_trader:
            polymarket_trader.close()
        if arbitrage_executor:
            arbitrage_executor.close()
        arbLog.close()
        pricesLog.close()
        print("Shutdown complete.")

if __name__ == "__main__":
    asyncio.run(main())
