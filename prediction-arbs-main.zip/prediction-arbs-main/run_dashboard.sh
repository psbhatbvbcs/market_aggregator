#!/bin/bash

echo "================================================"
echo "🚀 Starting Interactive Odds Dashboard"
echo "================================================"
echo ""

# Find the latest CSV file
CSV_FILE=$(ls -t odds_snapshots_*.csv 2>/dev/null | head -1)

if [ -z "$CSV_FILE" ]; then
    echo "❌ No CSV files found!"
    echo "Please run track_leeds_westham.py first to generate data."
    exit 1
fi

echo "📂 Using data file: $CSV_FILE"
echo ""
echo "🌐 Dashboard will open at: http://localhost:8050"
echo ""
echo "💡 Features:"
echo "  • Interactive zooming and panning"
echo "  • Hover tooltips with detailed info"
echo "  • Filter by outcomes and platforms"
echo "  • Three view types (separate, combined, comparison)"
echo "  • Export graphs as high-res PNG"
echo ""
echo "⌨️  Press Ctrl+C to stop the server"
echo "================================================"
echo ""

python dashboard_odds.py "$CSV_FILE"

