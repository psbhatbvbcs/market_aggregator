"""
Odds Snapshot Tracker

Takes synchronized snapshots of odds across all platforms every N seconds.
Perfect for time-series visualization and divergence analysis.

Output: CSV with synchronized timestamps for easy plotting
"""

import requests
import asyncio
import json
import csv
import time
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from datetime import date
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# API Configuration
KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
POLYMARKET_CLOB = "https://clob.polymarket.com"
API_SERVER_BASE = "http://localhost:8000"  # Local API server

# Credentials
API_KEY_ID = "39bb4b72-782d-432e-84e6-f228d2e4703d"
PRIVATE_KEY_PEM = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEA0OqcyMAVYIuNm7pOE6gLqoRkfyJ0s+hbEvFsFDJCGxjQ692B
gGaj3lHTxb/LyIrsIeod89wQVhAdipeE33KABoMwgxLHrsmx1a5CDaKnIKLqj2lj
z4eB4x8pecs/eWo78ZS5oknYniaPs20V1x+XJ08V2fRbJHxudKGSMcdQn+ci9Q1E
X8uIGsYKeZukKv9rDHpp+0TwaV5uuRB9LRSJX/WfPV8Sl8LREkym2B9qLsLEF7u8
8DNEvuP51aupJgcIDFrOq3TwXH6Z9YX9B3JTLaKTIDcpZ4J4jjJ9rm1BZlaN/eru
M1kiiGj8vJhimiJm3UQGDRhr4uoKsESYiUgYFQIDAQABAoIBADVYEpx33319ZLUk
xxbhy8jIcVi9FYtygv69QlmN069TkNUJBC4jByiXQDm4FXKpdk3al7dSs6EmEET5
F2ZuuB3xlYuCWhZZTd0/14HfzEjbEIV55ZByC0pRBKgiq5x28cNntFaqAHOxaPPp
oLADUvcojG3QpQ0V8KY7Mzceq4mIZxVSgp97kHAhJqzjB1KQbkhttPfXkKsswhpb
778ukO+gZ+V/OfJ21jOmTWT5GiO6lB1vOdakH5nIdAwc5xGHEKFjTOChmrgvpD3d
OygUByGbSYAEUJHdY7wW/qPrLrPc7m9UiAzJceK8an94430cJa823dVCcrpivobf
KQsjE0ECgYEA7GZrh0Ste5ijNhJT3Ti6zgtVZPpmTkkRle7dojoJKN10oN8PB4G1
uES4hODRAZv5RWG71zpDE6RU0PrOlW2kEc7WB88haatXFCKxkauuIZ2kj0SADEfJ
WvyivXXy4qry4EW9ShRsF46xQYzMx7NzwHXnx4/Ouyt19pdKZhXfhMkCgYEA4jza
lm6khW4SNBu+D0B55jVfb/HWs3aHkoX/qne0omlVR1egH2BTw60rWstsaBI1xym5
qLvvi6ulf190LK4qU1aUAn560mQD7r8C6QdFiWE0Nwas6oubSkcj04NRyiunM0TI
1eGG1zQfIMyMznyUWwYlrLns8+yTq62O5ZaP2u0CgYEAg3NoM21y8hksGDMUwxx6
c3xF3cKHBN0IlFCgmUagNUL/STz/hHMR8wbze5/vWG+8qmHwK3vQNKnaJ+Ju4RR4
eRaEWQ9KSxHld+Lazl+ikjqweKHkee+o/ZkhfSyLBJN+PktJOFomyOqlkgeTDzCw
GsL1QTisAdPm4lm6Gw3qnlECgYBwgK56jD7IE3p96yXSU8/KiNQSyQJpcBHu7S+8
R5bOBO9hcNOxhqdg8SZUGkCoaBXSGo+2tu5iWFMOShttdJabprwnmVnecdn6yYXa
98C+llXu3yTx5catYz8PmYf8r0SQHC57HZF+Ru8L0mxa6lyj/ySRBkws6IJupvoe
dYbH6QKBgBpZViTdyStqrYYLaVwJOWBDuA6xszmJroLE7nKib4UvW06YyIwv/YxO
Fmzg/FrDjhJffGSQ2tmOVUxxSkixt2bffLYribE+QO/dO5pHatyZpdXUVg4WDSiX
3Q5/l2Qg81kW86hFZZc2vFUOUhPxpF382Mkl6XLEW+wK9hUrpgDo
-----END RSA PRIVATE KEY-----"""

RUNDOWN_API_KEY = "bc27e7387dmsh38d411a3abc9e35p1ea17cjsnccd1838ac7b7"




@dataclass
class OddsSnapshot:
    """A synchronized snapshot of odds across all platforms at a specific time"""
    timestamp: float
    datetime_utc: str
    outcome: str  # e.g., "Leeds United", "Draw", "West Ham"
    # Traditional sportsbooks
    youwager_odds: Optional[float] = None
    matchbook_odds: Optional[float] = None
    unibet_odds: Optional[float] = None
    betmgm_odds: Optional[float] = None
    betonline_odds: Optional[float] = None
    bodog_odds: Optional[float] = None
    fanduel_odds: Optional[float] = None
    draftkings_odds: Optional[float] = None
    sportsbetting_odds: Optional[float] = None
    lowvig_odds: Optional[float] = None
    bovada_odds: Optional[float] = None
    pinnacle_odds: Optional[float] = None
    intertops_odds: Optional[float] = None
    # Prediction markets
    polymarket_price: Optional[float] = None
    kalshi_price: Optional[float] = None
    # American odds for prediction markets
    polymarket_american_odds: Optional[int] = None
    kalshi_american_odds: Optional[int] = None
    rundown_american_odds: Optional[int] = None
    
    def to_dict(self):
        return asdict(self)


class KalshiAuth:
    def __init__(self, api_key_id: str, private_key_pem: str):
        self.api_key_id = api_key_id
        self.private_key = self._load_private_key(private_key_pem)

    def _load_private_key(self, key_pem: str):
        return serialization.load_pem_private_key(
            key_pem.encode('utf-8'),
            password=None,
            backend=default_backend()
        )

    def create_signature(self, timestamp: str, method: str, path: str) -> str:
        message = f"{timestamp}{method}{path}".encode('utf-8')
        signature = self.private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.DIGEST_LENGTH
            ),
            hashes.SHA256()
        )
        return base64.b64encode(signature).decode('utf-8')

    def get_auth_headers(self, method: str, path: str) -> Dict[str, str]:
        timestamp = str(int(datetime.now().timestamp() * 1000))
        signature = self.create_signature(timestamp, method, path)
        return {
            'KALSHI-ACCESS-KEY': self.api_key_id,
            'KALSHI-ACCESS-SIGNATURE': signature,
            'KALSHI-ACCESS-TIMESTAMP': timestamp
        }


class OddsSnapshotTracker:
    """Takes synchronized snapshots of odds every N seconds"""
    
    def __init__(self, game_id: str, outcomes: Dict[str, Dict[str, str]], 
                 snapshot_interval: int = 5, event_date: Optional[str] = None):
        """
        Initialize the snapshot tracker
        
        Args:
            game_id: Unique identifier for the game
            outcomes: Dict mapping outcome names to their market IDs
                     Format: {
                         'Leeds United': {
                             'polymarket': 'token_id',
                             'kalshi': 'ticker'
                         },
                         'Draw': {...},
                         'West Ham': {...}
                     }
            snapshot_interval: Seconds between snapshots (default: 5)
            event_date: Date of the event in "YYYY-MM-DD" format (e.g., "2025-10-24")
        """
        self.game_id = game_id
        self.outcomes = outcomes
        self.snapshot_interval = snapshot_interval
        self.event_date = event_date
        
        # Authentication
        self.kalshi_auth = KalshiAuth(API_KEY_ID, PRIVATE_KEY_PEM)
        
        # Snapshots storage
        self.snapshots: List[OddsSnapshot] = []
        
        # Output files
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.csv_file = f"odds_snapshots_{game_id}_{timestamp}.csv"
        self.json_file = f"odds_snapshots_{game_id}_{timestamp}.jsonl"
        
        logger.info(f"Snapshot tracker initialized")
        logger.info(f"  Interval: {snapshot_interval} seconds")
        logger.info(f"  Outcomes: {len(outcomes)}")
        logger.info(f"  CSV output: {self.csv_file}")
        logger.info(f"  JSON output: {self.json_file}")
    
    async def fetch_polymarket_price(self, token_id: str) -> Optional[float]:
        """Fetch current price from Polymarket"""
        try:
            url = f"{POLYMARKET_CLOB}/book?token_id={token_id}"
            response = await asyncio.to_thread(requests.get, url, timeout=3)
            
            if response.status_code == 200:
                book = response.json()
                asks = book.get('asks', [])
                if asks and len(asks) > 0:
                    return float(asks[-1]['price'])
        except Exception as e:
            logger.debug(f"Error fetching Polymarket {token_id[:10]}...: {e}")
        return None
    
    async def fetch_kalshi_price(self, ticker: str) -> Optional[float]:
        """Fetch current price from Kalshi"""
        try:
            url = f"{KALSHI_BASE}/markets/{ticker}/orderbook"
            response = await asyncio.to_thread(requests.get, url, timeout=3)
            
            if response.status_code == 200:
                orderbook = response.json().get('orderbook', {})
                no_levels = orderbook.get('no', [])
                
                # YES price = 1 - best NO bid
                if no_levels and len(no_levels) > 0:
                    return 1 - no_levels[-1][0] / 100.0
        except Exception as e:
            logger.debug(f"Error fetching Kalshi {ticker}: {e}")
        return None
    
    def _american_to_probability(self, american_odds: int) -> float:
        """Convert American odds to implied probability"""
        if american_odds > 0:
            return 100 / (american_odds + 100)
        else:
            return abs(american_odds) / (abs(american_odds) + 100)

    def _probability_to_american(self, probability: float) -> Optional[int]:
        """Convert probability to American odds"""
        if probability is None or probability <= 0 or probability >= 1:
            return None
        if probability < 0.5:
            return int((100 - (probability * 100)) / probability)
        else:
            return int(-100 * probability / (1 - probability))
    
    async def fetch_rundown_prices(self) -> Dict[str, Optional[float]]:
        """Fetch all prices from Rundown via local API server"""
        if not self.event_date:
            return {}
        
        try:
            # Fetch from local API server
            url = f"http://localhost:8000/rundown?date_str={self.event_date}"
            logger.info(f"Fetching Rundown data from API server: {url}")
            
            response = await asyncio.to_thread(
                requests.get,
                url,
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            
            # Print full response structure
            logger.info("="*80)
            logger.info("API Response Structure:")
            logger.info("-"*80)
            import json
            logger.info(json.dumps(data, indent=2))
            logger.info("="*80)
            
            events = data.get('events', [])
            if not events:
                logger.debug(f"No events found for date: {self.event_date}")
                return {}
            
            # Take the first event
            event = events[0]
            prices = {}
            
            # Process all lines from all platforms
            for line in event.get('lines', []):
                if not line:
                    continue
                
                platform = line.get('affiliate_name')
                if not platform:
                    continue
                
                platform = platform.lower()
                
                # Get both YES market and draw odds
                yes_price = line.get('moneyline_home')
                away_price = line.get('moneyline_away')
                draw_price = line.get('moneyline_draw')
                
                # Store all prices
                if yes_price is not None:
                    platform_key = f"{platform}_yes"
                    prices[platform_key] = yes_price
                    logger.debug(f"Tracked {platform} YES price: {yes_price}")
                    
                if away_price is not None:
                    platform_key = f"{platform}_away"
                    prices[platform_key] = away_price
                    logger.debug(f"Tracked {platform} AWAY price: {away_price}")
                    
                if draw_price is not None:
                    platform_key = f"{platform}_draw"
                    prices[platform_key] = draw_price
                    logger.debug(f"Tracked {platform} DRAW price: {draw_price}")
            
            logger.info(f"Total prices tracked: {len(prices)}")
            return prices
        except Exception as e:
            logger.error(f"Error fetching Rundown: {e}")
        
        return {}
    
    async def take_snapshot(self) -> List[OddsSnapshot]:
        """Take a synchronized snapshot of all markets"""
        snapshot_time = time.time()
        snapshot_datetime = datetime.fromtimestamp(snapshot_time).isoformat()
        snapshots = []
        
        logger.info(f"📸 Taking snapshot at {snapshot_datetime}")
        
        # Fetch all prices concurrently
        tasks = []
        outcome_task_map = []
        
        for outcome_name, markets in self.outcomes.items():
            # Polymarket
            if 'polymarket' in markets and markets['polymarket']:
                task = self.fetch_polymarket_price(markets['polymarket'])
                tasks.append(task)
                outcome_task_map.append(('polymarket', outcome_name))
            
            # Kalshi
            if 'kalshi' in markets and markets['kalshi']:
                task = self.fetch_kalshi_price(markets['kalshi'])
                tasks.append(task)
                outcome_task_map.append(('kalshi', outcome_name))
        
        # Fetch Rundown once for all outcomes
        rundown_task = self.fetch_rundown_prices()
        tasks.append(rundown_task)
        outcome_task_map.append(('rundown', None))
        
        # Execute all fetches concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Organize results by outcome
        prices_by_outcome = {}
        rundown_prices = {}
        
        for (platform, outcome_name), result in zip(outcome_task_map, results):
            if platform == 'rundown':
                if not isinstance(result, Exception) and result:
                    rundown_prices = result
                continue
            
            if outcome_name not in prices_by_outcome:
                prices_by_outcome[outcome_name] = {}
            
            if isinstance(result, Exception):
                prices_by_outcome[outcome_name][platform] = None
            else:
                prices_by_outcome[outcome_name][platform] = result
        
        # Create snapshot for each outcome
        for outcome_name in self.outcomes.keys():
            prices = prices_by_outcome.get(outcome_name, {})
            
            # Map outcome names to Rundown keys (home/away/draw)
            rundown_price = None
            rundown_american = None
            if rundown_prices:
                # Determine which Rundown outcome matches this outcome_name
                # You can customize this mapping based on your outcome names
                outcome_lower = outcome_name.lower()
                if 'draw' in outcome_lower or 'tie' in outcome_lower:
                    rundown_price = rundown_prices.get('draw')
                    rundown_american = rundown_prices.get('draw_american')
                elif self.outcomes.keys():
                    # First non-draw outcome = home, second = away
                    outcome_list = list(self.outcomes.keys())
                    if outcome_name == outcome_list[0]:
                        rundown_price = rundown_prices.get('home')
                        rundown_american = rundown_prices.get('home_american')
                    elif len(outcome_list) > 1 and outcome_name == outcome_list[2]:
                        rundown_price = rundown_prices.get('away')
                        rundown_american = rundown_prices.get('away_american')
            
            # Extract all bookmaker odds from rundown_prices
            bookmaker_prices = {}
            if rundown_prices:
                for bookmaker in ['youwager', 'matchbook', 'unibet', 'betmgm', 'betonline', 
                                'bodog', 'fanduel', 'draftkings', 'sportsbetting', 'lowvig', 
                                'bovada', 'pinnacle', 'intertops']:
                    key = f"{bookmaker}_odds"
                    if outcome_name == outcome_list[0]:  # Home team
                        price = rundown_prices.get(f"{bookmaker}_yes")
                    elif len(outcome_list) > 1 and outcome_name == outcome_list[2]:  # Away team
                        price = rundown_prices.get(f"{bookmaker}_yes")
                    else:  # Draw - use moneyline_draw
                        draw_key = f"{bookmaker}_draw"
                        price = rundown_prices.get(draw_key)
                    bookmaker_prices[key] = price
                    logger.debug(f"Setting {key} = {price} for outcome {outcome_name}")
            
            # Calculate American odds for prediction markets
            poly_price = prices.get('polymarket')
            kalshi_price = prices.get('kalshi')
            
            snapshot = OddsSnapshot(
                timestamp=snapshot_time,
                datetime_utc=snapshot_datetime,
                outcome=outcome_name,
                polymarket_price=poly_price,
                kalshi_price=kalshi_price,
                polymarket_american_odds=self._probability_to_american(poly_price) if poly_price is not None else None,
                kalshi_american_odds=self._probability_to_american(kalshi_price) if kalshi_price is not None else None,
                rundown_american_odds=rundown_american,
                **bookmaker_prices  # Add all bookmaker odds
            )
            
            snapshots.append(snapshot)
            self.snapshots.append(snapshot)
            
            # Log the snapshot with all bookmaker prices
            log_parts = [f"{outcome_name:15}"]
            log_parts.extend([
                f"{bookmaker}: {self._format_price(getattr(snapshot, f'{bookmaker}_odds'))}"
                for bookmaker in ['youwager', 'matchbook', 'unibet', 'betmgm', 'betonline', 
                                'bodog', 'fanduel', 'draftkings', 'sportsbetting', 'lowvig', 
                                'bovada', 'pinnacle', 'intertops']
            ])
            log_parts.extend([
                f"Poly: {self._format_price(snapshot.polymarket_price)}",
                f"Kalshi: {self._format_price(snapshot.kalshi_price)}"
            ])
            logger.info(" | ".join(log_parts))
        
        # Write to files
        self._write_snapshots(snapshots)
        
        return snapshots
    
    def _format_price(self, price: Optional[float]) -> str:
        """Format price for display"""
        if price is None:
            return "N/A    "
        return f"${price:.4f}"
    
    def _write_snapshots(self, snapshots: List[OddsSnapshot]):
        """Write snapshots to CSV and JSON files"""
        # Write to JSONL
        with open(self.json_file, 'a') as f:
            for snapshot in snapshots:
                f.write(json.dumps(snapshot.to_dict()) + '\n')
        
        # Write to CSV
        file_exists = False
        try:
            with open(self.csv_file, 'r'):
                file_exists = True
        except FileNotFoundError:
            pass
        
        with open(self.csv_file, 'a', newline='') as f:
            if snapshots:
                # Define fixed column order
                fieldnames = [
                    'timestamp', 'datetime_utc', 'outcome',
                    # Traditional sportsbooks
                    'youwager_odds', 'matchbook_odds', 'unibet_odds', 'betmgm_odds',
                    'betonline_odds', 'bodog_odds', 'fanduel_odds', 'draftkings_odds',
                    'sportsbetting_odds', 'lowvig_odds', 'bovada_odds', 'pinnacle_odds',
                    'intertops_odds',
                    # Prediction markets
                    'polymarket_price', 'kalshi_price',
                    # American odds for prediction markets
                    'polymarket_american_odds', 'kalshi_american_odds', 'rundown_american_odds'
                ]
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if not file_exists:
                    writer.writeheader()
                for snapshot in snapshots:
                    writer.writerow(snapshot.to_dict())
    
    async def run(self, duration_seconds: int = 1800):
        """Run the snapshot tracker for specified duration"""
        logger.info("="*80)
        logger.info(f"STARTING SNAPSHOT TRACKING")
        logger.info(f"  Duration: {duration_seconds // 60} minutes")
        logger.info(f"  Snapshot interval: {self.snapshot_interval} seconds")
        logger.info(f"  Expected snapshots: ~{duration_seconds // self.snapshot_interval}")
        logger.info("="*80)
        print()
        
        start_time = time.time()
        snapshot_count = 0
        
        try:
            while time.time() - start_time < duration_seconds:
                # Take snapshot
                await self.take_snapshot()
                snapshot_count += 1
                
                # Calculate next snapshot time
                next_snapshot = start_time + (snapshot_count * self.snapshot_interval)
                sleep_time = max(0, next_snapshot - time.time())
                
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
        
        except KeyboardInterrupt:
            logger.info("\n\n⚠️  Tracking interrupted by user")
        
        finally:
            # Generate summary
            self._generate_summary()
    
    def _generate_summary(self):
        """Generate summary statistics"""
        logger.info("\n" + "="*80)
        logger.info("TRACKING SUMMARY")
        logger.info("="*80)
        logger.info(f"Total snapshots: {len(self.snapshots) // len(self.outcomes)}")
        logger.info(f"Data points: {len(self.snapshots)}")
        logger.info(f"Outcomes tracked: {len(self.outcomes)}")
        
        # Calculate availability
        poly_available = sum(1 for s in self.snapshots if s.polymarket_price is not None)
        kalshi_available = sum(1 for s in self.snapshots if s.kalshi_price is not None)
        
        logger.info(f"\nData availability:")
        logger.info(f"  Polymarket: {poly_available}/{len(self.snapshots)} ({poly_available/len(self.snapshots)*100:.1f}%)")
        logger.info(f"  Kalshi: {kalshi_available}/{len(self.snapshots)} ({kalshi_available/len(self.snapshots)*100:.1f}%)")
        
        logger.info(f"\nOutput files:")
        logger.info(f"  CSV: {self.csv_file}")
        logger.info(f"  JSON: {self.json_file}")
        logger.info("="*80)
        
        # Save summary to JSON
        summary = {
            'game_id': self.game_id,
            'total_snapshots': len(self.snapshots) // len(self.outcomes),
            'data_points': len(self.snapshots),
            'outcomes': list(self.outcomes.keys()),
            'polymarket_availability': poly_available / len(self.snapshots) if self.snapshots else 0,
            'kalshi_availability': kalshi_available / len(self.snapshots) if self.snapshots else 0,
            'csv_file': self.csv_file,
            'json_file': self.json_file
        }
        
        summary_file = f"snapshot_summary_{self.game_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        logger.info(f"\nSummary saved to: {summary_file}\n")


async def main():
    """Example usage"""
    # Leeds United vs West Ham configuration
    outcomes = {
        'Leeds United': {
            'polymarket': '30413884270873456148709223082839466102170770506960488658235965928290123136035',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-LEE'
        },
        'Draw': {
            'polymarket': '46989922153535687834881452526579430325384463679270525339176825823619522825824',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-TIE'
        },
        'West Ham': {
            'polymarket': '110458542910229477860301044301936279464048264454202209636357323944697297186083',
            'kalshi': 'KXEPLGAME-25OCT24LEEWHU-WHU'
        }
    }
    
    tracker = OddsSnapshotTracker(
        game_id='leeds_westham_epl',
        outcomes=outcomes,
        snapshot_interval=5,  # Every 5 seconds
        event_date="2025-10-24"  # Current date for testing
    )
    
    # Run for 30 minutes
    await tracker.run(duration_seconds=7200)


if __name__ == "__main__":
    asyncio.run(main())

